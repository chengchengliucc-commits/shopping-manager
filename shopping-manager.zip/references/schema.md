# 数据模型与字段角色

模板 assets/schema.json 的 model/schema 版本为2。后台保持五表：items（本次购物意图/商品条目）、offers（来源报价）、purchases（订单商品行）、events（支付/退款/冲回）、tasks（真实待付阶段和需处理事项）。一个账本可对应一次集中采购或一段用户明确的购物周期；新阶段是否另建文件由用户决定，不把它作为所有人的硬性习惯。

## 身份与数量

- item_id 是购物条目的稳定业务身份，服务端 record_id 是实际更新位置。商品身份、来源行和购物条目分开：同一商品可以多次购买，同一需求可以有多个平台候选；不以名称相近作为合并证明。
- source_key 用于识别材料中的具体对象。购物车来源别名存于报价 source_key，报价 item_id 指向需求；新来源关联同一需求必须明确候选或新增剩余需求。来源变化不能自动生成第二笔真实支付。
- planned_quantity 是本次需求总目标；quantity 在订单行是该次买入数。购物车输入是当前剩余量，业务入口计算“已满足+购物车剩余”，不直接用剩余量覆盖总目标。
- retained_quantity 是明确的最终保留数，未知留空。已知退货后以保留量计算需求满足情况，退款本身不推断退货。历史购买数量仍按订单保留。
- 退出/恢复用 items.details_json.intent_status（active/paused/dropped），not_bought_reason 仅解释。旧数据没有内部状态时兼容原原因退出规则。

稳定 ID/source_key 存在线上；operation_id、固定操作计划与恢复状态存于绑定旁的本地日志。所有 JSON 文本字段按 json_text 解析和序列化；未知金额为 null，真实零元为0。金额原字段以整数分存储。

## 用户输入与派生展示

用户源信息：名称、数量/单位、商品规格、明确购买/退款事实和决定。Agent 负责拆解规格、身份匹配和多表关联，不能要求用户维护 UUID/JSON/流水引用。

系统派生字段：购买状态、预估金额（元）、净支出（元）、参考日期、规格摘要、缺价标记，以及 Link/金额公式。它们可以从事实重建，用户改缓存会在 sync 时被覆盖。用户说“买了”走 record-purchase，不能只把缓存单选点成已购买。

默认购物清单显示商品、购买状态、未买部分预估、数量和规格；已购支出视图显示净支出，两个金额不在同一列切换。报价、购买、流水与待办的技术列在业务视图隐藏，用户自建列/视图保留。前台少列与后台结构化核算可以并存。

## 规格与报价版本

items/offers 的逻辑规格键一致：category、brand、color、memory、storage、size、pack_spec、spec_notes。物理列名可以不同，绑定后按逻辑键读取。品类选项是可扩展的起点，不是能力限于几个品牌/品类。缺规格是未知，不自动解释为不限；引用候选报价时要让用户知道实际选中的变体。

关键型号、代际、兼容条件没有独立列时保存在 details_json.product_identity 和原始材料中；Agent 在关联报价前核对。当前计算器检验已关联候选的结构化规格，不承担从两个近似商品标题自动判断同款的任务。

offers.base_fen 是指定数量的一行合计，basis 取 item_price 或 checkout_total；已包含的优惠/运费不能再次扣加。只有 details_json.quantity_pricing=linear 且 unit_price_fen 明确，才允许换数量估算。

商品页的新快照用 supersedes_offer_id 指向旧报价；旧版本保留但不参加当前最低价。显式选定旧报价时沿替代链使用当前版本；断链/循环/跨需求替代需要核对。购物车是当前观察，同来源报价原位更新并保留捕获时间；旧观察不能覆盖新观察。

## 订单与现金

purchase.order_group_id 把同一次订单的商品行放在一起。每条购买挂接有效 item；导入历史订单可由业务入口自动建已购商品条目。实际买了替代品时，购买名称保存实物，item_id 表达它满足哪个需求。

order_status 取 ordered/shipped/received/cancelled。purchase.details_json.payment_complete=true 表示明确已付清，需有确认支付；普通全款已付不需要人为建立 full_payment 待办。真实定金/尾款仍用付款阶段表达。只有下单不能推断已经支付。

events.kind 取 payment/refund/payment_reversal/refund_reversal，status 取 pending/confirmed/void。交易流水以 order_no 为可读标识，identity_key 使用真实交易身份（或有依据的稳定来源），order_no 本身不能区分同订单的多次支付和退款。非现金奖励不进入现金流水。

同一商品独占的订单/直接流水可确定净额；共享付款需要全部购买行的 details_json.item_paid_fen 且合计等于订单支付。共享退款的 item_refund_fen 也须完整且守恒；它仅分摊整单退款，直接指向购买行的退款另减。任一部分缺失或冲突，单品净支出留空，整单现金总额仍保留。比例分摊注明方法，不能冒称平台明示的单品成交事实。

## 待办与预算

付款任务 kind 取 deposit/balance/full_payment，status 取 active/paid/cancelled；payment_event_ids 保存实际 confirmed 支付 ID 的 JSON 数组。其他任务 evidence/price_protection 可用 done。已付状态不创造支付事实；没有尾款记录也不证明没有尾款。

预算是可选的当次输入，不新增预算列。overview 分别显示净支出、订单待付、未买预估；budget --budget 只核对用户明确提供的预算，不把预算差额称为省钱。

## 兼容与升级

binding.schema_version=1 是本地清单格式；model_version=2 表示当前业务模型。setup 对已有账本补缺少的表/字段/业务视图并重新绑定，不删除记录、用户列或历史表，不自动修改不兼容字段类型。

backend_contract=kdocs-dbsheet-v1 标识共同接口，cli/cli_version 记录当前入口，verified_cli_versions 记录已做本机命令及原账本 schema 核对的版本；它不是完整服务端验收清单。dbsheet-cli/kdocs-cli 切换不改变业务身份、远端字段 ID 或本地恢复日志，核对失败保留原绑定。

旧“需求名称”复用原字段 ID 更名为“商品名称”。旧“价格（元）/参考价格（元）”Number 列升级时原 ID 复用并更名为“预估金额（元）”，新增独立净支出列。引用原字段 ID 的参考价汇总卡可继续引用该估价列；升级后 sync 只在未满足需求上写估价。旧绑定可继续读取，sync 会报告缺少的展示列；完整新版视图需运行 setup。

不把缓存当下次核算的事实来源。用户手动新增行用 repair 在原位置补系统身份，缺数量时报告而非猜测。跨设备同时写入仍没有事务保证；本地锁仅约束本机同一绑定。
