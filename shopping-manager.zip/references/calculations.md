# 确定性计算与输入契约

scripts/shopping.py 使用 Python 3.9+ 标准库。只读取指定 JSON，输出 JSON，不联网、不修改账本。成功 exit=0，输入错误 exit=2，错误写 stderr。stdin 可用 --input -。真实账本快照优先由 ledger.py read 生成，见 db-cli.md。

数据由 Agent 从完整分页回读的账本和明确的新输入映射而来，脚本不是 OCR、CLI 适配器或规则抓取器。金额用整数分；未知用 null；false、含小数的金额和负金额拒绝。Number 列回读得到的整数值浮点（如 10000.0）会被接受并转为整数，含小数的仍拒绝。脚本 issues 必须解释或解决，不能声称无误。

## money：元转分

~~~json
{"amount":"99.90"}
~~~

返回 amount_fen=9990、yuan="99.90"。不支持货币符号、千分位、科学计数或超过两位小数；先核对原文再规范化。分字段不超过 JSON Number 安全整数上限。

## price：基础到手金额

item_price 的 base_fen 是本次指定数量的商品行总额，不是单件价格；运费独立，缺失 null。规则明确时按输入数组顺序扣优惠，仅确认且 eligible=true 的优惠可参与。

~~~json
{
  "basis":"item_price",
  "base_fen":10000,
  "shipping_fen":500,
  "stacking_verified":true,
  "promotions":[
    {"promotion_id":"coupon","kind":"fixed","status":"confirmed","eligible":true,"amount_fen":1000},
    {"promotion_id":"discount","kind":"percent","status":"confirmed","eligible":true,"discount_bps":1000}
  ]
}
~~~

上述虚构规则先减10元，再优惠剩余金额的10%，最后加5元运费，合计8600分。
discount_bps 是“减免比例”：2000 表示减20%，不是付20%。百分比按整数分四舍五入，cap_fen 可封顶；无法确定平台舍入时仍需要结算页确认。

full_reduction 是单阶固定满减，必须有 threshold_fen 和 threshold_basis=original/current；阈值仅针对商品金额，脚本不自行把运费加入门槛。
per_threshold 是单阶每满减：step_fen 为每满门槛，amount_fen 为每满一档的减免额，必须有 threshold_basis=original/current，cap_fen 可封顶。例如 step_fen=30000、amount_fen=5000、base_fen=70000 时按 2 档减 10000 分；不足一档时放 unapplied 的 threshold_not_met。它只算单笔订单内按商品金额的每满，跨店分摊、凑单归属、复杂补贴和定金膨胀仍不在此规则计算器内，用结算证据或条件说明处理。

多个可用优惠必须 stacking_verified=true，且数组顺序有证据。优惠已经包含在基价时不能再次列为扣减。未确认、过期或不适用优惠放 unapplied；条件方案可单独复制输入，标注其假设，不将其冒充确定价。

checkout_total 已包含当前结算的运费和优惠：

~~~json
{"basis":"checkout_total","base_fen":89900}
~~~

此模式不能再次传非零运费或扣减规则。它只是结算输入，不能靠选择 basis 证明证据可靠。
total_fen 在缺 base/运费时为 null，known_subtotal_fen 仅为已知小计，不能改名完整到手价。

## unit-price：同口径单位价

~~~json
{"amount_fen":15000,"total_units":"50","per_units":"1","unit":"片"}
~~~

返回每片3.0000元。对元/100g 可指定 per_units="100"、unit="g"。
输出保留四位元小数，用于比较小单价；同款、层数、净含量、质量与规格可比性由 Agent 检查，数学单位价不等于可直接比较的商品推荐。

## budget/review：一个计划的完整快照

输入见 assets/demo-ledger.json。必填：
- read_complete=true：代表账本记录已经完整读到；只读取一页不能设置。
- items、purchases、events、tasks：四个数组，空也显式给出。offers 不用于金额汇总，若包含只作来源。
- 每条记录包含对应稳定业务 ID；引用必须存在。
- purchases：item_id、order_group_id、quantity、order_status；retained_quantity 未知可留空。
- events：kind、status、amount_fen、target_type、target_id；冲回加 reverses_event_id。
- 支付 tasks：kind=deposit/balance/full_payment、status、amount_fen、target_type/target_id、payment_event_ids（数组，或文本列里的 JSON 数组；留空按空数组）。

参见 schema.md 的关联、状态与更正规則。

金额口径：
~~~text
净现金支出 = 已支付（减支付冲回） - 到账退款（减退款冲回）
尚待付款 = 各有效阶段应付 - 已分配的确认支付净额
预算占用与余额：仅当用户当次口头给出预算（budget --budget 元）时计算；
占用 = 净现金支出 + 尚待付款，余额 = 预算 - 占用。预算不是账本事实，不落库。
~~~

预算作为用户当次可选约束；账本不要求维护预算列。budget 命令核对已花+订单待付，未买预估与预计买齐总额由 overview 单独给出。

不核算返佣。普通订单明确已付清时，purchase.details_json.payment_complete=true 与确认支付共同表达结清，不需额外付款待办；只有下单或支付定金不能推断结清。

同一笔 confirmed payment 不能完整分配到两个付款任务。支付冲回减少关联任务已付额；退款不会自动恢复付款义务，取消或修改义务按订单规则证据更新任务。

未分配到有效付款阶段、且没有明确结清标记的确认支付，若未全部冲回且关联订单仍有效，产生 payment_unallocated:event_id。保留真实累计支付与净支出，但同订单的 payment_tasks.remaining_fen、待付总额、预算占用和剩余预算为 null，直到核实关联；其他订单已知待付仍计入 known_fen。unallocated_payment_ids 列出需要核对的事件。已取消的购买/整单与完全冲回的付款不凭空产生付款义务。

tasks.kind 与 status 必须是受支持的中文选项或英文 token，包括非支付待办；空白或未知类型明确报 InputError。只有 evidence、price_protection 等已知非支付类型不参与付款核算。

仅有定金任务不证明整单付款计划完整：缺少覆盖该购买的尾款/全款义务记录时，产生 deposit_missing_balance_schedule，待付和预算保持未知。尾款确为0也需要明确依据的0金额阶段；已按证据取消的尾款任务可表达义务解除。

一单多品用 order_group 的流水；脚本只给组总额，不猜单件分摊。反复回读同 business_id 的相同记录会去重，冲突记录报错。实际 identity_key 相同的相同财务事件可合并；同金额、同商品但无实际流水身份只提示疑似重复，不静默删除。

每个聚合值返回 known_fen、unknown_count 和 total_fen。unknown_count>0 时 total_fen=null。预算任一组成未知时剩余额度为null，不用已知小计冒充完整额。
budget/review 的 payment_tasks 每条含 task_id、kind、status、target_type/target_id、amount_fen、due_at、time_source 与 remaining_fen，可直接用于待付金额与截止时间提醒；remaining_fen 为 null 表示该阶段应付或已付金额未知。
issues 包含可能重复付款、购买缺支付计划、声明已付却无足额流水、取消订单仍有付款计划、退款大于支付、单订单退款超出该单支付等核对项。
complete 表示所读快照的金额/核对项是否完整，不证明用户未提交的现实交易不存在；未知购买结果仍单列。

review 展示：
- purchased/partial：有非取消购买记录，按数量是否满足计划数量区分；订单状态和最终保留数量另看。
- not_bought：无有效购买记录且明确退出当前意图；旧数据兼容未购原因退出规则。
- purchase_result_unknown：无确认结果，不能列为明确未购。
- cancelled_only：只有取消订单，不表示用户永久放弃需求。
- multi_item_order_groups：不能凭组总额填每件实付。

## workbench 与 overview：展示和统一总额

workbench 返回 summary、reference_pricing、spending_overview、items[].display/amounts/assistant_notes 和 tasks[].display。legacy_display 仅兼容旧调用，不是新视图的数据口径；sync 只写实际绑定的新版字段。

- 预估金额（元）：未满足且仍 active 的需求所需金额，不含已满足部分。最终保留数量明确时用于满足量，退款金额不改变数量。
- 净支出（元）：确认支付减到账退款。独占订单/直接归属可精确计算；共享订单须全部按件支付分摊齐备且与订单支付守恒，共享退款分摊也须完整守恒。任一部分缺失/冲突，不用部分和冒充完整单品支出。
- purchase.details_json.item_paid_fen/item_refund_fen 使用与顶层分金额相同的整数、非负校验。比例分摊保留方法，不自动成为平台单品成交事实。
- 参考价只比较当前版本，supersedes_offer_id 指向的旧版本被排除；显式选择旧报价时沿更新链选当前候选。替代链循环/跨需求错误拒绝。
- 数量应可比；仅明确 quantity_pricing=linear 和 unit_price_fen 才外推剩余数量。已知商品运费加一次，checkout_total 不再叠加。
- 报价日期跟随所选证据，超过7天或未知日期进入汇总缺项，不伪装实时价。未知规格不能宣称已经严格同款，Agent仍需核对型号/变体身份。

spending_overview 返回以下整数分字段：

```text
net_paid_fen = 实际净支出
committed_unpaid_fen = 订单待付
unbought_estimate_fen = 未买部分完整参考预估（缺价时null）
estimated_remaining_fen = 订单待付 + 未买预估
estimated_total_fen = 净支出 + 订单待付 + 未买预估
```

known_unbought_subtotal_fen 保留已录估价小计，missing_price_items/stale_price_items 显示覆盖限制。预算仍可作为当次 --budget 输入核对，不写成账本字段。overview 不返回无依据的完整预计数。

展示缓存不是财务事实；人工改源字段后重新 read/sync。助手解释使用 assistant_notes，不创建“金额概况/下一步/参考价格说明”常驻列。

## 本地演示

```bash
python3 scripts/shopping.py overview --input assets/demo-ledger.json
python3 -m unittest discover -s tests -v
```

样例完全虚构，不代表市场报价。实际操作输入与恢复见 operations.md。
