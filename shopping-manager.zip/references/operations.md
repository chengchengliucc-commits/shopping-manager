# 业务入口：规范化输入与恢复

输入由 Agent 从网页、截图或口述整理成 UTF-8 JSON，不要求用户编写 JSON。所有金额为整数分。先运行 doctor，已有账本可直接绑定；首次/版本升级使用 setup。完整示例中的商品和金额均为虚构。

## 共用调用

```bash
python3 scripts/ledger.py import-cart --binding /用户工作目录/.shopping-ledger/binding.json --input 本次购物车.json
python3 scripts/ledger.py record-purchase --binding /用户工作目录/.shopping-ledger/binding.json --input 本次购买.json
python3 scripts/ledger.py record-refund --binding /用户工作目录/.shopping-ledger/binding.json --input 本次退款.json
python3 scripts/ledger.py set-intent --binding /用户工作目录/.shopping-ledger/binding.json --input 本次决定.json
python3 scripts/ledger.py overview --binding /用户工作目录/.shopping-ledger/binding.json
```

已在当前目录绑定或全局登记且只有一个有效落点时，--binding 可省略；多个账本必须选定。业务入口加 --preview 可只校验并输出计划。用户已要求保存/导入时执行实际写入，预览不冒充已保存。

operation_id 标识本次业务操作；请求文件保存后不换 ID 或内容。脚本把固定多表计划保存在绑定旁 transactions/，子操作在 operations/ 留档。再次提交同输入先对账已有步骤；不会因为新会话而重复创建。不同证据描述同一交易时，先匹配已有购买/流水身份，不能仅换材料来源新增交易。

## import-cart

```json
{
  "operation_id": "cart-demo-capture-1",
  "platform": "demo",
  "captured_at": "2026-10-16T12:00:00+08:00",
  "complete": true,
  "items": [{"sku":"sku-1","name":"演示纸品","quantity":2,"unit":"箱","price_fen":20000,"condition":"全新"}]
}
```

- platform 是规范的平台标识；可选 cart_id 区分账户/购物车，默认与 platform 相同。source_item_id 标识一个明确变体/卖家来源行，缺省用 sku；只有产品 ID 而未区分规格时不能冒充 SKU。
- quantity 是当前购物车的剩余需求。price_fen 是这一行该数量的合计，非单价；未知留空。可附 seller、source_url、shipping_fen、promotions_json 和 schema 的规格字段。赠品可填 item_type=赠品、price_fen=0。
- 明确单价且无数量优惠时，可附 unit_price_fen，导入器标为线性计价；没有这个依据时，不把一次报价外推到其他数量。
- 同一来源行复用报价和意图身份，价格原位更新；本次意图总量=当前已满足数量+购物车剩余数量。历史购买记录不被覆盖，重复导入不重复加数量。
- 已有来源行按报价的 item_id 找原需求。新来源想关联同一需求时显式提供 item_id 与 quantity_mode：remaining 更新剩余需求，candidate 只加比价候选、不改目标量。跨平台同款默认分别记录，确认关联含义后再归并；不按名称猜合并。
- captured_at 需有时区，旧观察不能覆盖新观察。complete=true 仅在已确认读完整购物车时使用；移除项只列为待确认，不推断已购买/放弃，不删除记录。不完整读取用 complete=false。

## record-purchase

```json
{
  "operation_id":"purchase-demo-1",
  "source_key":"order:demo:SO-1001",
  "platform":"demo",
  "order_no":"SO-1001",
  "item_id":"已有需求ID",
  "quantity":1,
  "paid_fen":10000,
  "payment_complete":true
}
```

- item_id 指定已有需求。没有对应需求时省略并提供 name，入口自动建立已购商品条目。quantity 必须明确；order_status 缺省为 ordered，可指定 shipped/received/cancelled。
- 没有支付事实就不填 paid_fen；只说“下单”不能补支付。payment_complete=true 只表示有依据确认已付清，需同时提供 payment 或 paid_fen；可以金额未知但确认已结清。普通全额已付不造付款待办。
- 真实定金/尾款：paid_fen 为已付，remaining_fen 为已确认待付，due_at/time_source 可选。入口建立已付阶段和尾款义务。只知道已付、不知道尾款，保持待付未知。
- 后续付尾款时复用 purchase_id，以本次支付的 source_key/identity_key 记录新增现金；唯一且等额的待付阶段自动结清。有多个阶段或部分支付时由 Agent 指定 payment.task_id，剩余金额与原阶段核对，不新造一组定金尾款。paid_fen/付款金额表示本次新增支付，不能把含定金的累计总实付再次录入。
- 多商品订单使用 purchases 数组，每行提供 item_id 或 name、quantity、source_item_id；整单 payment 只提供一次，例如 {"amount_fen":30000,"identity_key":"实际支付身份","occurred_at":"..."}。order_group_id 可显式提供，否则从平台/订单来源稳定生成。
- 后来的订单截图补齐口述记录时，明确已有 purchase_id 和 payment.event_id，再补 order_no/identity_key。脚本保留原来源和订单关联，金额/归属发生冲突时停止；确认流水的金额更正走明确冲回/替代，不自动覆盖。
- details_json.item_paid_fen 为按购买行归属的累计支付金额，所有共享订单行完整填写且总和等于订单支付才能使用。比例分摊方法放 details_json.allocation 并注明推算性质；原始资料无依据时整单保留、单品留空。

## record-refund

```json
{"operation_id":"refund-demo-pending","source_key":"refund:demo:R-1001","purchase_id":"已有购买ID","amount_fen":2000,"status":"pending"}
```

到账时用同 source_key（或已有 event_id/真实 identity_key），新的 operation_id，status=confirmed。更新同一退款，不追加第二笔。退款申请不减支出；确认到账后才减。已确认退款金额或状态更正需显式冲回/替代。

整单退款使用 target_type=order_group、target_id=订单组。未明确单品归属时各单品净支出留空，整体净支出继续准确核算；可用购买行 details_json.item_refund_fen 记录共享退款的累计分摊，须全行齐备且守恒（不包括已经直接归属购买行的退款）。

只有明确退货数量时才附 retained_quantity（限定 purchase 目标）；现金退款不自动改变保留数量。最终保留0会重新开放未满足需求，曾经的购买和现金记录仍保留。

## set-intent 与 repair

```json
{"operation_id":"pause-demo","item_id":"已有需求ID","intent_status":"paused","reason":"之后再考虑"}
```

intent_status 取 active/paused/dropped，写在内部详情中；reason 是解释，不承担新模型的状态控制。恢复 active 后仍可保留历史原因文字。旧数据没有内部标记时，兼容“有未购原因即退出”的规则。

```bash
python3 scripts/ledger.py repair --binding 绑定.json
```

repair 只为已有名称和有效数量的手动清单行补 ID/source_key，保留原行。缺数量会列进 needs_input；不要为了通过校验猜数量。业务导入遇到缺身份的手动行会尝试此修复；单纯查询保持只读。

## 统一总览与异常恢复

`overview` 返回 net_paid_fen（已付净额）、committed_unpaid_fen（订单待付）、unbought_estimate_fen（未买预估）、estimated_remaining_fen（待付+未买预估）、estimated_total_fen（净支出+待付+未买预估），并带缺价/陈旧报价数。缺价时完整预估留空，known_unbought_subtotal_fen 仍是已知小计。预计金额不是结算承诺；未知优惠、运费和过期证据要在回复中指出。

写入超时/部分失败：每批只发一次，回读未确认则停。再次用原请求仅对账；如果原请求后来完成，可继续后续步骤。仍有缺失时不换 ID、不自动补发；先取得原请求已结束、缺失确未写入的依据，再针对缺失项准备有依据的新操作。未知操作也会阻止其他新 ID 对同一记录写入。

业务数据全部确认而展示刷新失败时会返回 saved=true、display.synced=false。此时只修复展示并执行 sync，不能重复录付款或退款。单表 apply 是低层工具，跨表业务优先使用以上入口。
