# CLI、初始化与恢复

config.json 默认 cli=auto。启动先检测 dbsheet-cli，仅未安装时检测 kdocs-cli；两者的多维表格服务共用 kdocs-dbsheet-v1 契约，本次本机帮助核对版本均为2.7.3。当前只支持这两种入口，不承诺兼容任意 CLI 或其他表格服务。认证使用选中 CLI 的官方登录流程，不索要聊天中的 Token。

```bash
python3 scripts/ledger.py bootstrap
python3 scripts/ledger.py doctor
```

bootstrap 已有任一工具时复用；两者都没有时校验 assets/vendor/dbsheet.json 中的 SHA256，解压原始官方包并安装 dbsheet Skill，调用其 setup.sh/setup.ps1 安装本机 CLI。包内的 Windows 路径分隔符会规范化，拒绝越界路径；已有不同内容的依赖 Skill 不覆盖。首次 CLI 安装需要联网，分发包本身不含所有平台二进制。

bootstrap 的 --install-skill 可在 CLI 已存在时单独安装官方依赖 Skill；--skills-dir 指定 Skill 父目录，--bin-dir 指定 CLI 目录。默认遵循已配置的 CODEX_HOME/skills 或 ~/.codex/skills；默认 CLI 目录在 Unix 为 ~/.local/bin，Windows 为 LOCALAPPDATA/dbsheet-cli。检测同时搜索 PATH 和默认 CLI 目录，执行时固定实际路径；自定义安装目录需加入后续命令的 PATH。

doctor 返回选中 CLI、版本、认证布尔值、auth_command/auth_argv、capabilities、missing_capabilities 和 ready。read/write/setup/create 分别表示读取、记录写入、已有文件结构配置、新建账本所需的本机命令是否具备，ready 还要求已认证。读取未就绪时退出码为2；其他能力按各自字段判断。它检查实际 --help/--version/auth status，不探测远端写权限，也不输出 Token。登录应使用返回的参数数组/完整路径，由用户在官方页面授权；CLI 登录输出可能带 Token，Agent 只转述链接与成功/失败结果。

已有 kdocs-cli 的用户可直接使用，无需安装两个工具。可用 SHOPPING_CLI=dbsheet-cli/kdocs-cli 显式固定入口；兼容 config.json 中原来的固定 cli 名称，环境变量优先。显式指定的工具未安装会报错，不偷偷换用另一个。未来增加入口需要扩展 cli_backend.py 并验证输入、响应、分页和恢复契约，不能仅追加一个可执行文件名。

每次命令固定一个入口，认证失败、缺必要命令、服务端错误或超时不改选另一个重试。主工具存在但不可用时报告原因和对应登录/缺能力信息；自动降级只用于启动时没有安装主工具的情形。底层调用使用参数数组和私有临时 JSON 文件，不把用户材料插进 shell，也不打印认证凭据。CLI 错误仍需要对账，退出码不等于“服务端没有写入”。

## 初始化、升级与续记

```bash
python3 scripts/ledger.py setup --name 购物账本 --binding /用户工作目录/.shopping-ledger/binding.json
python3 scripts/ledger.py setup --file-id 实际文件ID --binding /用户工作目录/.shopping-ledger/binding.json
python3 scripts/ledger.py ledgers
```

setup 新文件时创建 dbt；已有文件时补缺少资源。它创建五表、必要展示字段和业务视图，复用已存在的表/字段 ID，保留用户记录、列与视图。旧“需求名称”与金额列更名复用原 ID，净支出另列；类型不兼容或同名有歧义时停止。初始化请求在 binding.json.setup.json 留档，未知结果不重复创建文件/字段。恢复需先回读确认资源已经存在。

setup 完成代表结构/接口配置已确认，不代表页面视觉验收。它不自动创建仪表盘，也不改变分享权限；优先交付可用清单与 overview，仪表盘按 presentation.md 验证后另配。

setup/bind 在用户目录 ~/.shopping-ledger/ledgers.json 登记绑定路径和 file_id，便于新会话续记；可用 SHOPPING_LEDGER_REGISTRY 指定另一登记位置。业务数据和恢复日志仍在用户工作目录，不进入 Skill 包。默认定位当前工作目录绑定，其次唯一有效登记；有多个落点时明确选择，不猜“最近一个”。

仅需重新映射既有完整结构时可 bind：

```bash
python3 scripts/ledger.py bind --file-id 实际文件ID --binding 绑定.json [--mapping 映射.json]
```

mapping 形如 {"items":{"sheet_id":1,"fields":{"item_id":"真实字段ID"}}}。绑定保存实际 ID/类型、model_version、backend_contract 与 CLI 版本。换工具或版本时先核对本机必要命令、认证，再用所选 CLI 回读原 file_id 的 schema，确认原表/字段 ID 和类型一致才更新绑定中的工具信息；旧 v0.6.0 绑定可按此补齐兼容元数据。继续使用原恢复日志，不复制账本。字段改名后按 ID 继续读写，缺列或类型变化先 setup/核对，不按列位置猜。

## 读取、总览与刷新

```bash
python3 scripts/ledger.py read --binding 绑定.json --out 快照.json
python3 scripts/ledger.py overview --binding 绑定.json
python3 scripts/ledger.py sync --binding 绑定.json [--out 快照.json]
python3 scripts/ledger.py repair --binding 绑定.json
```

read 完整分页读取五表；检查重叠 ID、游标循环、读前后行数和字段绑定。--page-size=2 可检查跨页。服务不提供事务快照，行数校验也不能发现所有并发修改；依单写入者使用。

原始 fields 可为 JSON 文本，统一解析；整值 Number 转整数分，空金额保持未知。read 不改业务记录。非空清单行缺 ID 会给实际 record_id 与 repair 提示；repair 只补已有名称/明确数量行的系统身份，未知数量留给用户确认。

sync 完整读取后重算 items 的购买状态/预估金额/净支出/规格摘要/参考日期/缺价标记，派生 purchases/offers/tasks 的关联商品并更新待付提示；只写差异、回读确认。输出各批累计确认数、跳过的无来源行、缺展示字段、逐行 notes、参考价龄与 spending_overview。旧绑定缺净支出列时不编造完成，应 setup 后 sync。

Link 当前只写唯一可确定的非空关联；整单多品待办不指认单一商品。手动解除/重挂业务关系要同步源 item_id，再刷新派生 Link，不仅改显示链接。

## 业务操作优先，apply 留作低层工具

import-cart、record-purchase、record-refund、set-intent 的输入见 operations.md。这些入口先校验拟写的完整业务状态，再用 transactions/ 中固定计划执行单表子操作。业务全部确认后刷新展示；返回 saved=true 且 display.synced=false 时仅修展示。

```bash
python3 scripts/ledger.py apply --binding 绑定.json --input 单表操作.json
```

apply 输入为 {"operation_id":"固定操作ID","table":"items","records":[{"fields":{"item_id":"稳定ID","name":"商品","planned_quantity":1,"source_key":"材料对象身份"}}]}。每次1-50条，按逻辑字段映射到实际 ID；同业务 ID 更新，不存在才新增；可额外给 record_id 在已有手动行补身份。它校验字段、金额、选项和来源/交易身份，不替代跨表业务规划器。

- 状态英文 token 转中文，未知引擎枚举拒绝；规格新值仅在字段允许 autoAddItem 时补选项再写。原选项一并保留。
- json_text 序列化为文本。新记录未知数值省略，现有数值清空用空字符串；缺失金额不变成0。
- display 只能包含已绑定的文本、Number、单选或 Link 展示字段。Number 须有限值/null，Link 须非空 record_id 数组；不能用展示值覆盖财务原字段。
- 本机排他锁防同一绑定并发；各表不构成跨表事务。操作日志保存固定意图、已确认项与未决状态，不能用换 ID 绕过。

## 超时与部分失败

每个写批次仅发送一次，随后完整回读。全量匹配可确认成功；缺失或不匹配留 unresolved，不因“刚才没有读到”就再次 create。下一次同输入只对账；原请求后来完成后可以继续。

新 operation_id 对同一记录写入也会检查未决日志。旧请求确已终止、缺失确未写入后才能另做有依据的缺失项操作。程序强制退出可能留下 .lock；确认原进程停止并检查日志后再清锁。

CLI 版本变化会重新检查命令和原账本 schema；响应不兼容时停止，不按退出码猜成功。真实服务兼容性仍需验收。远端认证失效、限流、跨设备并发、网页提取准确性不由本地日志解决，验证范围见 validation.md。
