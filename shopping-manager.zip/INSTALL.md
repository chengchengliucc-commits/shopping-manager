# 安装与首次使用

这份文件写给拿到安装包的使用者。Skill 本身是什么、怎么用，见 [README](README.md) 和 [SKILL.md](SKILL.md)。

## 用它做什么

装好之后，你不需要记命令，直接对 AI 说人话：

> 整理我的京东购物车，看看这些东西大概要花多少钱。

> 这件买了，全款100元。这是订单截图，补到原来的记录里。

> 上次申请的20元退款到账了。现在实际花了多少，还要付多少？

AI 会把这些材料整理成金山文档多维表格里的一个账本，下次接着说就能接着更新。

## 需要准备

| 项目 | 要求 |
|---|---|
| AI 客户端 | Codex、Claude Code、Cursor、OpenClaw 任一，或其它支持 Agent Skills 的客户端 |
| Python | 3.9 或更高。macOS/Linux 用 `python3 --version` 检查；Windows 一般用 `python --version` |
| 金山文档账号 | 能正常登录自己的账号（首次使用会引导你授权） |
| 网络 | 首次准备账本时需要联网，自动下载 dbsheet CLI |

不需要另外装 Python 包，脚本只用标准库。

## 安装

### 方式 A：从 Skills 市场安装（最省事）

如果你的客户端接了 KSkillHub，直接搜「购物管理系统」订阅，客户端会自动同步到本地。

### 方式 B：本地安装安装包

先解压到一个临时目录看一眼，确认里面有 `SKILL.md`。然后手工放到客户端的 skills 目录：

**macOS / Linux**

```bash
# 按你实际用的客户端选一个路径
DEST="$HOME/.codex/skills/shopping-manager"      # Codex
# DEST="$HOME/.claude/skills/shopping-manager"    # Claude Code
# DEST="$HOME/.cursor/skills/shopping-manager"    # Cursor
# DEST="$HOME/.openclaw/skills/shopping-manager"  # OpenClaw

mkdir -p "$DEST"
unzip -o shopping-manager-0.6.3.zip -d "$DEST"
ls "$DEST"   # 应该看到 SKILL.md
```

**Windows PowerShell**

```powershell
$DEST = "$env:USERPROFILE\.codex\skills\shopping-manager"   # Claude Code 换成 .claude，Cursor 换成 .cursor
New-Item -ItemType Directory -Force -Path $DEST | Out-Null
Expand-Archive -Path .\shopping-manager-0.6.3.zip -DestinationPath $DEST -Force
Get-ChildItem $DEST   # 应该看到 SKILL.md
```

装完**重启客户端或新开一个会话**，让客户端重新扫描 skills 目录。已经开着的会话不会自动发现新 Skill。

## 装完先自检

不用登录、不联网，跑一遍内置样例：

```bash
python3 "$HOME/.codex/skills/shopping-manager/scripts/shopping.py" overview \
  --input "$HOME/.codex/skills/shopping-manager/assets/demo-ledger.json"
```

输出里应该有 `"estimated_total_fen": 1030000`。对得上就说明脚本能跑。

想更彻底一点，可以跑单测（148 个，约几秒）：

```bash
cd "$HOME/.codex/skills/shopping-manager" && python3 -m unittest discover -s tests
```

期望最后一行是 `OK`。

## 第一次真正使用

在**你自己的项目目录**里打开客户端，然后说：

> 帮我建一个购物账本

AI 会依次做这几件事，过程中可能停下来要你配合：

1. 检查有没有可用的 `dbsheet-cli`（或 `kdocs-cli`）；都没有就用安装包内置的官方分发包装上；
2. 给你一个**官方授权链接**，请你自己在浏览器里点开并登录；
3. 授权完成后建好五张表和业务视图，告诉你在哪里继续。

授权这一步有两个约定：**Token 由你本人在官方页面完成，不要把 Token 贴回对话**；AI 也不应该向你索要 Token。

## 你的数据存在哪里

| 内容 | 位置 |
|---|---|
| 账本本身（五张表、视图） | 你自己的金山文档多维表格里 |
| 绑定信息 | 当前工作目录的 `.shopping-ledger/binding.json` |
| 账本登记表 | `~/.shopping-ledger/ledgers.json` |

换目录继续记账时，AI 会用登记表找到原来的账本；有好几个账本时会让你选。不要手动改这些文件——改坏了 AI 会找不到账本。

## 卸载

删掉安装目录就行，**表格和账本不会跟着消失**，它们在你的云文档里。

如果想连本地痕迹一起清掉，再删工作目录下的 `.shopping-ledger/` 和 `~/.shopping-ledger/`。删之前确认里面没有你还需要的中间状态。

## 常见问题

**`python3: command not found`**
换用 `python` 试；确认版本 ≥ 3.9。Windows 上通常就是 `python`。

**提示找不到 dbsheet-cli / kdocs-cli**
在安装目录运行 `python3 scripts/ledger.py bootstrap`，它会解压内置官方包并调用官方安装器。

**登录过但仍显示未认证**
运行 `python3 scripts/ledger.py doctor` 看具体哪一项没过；必要时重新执行它给出的授权命令。

**提示找不到账本**
当前目录没有 `.shopping-ledger/`，也没登记过账本。让 AI 先 `setup` 建一个，或用 `ledger.py ledgers` 列出现有账本。

**Windows 下输出中文乱码或报编码错误**
PowerShell 里先执行 `$env:PYTHONUTF8=1` 再跑命令。

**想确认安装包没被改过**
用官方给的 SHA256 对比：`shasum -a 256 shopping-manager-0.6.3.zip`（Windows：`Get-FileHash .\shopping-manager-0.6.3.zip -Algorithm SHA256`）。

## 当前状态（重要）

0.6.3 是**小范围试用版**，不是成熟产品，请按试用的预期使用：

- 真实服务上的完整流程（建表 → 导入购物车 → 部分购买 → 退款 → 复盘 → 写入中断后恢复）还没做过一轮完整验收，只做过分层验证；
- 安装器只在 macOS 上实机跑过，Windows 的路径分支没有实机验证；
- 网页、截图识别的准确性依赖当时的页面和你给的材料，会有错，请按订单核对。

遇到问题请把**报错原文和出错的那条命令**发给作者，不要贴 Token。验证到什么程度、哪些没验，见 [验证说明](references/validation.md)。
