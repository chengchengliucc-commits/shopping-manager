#!/usr/bin/env python3
"""Bind, read and reconcile shopping records through a supported dbsheet CLI."""
import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import tempfile

from shopping import DISPLAY_LABELS, fen, workbench
from cli_backend import (ACTIVE_CLI, CONTRACT, SUPPORTED, BackendError, cli_session,
                         cli_executable, cli_version, inspect_cli, require_capability, select_cli)

ROOT = Path(__file__).resolve().parents[1]
TABLES = json.loads((ROOT / "assets/schema.json").read_text(encoding="utf-8"))["tables"]
DEFINITIONS = {t["logical_name"]: t for t in TABLES}
PRESENTATION = json.loads((ROOT / "assets/presentation.json").read_text(encoding="utf-8"))
DISPLAY_FIELDS = PRESENTATION.get("display_fields", {})
DISPLAY_ALIASES = PRESENTATION.get("display_aliases", {})
MODEL_VERSION = 2
FIELD_ALIASES = {"items": {"name": ("需求名称",)}}
# Spec selects follow the field's own autoAddItem flag from the live schema, so
# legitimate new values (a new category, a new brand) can be filled directly;
# engine enums (statuses) stay strict via DISPLAY_LABELS in prepare_fields.


class LedgerError(ValueError):
    pass


def unwrap(value):
    """Check every envelope, including inner result errors under an outer code=0."""
    while isinstance(value, dict):
        if "code" in value and (isinstance(value["code"], bool) or value["code"] not in (0, "0")):
            raise LedgerError("CLI business error, code=" + str(value["code"]))
        if "result" in value and (isinstance(value["result"], bool) or value["result"] not in (0, "0", "ok")):
            raise LedgerError("CLI business error, result=" + str(value["result"]))
        if "data" in value and any(k in value for k in ("code", "result", "message", "msg")):
            value = value["data"]
        elif "detail" in value and "result" in value:
            value = value["detail"]
        else:
            return value
    raise LedgerError("CLI returned no object")


def cli_name():
    if ACTIVE_CLI.get():
        return ACTIVE_CLI.get()
    config = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
    try:
        return select_cli(config.get("cli", "auto"))
    except BackendError as error:
        raise LedgerError(str(error)) from None


def attach_backend(binding, info):
    """Record the transport only after its live schema has matched the binding."""
    versions = dict(binding.get("verified_cli_versions", {}))
    if binding.get("cli") in SUPPORTED and binding.get("cli_version"):
        versions.setdefault(binding["cli"], binding["cli_version"])
    versions[info["cli"]] = info["version"]
    binding.update(cli=info["cli"], cli_version=info["version"], backend_contract=CONTRACT,
                   verified_cli_versions=versions)
    return binding


def call(service, action, payload):
    # Keep user content out of shell interpolation and process argument listings.
    with tempfile.TemporaryDirectory(prefix="shopping-cli-") as directory:
        path = Path(directory) / "params.json"
        save_json(path, payload)
        try:
            result = subprocess.run([cli_executable(cli_name()), service, action, "--file", str(path), "--output", "json"],
                                    capture_output=True, text=True, timeout=45)
        except subprocess.TimeoutExpired:
            raise LedgerError("CLI timeout; writes must be reconciled by readback") from None
        # CLI diagnostics can contain user content; return only the action and exit code.
        if result.returncode:
            raise LedgerError(action + " failed, exit=" + str(result.returncode))
        try:
            return unwrap(json.loads(result.stdout))
        except json.JSONDecodeError:
            raise LedgerError(action + " returned invalid JSON; reconcile writes before retrying") from None


def save_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix="." + path.name, dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def registry_path():
    return Path(os.environ.get("SHOPPING_LEDGER_REGISTRY", str(Path.home() / ".shopping-ledger" / "ledgers.json")))


def known_ledgers(path=None):
    path = Path(path) if path else registry_path()
    entries = json.loads(path.read_text(encoding="utf-8")) if path.exists() else []
    if not isinstance(entries, list):
        raise LedgerError("ledger registry must contain an array")
    return [entry for entry in entries if isinstance(entry, dict) and Path(entry.get("binding", "")).is_file()]


def remember_binding(binding_path, binding, path=None):
    path = Path(path) if path else registry_path()
    target = str(Path(binding_path).resolve())
    entries = [entry for entry in known_ledgers(path) if entry["binding"] != target]
    entries.append({"binding": target, "file_id": binding["file_id"]})
    save_json(path, entries)


def resolve_binding(supplied=None, workspace=None, registry=None):
    if supplied:
        return Path(supplied).resolve()
    local = Path(workspace or Path.cwd()) / ".shopping-ledger" / "binding.json"
    if local.is_file():
        return local.resolve()
    candidates = known_ledgers(registry)
    if len(candidates) == 1:
        return Path(candidates[0]["binding"]).resolve()
    raise LedgerError("choose a ledger with --binding; use ledgers to list known bindings")


@contextmanager
def writer_lock(binding_path):
    path = Path(str(binding_path) + ".lock")
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError:
        raise LedgerError("binding has an active or unresolved writer lock: " + str(path)) from None
    try:
        os.close(fd)
        yield
    finally:
        path.unlink()


def get_schema(file_id):
    schema = call("dbsheet", "get-schema", {"file_id": file_id})
    if not isinstance(schema.get("sheets"), list):
        raise LedgerError("get-schema returned no sheets")
    return schema


def make_binding(schema, file_id, mapping=None):
    mapping = mapping or {}
    tables = {}
    for definition in TABLES:
        logical = definition["logical_name"]
        override = mapping.get(logical, {})
        matches = [s for s in schema["sheets"] if
                   (s["id"] == override["sheet_id"] if "sheet_id" in override else s["name"] == definition["name"])]
        if len(matches) != 1:
            raise LedgerError("missing or ambiguous table: " + logical)
        sheet = matches[0]
        fields = {}
        for field in definition["fields"]:
            selected = override.get("fields", {}).get(field["key"], field["name"])
            candidates = [f for f in sheet["fields"] if selected in (f["id"], f["name"])]
            if not candidates and field["key"] not in override.get("fields", {}):
                aliases = FIELD_ALIASES.get(logical, {}).get(field["key"], ())
                candidates = [f for f in sheet["fields"] if f["name"] in aliases]
            if len(candidates) != 1:
                raise LedgerError("missing or ambiguous field: " + logical + "." + field["key"])
            fields[field["key"]] = {k: candidates[0][k] for k in ("id", "name", "type")}
        core_names = {f["name"] for f in definition["fields"]}
        display_names = {f["name"] for f in DISPLAY_FIELDS.get(logical, [])
                         if f["type"] in {"MultiLineText", "Number", "SingleSelect", "Link", "OneWayLink"}
                         and f["name"] not in core_names}
        select_options = {}
        for field in definition["fields"]:
            if field.get("suggested_cli_type") != "SingleSelect":
                continue
            live = next((f for f in sheet["fields"] if f["name"] == fields[field["key"]]["name"]), None)
            if not live:
                continue
            values = [i.get("value") for i in (live.get("items") or [])
                      if isinstance(i, dict) and i.get("value")]
            select_options[field["key"]] = {"values": values, "auto_add": live.get("autoAddItem") is True}
        displays = {}
        for name in display_names:
            candidates = [f for f in sheet["fields"] if f["name"] == name]
            if not candidates:
                candidates = [f for f in sheet["fields"] if f["name"] in DISPLAY_ALIASES.get(logical, {}).get(name, [])]
            if len(candidates) > 1:
                raise LedgerError("ambiguous display field: " + logical + "." + name)
            if candidates:
                displays[name] = {k: candidates[0][k] for k in ("id", "name", "type")}
        tables[logical] = {"sheet_id": sheet["id"], "fields": fields, "select_options": select_options,
                           "display_fields": displays}
    return {"schema_version": 1, "model_version": MODEL_VERSION, "file_id": str(file_id),
            "cli": cli_name(), "backend_contract": CONTRACT, "tables": tables}


def list_records(file_id, sheet_id, page_size=100):
    records, ids, tokens, token = [], set(), set(), ""
    while True:
        page = call("dbsheet", "records-list", {"file_id": file_id, "sheet_id": sheet_id,
                    "prefer_id": True, "page_size": page_size, "page_token": token})
        if not isinstance(page.get("records"), list):
            raise LedgerError("records-list returned no records array")
        for record in page["records"]:
            if not record.get("id") or record["id"] in ids:
                raise LedgerError("missing record ID or overlapping pages; read is incomplete")
            ids.add(record["id"])
            fields = record.get("fields", {})
            if isinstance(fields, str):
                fields = json.loads(fields)
            if not isinstance(fields, dict):
                raise LedgerError("record fields must be an object or JSON object string")
            records.append({"id": record["id"], "fields": fields})
        token = page.get("page_token", "")
        if not token:
            return records
        if not isinstance(token, str) or token in tokens:
            raise LedgerError("pagination cursor did not advance; read is incomplete")
        tokens.add(token)


def verify_binding(binding, schema):
    if (binding.get("schema_version") != 1 or binding.get("cli") not in SUPPORTED
            or binding.get("backend_contract", CONTRACT) != CONTRACT):
        raise LedgerError("binding backend contract is unsupported; check it before rebinding")
    if not isinstance(binding.get("model_version", 1), int) or binding.get("model_version", 1) > MODEL_VERSION:
        raise LedgerError("binding uses a newer model; use a compatible Skill version")
    by_id = {s["id"]: s for s in schema["sheets"]}
    for logical, definition in DEFINITIONS.items():
        table = binding.get("tables", {}).get(logical)
        if not table or any(f["key"] not in table.get("fields", {}) for f in definition["fields"]):
            raise LedgerError("binding model is outdated; run setup --file-id with this binding")
        displays = table.setdefault("display_fields", {})
        for canonical, aliases in DISPLAY_ALIASES.get(logical, {}).items():
            for alias in aliases:
                if canonical not in displays and alias in displays:
                    displays[canonical] = displays.pop(alias)
        active_displays = {f["name"] for f in DISPLAY_FIELDS.get(logical, [])}
        table["display_fields"] = {name: value for name, value in displays.items() if name in active_displays}
        sheet = by_id.get(table["sheet_id"])
        if sheet is None:
            raise LedgerError("bound table is missing")
        actual = {f["id"]: f for f in sheet["fields"]}
        for field in [table["fields"][f["key"]] for f in definition["fields"]] + list(table.get("display_fields", {}).values()):
            if field["id"] not in actual or actual[field["id"]]["type"] != field["type"]:
                raise LedgerError("bound field is missing or changed type; remap before continuing")


def logical_fields(logical, record, binding):
    table = binding["tables"][logical]
    row = {f["key"]: record["fields"].get(table["fields"][f["key"]]["id"]) for f in DEFINITIONS[logical]["fields"]}
    for field in DEFINITIONS[logical]["fields"]:
        key, value = field["key"], row[field["key"]]
        if field["logical_type"] == "json_text" and value not in (None, ""):
            row[key] = json.loads(value) if isinstance(value, str) else value
        if key.endswith("_fen"):
            row[key] = fen(None if value == "" else value, logical + "." + key)
    return row


def read_snapshot(binding, page_size=100):
    before = get_schema(binding["file_id"])
    verify_binding(binding, before)
    selected, record_ids = {}, {}
    counts = {}
    for logical in DEFINITIONS:
        table = binding["tables"][logical]
        raw = list_records(binding["file_id"], table["sheet_id"], page_size)
        counts[table["sheet_id"]] = len(raw)
        selected[logical], record_ids[logical] = [], {}
        key = DEFINITIONS[logical]["business_key"]
        for record in raw:
            row = logical_fields(logical, record, binding)
            if all(v in (None, "", [], {}) for v in row.values()):
                continue
            if not row.get(key):
                raise LedgerError(logical + ": nonempty record needs business ID: " + record["id"] +
                                  "; run repair to adopt an existing named item row")
            if row[key] in record_ids[logical]:
                raise LedgerError("duplicate business ID in ledger: " + row[key])
            selected[logical].append(row)
            record_ids[logical][row[key]] = record["id"]
    after = get_schema(binding["file_id"])
    verify_binding(binding, after)
    for schema in (before, after):
        for sheet in schema["sheets"]:
            if sheet["id"] in counts and sheet.get("recordsCount") != counts[sheet["id"]]:
                raise LedgerError("record count changed or pagination is incomplete; read again")
    return {"read_complete": True, "read_at": datetime.now(timezone.utc).isoformat(),
            **selected, "_record_ids": record_ids}


def comparable(value):
    return None if value in (None, "") else value


def prepare_fields(logical, values):
    definitions = {f["key"]: f for f in DEFINITIONS[logical]["fields"]}
    if not isinstance(values, dict) or set(values) - definitions.keys():
        raise LedgerError("unknown logical fields in " + logical)
    result = dict(values)
    for key in (DEFINITIONS[logical]["business_key"], "source_key"):
        if not isinstance(result.get(key), str) or not result[key].strip():
            raise LedgerError("write requires a stable nonempty " + key)
    for key, value in list(result.items()):
        labels = DISPLAY_LABELS.get(logical, {}).get(key)
        if labels:
            value = labels.get(value, value)
            if value not in labels.values():
                raise LedgerError("unknown option: " + logical + "." + key)
        if key.endswith("_fen"):
            value = fen(value, key)
        if definitions[key]["logical_type"] == "json_text" and value not in (None, ""):
            value = json.loads(value) if isinstance(value, str) else value
            value = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
        result[key] = value
    return result


def _live_select_meta(schema, binding, logical):
    """Field-keyed select metadata from the live schema; option lists drift over time."""
    table = binding["tables"][logical]
    sheet = next((s for s in schema["sheets"] if s["id"] == table["sheet_id"]), None)
    if not sheet:
        raise LedgerError("bound table is missing")
    meta = {}
    for field_key, field in table["fields"].items():
        if field["type"] != "SingleSelect":
            continue
        live = next((f for f in sheet["fields"] if f["id"] == field["id"]), None)
        if not live:
            continue
        values = [i.get("value") for i in (live.get("items") or [])
                  if isinstance(i, dict) and i.get("value")]
        meta[field_key] = {"id": field["id"], "type": field["type"],
                           "values": values, "auto_add": live.get("autoAddItem") is True}
    return meta


def apply_records(binding, binding_path, batch):
    logical, operation_id = batch.get("table"), batch.get("operation_id")
    if logical not in DEFINITIONS or not isinstance(operation_id, str) or not operation_id.strip():
        raise LedgerError("write requires a known table and stable operation_id")
    records = batch.get("records")
    if not isinstance(records, list) or not 1 <= len(records) <= 50:
        raise LedgerError("write requires 1..50 records")
    table, key = binding["tables"][logical], DEFINITIONS[logical]["business_key"]
    schema_now = get_schema(binding["file_id"])
    verify_binding(binding, schema_now)
    select_meta = _live_select_meta(schema_now, binding, logical)
    desired = []
    missing_options = {}
    for record in records:
        values = prepare_fields(logical, record["fields"])
        # Spec selects marked autoAddItem by the field grow on demand: the missing
        # options are appended to the field before writing (update-records drops
        # unknown select values silently instead of adding them). Engine enums
        # stay strict: prepare_fields rejects unknown statuses outright.
        for field_key, value in values.items():
            meta = select_meta.get(field_key)
            if not meta or value in (None, "") or value in meta["values"]:
                continue
            if not meta.get("auto_add"):
                raise LedgerError("unknown option: " + logical + "." + field_key +
                                  "; align the value or add the option on the field first")
            spec = missing_options.setdefault(meta["id"], {"type": meta["type"], "values": set(meta["values"])})
            spec["values"].add(value)
        display = record.get("display", {})
        if not isinstance(display, dict) or set(display) - table.get("display_fields", {}).keys():
            raise LedgerError("unknown or unbound display fields; create fields and bind again")
        for name, value in display.items():
            field_type = table["display_fields"][name]["type"]
            if field_type == "Number":
                if value is not None and (isinstance(value, bool) or not isinstance(value, (int, float))
                                          or not math.isfinite(value)):
                    raise LedgerError("numeric display fields accept finite numbers or null only")
            elif field_type in ("Link", "OneWayLink"):
                # 链接是派生值且由 sync 维护：只接受记录 id 的非空数组，不支持清写
                #（手工解除关联在表格界面完成，回读缺省与空数组的形态差异会让对账失真）。
                if not isinstance(value, list) or not value or not all(
                        isinstance(v, str) and v.strip() for v in value):
                    raise LedgerError("link display fields accept a nonempty list of record ids")
            elif value is not None and not isinstance(value, str):
                raise LedgerError("text display fields accept strings or null only")
        desired.append({"record_id": record.get("record_id"), "values": values,
                        "fields": {**{table["fields"][k]["id"]: v for k, v in values.items()},
                                   **{table["display_fields"][k]["id"]: v for k, v in display.items()}}})
    if len({r["values"][key] for r in desired}) != len(desired):
        raise LedgerError("duplicate business IDs in write batch")
    explicit_ids = [r["record_id"] for r in desired if r["record_id"]]
    if len(set(explicit_ids)) != len(explicit_ids):
        raise LedgerError("one remote record cannot be adopted twice in the same batch")
    if logical == "events":
        identities = [r["values"]["identity_key"] for r in desired if r["values"].get("identity_key")]
        if any(not isinstance(key, str) for key in identities) or len(set(identities)) != len(identities):
            raise LedgerError("duplicate or invalid financial identity_key in write batch")
    fingerprint = hashlib.sha256(json.dumps(desired, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
    journal_path = Path(binding_path).parent / "operations" / (hashlib.sha256(operation_id.encode()).hexdigest() + ".json")
    journal = json.loads(journal_path.read_text(encoding="utf-8")) if journal_path.exists() else None
    if journal and (journal["fingerprint"] != fingerprint or journal["file_id"] != binding["file_id"]):
        raise LedgerError("operation_id was already used for a different write")
    # Option growth is a schema change, not a record write: appending the missing
    # options first is idempotent and safe to keep if the record write later fails.
    if missing_options:
        call("dbsheet", "update-fields", {"file_id": binding["file_id"], "sheet_id": table["sheet_id"],
             "fields": [{"id": fid, "type": spec["type"],
                         "items": [{"value": v} for v in sorted(spec["values"])]}
                        for fid, spec in sorted(missing_options.items())]})
    verify_binding(binding, get_schema(binding["file_id"]))

    def current_rows():
        rows = list_records(binding["file_id"], table["sheet_id"])
        by_business = {}
        for row in rows:
            identity = row["fields"].get(table["fields"][key]["id"])
            if identity:
                if identity in by_business:
                    raise LedgerError("duplicate remote business ID: " + identity)
                by_business[identity] = row
        return rows, by_business

    field_types = {table["fields"][f["key"]]["id"]: f["logical_type"]
                   for f in DEFINITIONS[logical]["fields"]}

    def matches(actual, wanted):
        if not actual:
            return False
        for field_id, value in wanted.items():
            old = actual["fields"].get(field_id)
            if field_types.get(field_id) == "json_text":
                old = json.loads(old) if isinstance(old, str) and old else old
                value = json.loads(value) if isinstance(value, str) and value else value
            if comparable(old) != comparable(value):
                return False
        return True

    raw, existing = current_rows()
    wanted_ids = {r["values"][key] for r in desired}
    for prior_path in journal_path.parent.glob("*.json"):
        if prior_path == journal_path:
            continue
        prior = json.loads(prior_path.read_text(encoding="utf-8"))
        if (prior.get("file_id") != binding["file_id"] or prior.get("table") != logical
                or prior.get("status") not in {"pending", "unresolved"}
                or not wanted_ids.intersection(prior.get("business_ids", []))):
            continue
        expected = prior.get("desired", [])
        if expected and all(matches(existing.get(row["business_id"]), row["fields"]) for row in expected):
            prior.update(status="confirmed", confirmed=[row["business_id"] for row in expected])
            save_json(prior_path, prior)
        else:
            raise LedgerError("an earlier write for these records is unresolved; reconcile operation " +
                              str(prior.get("operation_id")) + " before starting a new one")
    creates, updates = [], []
    create_queue, update_queue = [], []
    create_sources = set()
    for record in desired:
        identity = record["values"][key]
        actual = existing.get(identity)
        if record["record_id"]:
            supplied = next((r for r in raw if r["id"] == record["record_id"]), None)
            if supplied is None or (actual and actual["id"] != supplied["id"]):
                raise LedgerError("explicit record_id is missing or conflicts with business ID")
            previous_id = supplied["fields"].get(table["fields"][key]["id"])
            if previous_id and previous_id != identity:
                raise LedgerError("cannot replace another record's business ID")
            actual = supplied
        if matches(actual, record["fields"]):
            continue
        if journal:
            raise LedgerError("previous operation is unresolved or has changed; reconcile before another write")
        # A source key identifies one extracted business object, not an entire screenshot.
        for other in raw:
            same_source = other["fields"].get(table["fields"]["source_key"]["id"]) == record["values"]["source_key"]
            same_transaction = (logical == "events" and record["values"].get("identity_key") and
                                other["fields"].get(table["fields"]["identity_key"]["id"]) == record["values"]["identity_key"])
            if same_transaction and (not actual or other["id"] != actual["id"]):
                raise LedgerError("source or transaction already exists; reuse and reconcile its business ID")
            if same_source and not actual:
                raise LedgerError("source or transaction already exists; reuse and reconcile its business ID")
        if actual:
            # 只提交发生变化的字段：全字段更新会触发服务端 400100 Internal error（实测），
            # 最小差异更新同时缩小请求面。None 仍以空字符串提交以清空单元格。
            changed = {}
            for fid, want in record["fields"].items():
                wire_value = want
                stored = actual["fields"].get(fid)
                if field_types.get(fid) == "json_text":
                    stored = json.loads(stored) if isinstance(stored, str) and stored else stored
                    want = json.loads(want) if isinstance(want, str) and want else want
                if comparable(stored) != comparable(want):
                    changed[fid] = "" if wire_value is None else wire_value
            if changed:
                updates.append({"id": actual["id"], "fields": changed})
                update_queue.append((record["values"][key], updates[-1]))
        else:
            if record["values"]["source_key"] in create_sources:
                raise LedgerError("source_key must identify one new business object, including its line/event")
            create_sources.add(record["values"]["source_key"])
            # Unknown cells on new records must be absent; this API rejects null
            # Number cells. Readback still compares an absent cell with null.
            creates.append({"fields": {k: v for k, v in record["fields"].items() if v is not None}})
            create_queue.append((record["values"][key], creates[-1]))
    journal = {"file_id": binding["file_id"], "table": logical, "fingerprint": fingerprint, "operation_id": operation_id,
               "status": "pending", "business_ids": [r["values"][key] for r in desired],
               "desired": [{"business_id": r["values"][key], "fields": r["fields"]} for r in desired]}
    save_json(journal_path, journal)
    error = None
    try:
        # A read immediately after a timeout cannot prove the first request has
        # stopped. Send each batch once, then reconcile; never replay missing rows
        # automatically while an earlier request may still be in flight.
        for action, queue in (("create-records", create_queue), ("update-records", update_queue)):
            if not queue:
                continue
            try:
                call("dbsheet", action, {"file_id": binding["file_id"], "sheet_id": table["sheet_id"],
                     "prefer_id": True, "value_prefer_id": False, "add_select_item": False,
                     "omit_failure": False, "records": [p for _, p in queue]})
            except (LedgerError, OSError) as failure:
                error = failure
            _, by_business_now = current_rows()
            if any(not matches(by_business_now.get(bid), payload["fields"]) for bid, payload in queue):
                error = error or LedgerError("write not fully visible; outcome remains unresolved")
                break
    except (LedgerError, OSError) as failure:
        error = failure
    _, after = current_rows()
    confirmed = [r["values"][key] for r in desired if matches(after.get(r["values"][key]), r["fields"])]
    journal.update(status="confirmed" if len(confirmed) == len(desired) else "unresolved", confirmed=confirmed)
    save_json(journal_path, journal)
    if journal["status"] != "confirmed":
        raise LedgerError("write unresolved; confirmed=" + json.dumps(confirmed, ensure_ascii=False) +
                          "; keep operation journal and reconcile before retrying" + ("; " + str(error) if error else ""))
    return {"saved": True, "confirmed": confirmed, "created": len(creates), "updated": len(updates)}


def sync_display(binding, binding_path, snapshot):
    """One-shot derived-value refresh: full read -> recompute -> write -> readback.

    Display caches and 关联商品 links are derived values with no financial
    semantics, so every run recomputes them from a fresh complete read; the
    operation journal still records what landed. Rows without a source_key
    are skipped and reported, not adopted silently. Link cells are only ever
    written with a derived nonempty value — clearing happens in the sheet UI.
    """
    report = workbench(snapshot)
    item_record_ids = snapshot.get("_record_ids", {}).get("items", {})
    purchase_by_id = {p["purchase_id"]: p for p in snapshot.get("purchases", [])}

    def item_link(item_id):
        record = item_record_ids.get(item_id)
        return [record] if record else None

    def task_item_id(task):
        if task.get("item_id"):
            return task["item_id"]
        if task.get("target_type") == "purchase":
            return purchase_by_id.get(task.get("target_id"), {}).get("item_id")
        if task.get("target_type") == "order_group":
            members = {p.get("item_id") for p in purchase_by_id.values()
                       if p.get("order_group_id") == task.get("target_id")}
            return members.pop() if len(members) == 1 and None not in members else None
        return None

    def linked(logical, item_id):
        # 链接只在绑定到真实 Link 展示字段且能唯一定位商品时写，其余留原状。
        if not binding["tables"][logical].get("display_fields", {}).get("关联商品") or not item_id:
            return {}
        link = item_link(item_id)
        return {"关联商品": link} if link else {}

    # items 只刷展示缓存；purchases/offers 的 关联商品 由 item 外键派生；
    # tasks 带 待付提示 加可派生的链接。整单多品的付款待办不指认单一商品。
    task_notes = {row["task_id"]: row["display"]["待付提示"] for row in report["tasks"]}
    passes = {"items": [(row["item_id"], row["display"]) for row in report["items"]],
              "purchases": [(row["purchase_id"], linked("purchases", row.get("item_id")))
                            for row in snapshot.get("purchases", [])],
              "offers": [(row["offer_id"], linked("offers", row.get("item_id")))
                         for row in snapshot.get("offers", [])],
              "tasks": [(row["task_id"], {**{"待付提示": task_notes.get(row["task_id"], "")},
                                           **linked("tasks", task_item_id(row))})
                        for row in snapshot.get("tasks", [])]}
    sources = {logical: {row.get(DEFINITIONS[logical]["business_key"]): row
                         for row in snapshot.get(logical, [])} for logical in passes}
    skipped = {logical: [] for logical in passes}
    operation_ids = {logical: [] for logical in passes}
    records_by_table = {}
    for logical, rows in passes.items():
        key = DEFINITIONS[logical]["business_key"]
        records = []
        for identity, display in rows:
            source = sources[logical].get(identity, {}).get("source_key")
            if not isinstance(source, str) or not source.strip():
                skipped[logical].append(identity)
            elif display:
                bound = binding["tables"][logical].get("display_fields", {})
                filtered = {name: value for name, value in display.items() if name in bound}
                if filtered:
                    records.append({"fields": {key: identity, "source_key": source}, "display": filtered})
        records_by_table[logical] = records
    applied = {logical: {"saved": False, "confirmed": [], "created": 0, "updated": 0}
               for logical in records_by_table if records_by_table[logical]}
    for logical, records in records_by_table.items():
        for index in range(0, len(records), 50):
            operation_id = "sync:%s:%s:%d" % (snapshot["read_at"], logical, index // 50 + 1)
            operation_ids[logical].append(operation_id)
            result = apply_records(binding, binding_path, {
                "table": logical, "operation_id": operation_id, "records": records[index:index + 50]})
            applied[logical]["saved"] = result["saved"]
            applied[logical]["confirmed"].extend(result["confirmed"])
            applied[logical]["created"] += result["created"]
            applied[logical]["updated"] += result["updated"]
    return {"synced": True, "read_at": snapshot["read_at"],
            "applied": applied, "skipped_no_source_key": skipped, "operation_ids": operation_ids,
            "summary": report["summary"], "reference_pricing": report["reference_pricing"],
            "spending_overview": report["spending_overview"],
            "missing_display_fields": {logical: [f["name"] for f in DISPLAY_FIELDS.get(logical, [])
                if f["type"] in {"MultiLineText", "Number", "SingleSelect", "Link", "OneWayLink"}
                and f["name"] not in {x["name"] for x in DEFINITIONS[logical]["fields"]}
                and f["name"] not in binding["tables"][logical].get("display_fields", {})]
                for logical in passes},
            "item_notes": [{"item_id": row["item_id"], "name": row["name"],
                            "assistant_notes": row["assistant_notes"]} for row in report["items"]]}


def execute_workflow(binding, binding_path, command, request):
    """Persist a fixed business plan, then resume its confirmed steps without replaying unknown writes."""
    from workflows import PLANNERS, merged_snapshot
    if not isinstance(request, dict):
        raise LedgerError("business operation input must be an object")
    operation_id = request.get("operation_id")
    if not isinstance(operation_id, str) or not operation_id.strip():
        raise LedgerError("business operations require a stable operation_id")
    fingerprint = hashlib.sha256(json.dumps({"command": command, "request": request},
                                            sort_keys=True, ensure_ascii=False).encode()).hexdigest()
    path = Path(binding_path).parent / "transactions" / (hashlib.sha256(operation_id.encode()).hexdigest() + ".json")
    if path.exists():
        transaction = json.loads(path.read_text(encoding="utf-8"))
        if transaction["fingerprint"] != fingerprint or transaction["file_id"] != binding["file_id"]:
            raise LedgerError("operation_id was already used for a different business operation")
        operation = transaction["plan"]
        if transaction.get("status") == "confirmed":
            current = workbench(read_snapshot(binding))
            return {"saved": True, "already_processed": True, "operation_id": operation_id,
                    "confirmed_steps": transaction["confirmed_steps"], "notes": {"already_processed": True},
                    "spending_overview": current["spending_overview"], "display": {"unchanged": True}}
    else:
        try:
            source = read_snapshot(binding)
        except LedgerError as error:
            if not str(error).startswith("items: nonempty record needs business ID"):
                raise
            repair = repair_items(binding, binding_path)
            if repair["needs_input"]:
                raise LedgerError("named shopping rows need quantity before import: " +
                                  json.dumps(repair["needs_input"], ensure_ascii=False)) from None
            source = read_snapshot(binding)
        operation = PLANNERS[command](source, request)
        for batch in operation["batches"]:
            allowed = {f["key"] for f in DEFINITIONS[batch["table"]]["fields"]}
            for record in batch["records"]:
                record["fields"] = {k: v for k, v in record["fields"].items() if k in allowed}
        workbench(merged_snapshot(source, operation))
        transaction = {"file_id": binding["file_id"], "operation_id": operation_id,
                       "fingerprint": fingerprint, "plan": operation, "confirmed_steps": [], "status": "pending"}
        save_json(path, transaction)
    for batch in operation["batches"]:
        if batch["operation_id"] in transaction["confirmed_steps"]:
            continue
        # Re-entering a sub-operation only reconciles its previous journal. It
        # never creates a new id to bypass a pending request.
        result = apply_records(binding, binding_path, batch)
        if batch["operation_id"] not in transaction["confirmed_steps"]:
            transaction["confirmed_steps"].append(batch["operation_id"])
        save_json(path, transaction)
    transaction["status"] = "confirmed"
    save_json(path, transaction)
    current = read_snapshot(binding)
    report = workbench(current)
    result = {"saved": True, "operation_id": operation_id, "confirmed_steps": transaction["confirmed_steps"],
              "notes": operation["notes"], "spending_overview": report["spending_overview"]}
    try:
        result["display"] = sync_display(binding, binding_path, current)
    except (LedgerError, OSError) as error:
        # The business data is already confirmed; an optional display failure
        # must not make the caller repeat the purchase or payment.
        result["display"] = {"synced": False, "error": str(error), "recovery": "run sync after resolving the display operation"}
    return result


def repair_items(binding, binding_path):
    """Adopt existing named rows in place; never invent a missing quantity or purchase."""
    from shopping import positive
    from workflows import stable_id
    verify_binding(binding, get_schema(binding["file_id"]))
    table = binding["tables"]["items"]
    records, pending = [], []
    for raw in list_records(binding["file_id"], table["sheet_id"]):
        row = logical_fields("items", raw, binding)
        if not row.get("name") or (row.get("item_id") and row.get("source_key")):
            continue
        try:
            positive(row.get("planned_quantity"), "planned_quantity")
        except ValueError:
            pending.append({"record_id": raw["id"], "name": row["name"], "missing": "quantity"})
            continue
        source = "manual:" + binding["file_id"] + ":" + raw["id"]
        records.append({"record_id": raw["id"], "fields": {"item_id": row.get("item_id") or stable_id("item", source),
                        "source_key": row.get("source_key") or source}})
    confirmed = []
    for offset in range(0, len(records), 50):
        chunk = records[offset:offset + 50]
        digest = hashlib.sha256(json.dumps(chunk, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
        result = apply_records(binding, binding_path, {"operation_id": "repair:" + digest, "table": "items", "records": chunk})
        confirmed.extend(result["confirmed"])
    return {"repaired": confirmed, "needs_input": pending}


def field_payload(field):
    payload = {k: v for k, v in field.items() if k not in {"key", "logical_type", "suggested_cli_type", "suggested_options"}}
    payload["type"] = field["suggested_cli_type"]
    if field.get("suggested_options"):
        payload["items"] = [{"value": value} for value in field["suggested_options"]]
    return payload


def setup_ledger(binding_path, file_id=None, name=None, backend_info=None):
    """Add missing template resources, reuse old amount-field IDs, and bind the result."""
    from presentation import compile_views
    state_path = Path(str(binding_path) + ".setup.json")
    state = json.loads(state_path.read_text(encoding="utf-8")) if state_path.exists() else {}
    previous = json.loads(Path(binding_path).read_text(encoding="utf-8")) if Path(binding_path).exists() else {}
    file_id = file_id or previous.get("file_id") or state.get("file_id")
    if previous.get("file_id") and file_id != previous["file_id"]:
        raise LedgerError("binding points to another file; use another binding path")
    if not file_id:
        if state.get("pending"):
            raise LedgerError("file creation outcome is unknown; locate the created file and supply --file-id")
        if not name:
            raise LedgerError("setup needs --file-id for an existing ledger or --name for a new one")
        state = {"pending": {"service": "drive", "action": "create-empty-file", "name": name}}
        save_json(state_path, state)
        created = call("drive", "create-empty-file", {"name": name, "file_extension": "dbt"})
        file_id = str(created.get("id") or created.get("file_id") or "")
        if not file_id:
            raise LedgerError("created file response has no ID; reconcile before creating another file")
        state = {"file_id": file_id}
        save_json(state_path, state)
    schema = get_schema(file_id)
    pending = state.get("pending")
    if pending:
        payload = pending.get("payload", {})
        sheet = next((s for s in schema["sheets"] if s["id"] == payload.get("sheet_id")), None)
        action = pending.get("action")
        resolved = action == "create-empty-file" and bool(file_id)
        resolved = resolved or (action == "create-sheet" and any(s["name"] == payload.get("name") for s in schema["sheets"]))
        resolved = resolved or (action == "create-fields" and sheet and all(
            any(f["name"] == field["name"] for f in sheet["fields"]) for field in payload.get("fields", [])))
        resolved = resolved or (action == "create-view" and sheet and any(
            v["name"] == payload.get("name") for v in sheet.get("views", [])))
        if not resolved:
            raise LedgerError("previous setup action is unresolved; inspect its saved request before continuing")
    state = {"file_id": str(file_id), "model_version": MODEL_VERSION}
    save_json(state_path, state)

    def write(action, payload):
        state["pending"] = {"action": action, "payload": payload}
        save_json(state_path, state)
        result = call("dbsheet", action, payload)
        state.pop("pending", None)
        save_json(state_path, state)
        return result

    mapping = {}
    for definition in TABLES:
        logical = definition["logical_name"]
        schema = get_schema(file_id)
        previous_table = previous.get("tables", {}).get(logical, {})
        matches = [s for s in schema["sheets"] if s["id"] == previous_table.get("sheet_id")]
        if not matches:
            matches = [s for s in schema["sheets"] if s["name"] == definition["name"]]
        if len(matches) > 1:
            raise LedgerError("ambiguous table: " + definition["name"])
        if not matches:
            write("create-sheet", {"file_id": file_id, "name": definition["name"],
                  "fields": [field_payload(f) for f in definition["fields"]],
                  "views": [{"name": "默认视图", "type": "grid"}]})
            schema = get_schema(file_id)
            matches = [s for s in schema["sheets"] if s["name"] == definition["name"]]
        if len(matches) != 1:
            raise LedgerError("new table not visible; reconcile setup before retrying")
        sheet = matches[0]
        mapping[logical] = {"sheet_id": sheet["id"], "fields": {}}
        missing = []
        for field in definition["fields"]:
            old_id = previous_table.get("fields", {}).get(field["key"], {}).get("id")
            candidates = [f for f in sheet["fields"] if f["id"] == old_id] if old_id else []
            if not candidates:
                names = {field["name"], *FIELD_ALIASES.get(logical, {}).get(field["key"], ())}
                candidates = [f for f in sheet["fields"] if f["name"] in names]
            if len(candidates) > 1:
                raise LedgerError("ambiguous field: " + field["name"])
            if candidates:
                if candidates[0]["type"] != field["suggested_cli_type"]:
                    raise LedgerError("field type needs explicit migration: " + field["name"])
                mapping[logical]["fields"][field["key"]] = candidates[0]["id"]
                if (candidates[0]["name"] in FIELD_ALIASES.get(logical, {}).get(field["key"], ())
                        and not any(f["name"] == field["name"] for f in sheet["fields"])):
                    write("update-fields", {"file_id": file_id, "sheet_id": sheet["id"],
                          "fields": [{"id": candidates[0]["id"], "name": field["name"]}]})
            else:
                missing.append(field_payload(field))
        if missing:
            write("create-fields", {"file_id": file_id, "sheet_id": sheet["id"], "fields": missing})
        for canonical, aliases in DISPLAY_ALIASES.get(logical, {}).items():
            if any(f["name"] == canonical for f in sheet["fields"]):
                continue
            legacy = [f for f in sheet["fields"] if f["name"] in aliases]
            if len(legacy) > 1:
                raise LedgerError("ambiguous old amount columns; select the intended field before migration")
            if legacy:
                if legacy[0]["type"] != "Number":
                    raise LedgerError("old amount field has an incompatible type; inspect it before migration")
                write("update-fields", {"file_id": file_id, "sheet_id": sheet["id"],
                      "fields": [{"id": legacy[0]["id"], "name": canonical}]})
    for _ in range(5):
        schema = get_schema(file_id)
        compile_schema = json.loads(json.dumps(schema))
        for definition in TABLES:
            next(s for s in compile_schema["sheets"] if s["id"] == mapping[definition["logical_name"]]["sheet_id"])["name"] = definition["name"]
        compiled = compile_views(compile_schema, file_id)
        creates = [r for r in compiled["requests"] if r["action"] in {"create-fields", "create-view"}]
        if creates:
            for request in creates:
                write(request["action"], request["payload"])
            continue
        if compiled["limitations"]:
            raise LedgerError("presentation needs review: " + json.dumps(compiled["limitations"], ensure_ascii=False))
        for request in compiled["requests"]:
            write(request["action"], request["payload"])
        break
    else:
        raise LedgerError("setup did not converge; inspect schema before continuing")
    binding = make_binding(get_schema(file_id), file_id, mapping)
    attach_backend(binding, backend_info or {"cli": cli_name(), "version": cli_version(cli_name())})
    save_json(binding_path, binding)
    state["status"] = "confirmed"
    save_json(state_path, state)
    return {"ready": True, "file_id": file_id, "model_version": MODEL_VERSION,
            "tables": len(TABLES), "data_deleted": False, "page_verified": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("doctor")
    commands.add_parser("ledgers")
    bootstrap = commands.add_parser("bootstrap", help="install the bundled dbsheet dependency when both CLIs are missing")
    bootstrap.add_argument("--install-skill", action="store_true", help="also install the official dependency Skill when a CLI already exists")
    bootstrap.add_argument("--skills-dir", help="override the dependency Skill installation directory")
    bootstrap.add_argument("--bin-dir", help="override the CLI installation directory")
    bind = commands.add_parser("bind")
    bind.add_argument("--file-id", required=True)
    bind.add_argument("--mapping", help="optional explicit logical-table/field mapping JSON")
    setup = commands.add_parser("setup")
    setup.add_argument("--binding", required=True)
    setup.add_argument("--file-id", help="reuse and additively upgrade an existing ledger")
    setup.add_argument("--name", help="create a new ledger only when no existing binding/file ID is supplied")
    business = ("import-cart", "record-purchase", "record-refund", "set-intent")
    for name in ("bind", "read", "apply", "sync", "repair", "overview", *business):
        command = bind if name == "bind" else commands.add_parser(name)
        command.add_argument("--binding", required=name == "bind", help="manifest path; otherwise resolve the workspace or sole registered ledger")
        if name in ("read", "sync"):
            command.add_argument("--page-size", type=int, default=100, choices=range(1, 1001), metavar="1..1000")
        if name == "read":
            command.add_argument("--out", required=True)
        if name == "sync":
            command.add_argument("--out", help="optional path to save the complete snapshot used for the sync")
        if name == "apply" or name in business:
            command.add_argument("--input", required=True)
        if name in business:
            command.add_argument("--preview", action="store_true", help="validate and show the business plan without writing")
    args = parser.parse_args()
    try:
        if args.command == "bootstrap":
            from bootstrap import bootstrap_environment
            print(json.dumps(bootstrap_environment(args.skills_dir, args.bin_dir, args.install_skill), ensure_ascii=False))
            return 0
        if args.command == "ledgers":
            print(json.dumps({"ledgers": known_ledgers()}, ensure_ascii=False))
            return 0
        name = cli_name()
        with cli_session(name):
            info = inspect_cli(name)
            if args.command == "doctor":
                print(json.dumps(info, ensure_ascii=False))
                return 0 if info["ready"]["read"] else 2
            return run_command(args, business, info)
    except (ValueError, OSError, KeyError, TypeError, subprocess.SubprocessError) as error:
        print(json.dumps({"error": str(error)}, ensure_ascii=False), file=sys.stderr)
        return 2


def run_command(args, business, info):
    """Keep one inspected transport for the whole command, including readback."""
    binding_path = resolve_binding(args.binding)
    if binding_path.is_relative_to(ROOT):
        raise LedgerError("store user binding and journals outside the skill package")
    group = "read" if args.command in {"bind", "read", "overview"} else "write"
    if args.command == "setup":
        state_path = Path(str(binding_path) + ".setup.json")
        prior = json.loads(binding_path.read_text(encoding="utf-8")) if binding_path.exists() else {}
        state = json.loads(state_path.read_text(encoding="utf-8")) if state_path.exists() else {}
        group = "setup" if args.file_id or prior.get("file_id") or state.get("file_id") else "create"
    require_capability(info, group)
    with writer_lock(binding_path):
        if args.command == "setup":
            result = setup_ledger(binding_path, args.file_id, args.name, info)
            remember_binding(binding_path, json.loads(binding_path.read_text(encoding="utf-8")))
        elif args.command == "bind":
            if binding_path.exists():
                old = json.loads(binding_path.read_text(encoding="utf-8"))
                if old["file_id"] != args.file_id:
                    raise LedgerError("binding already points to another file; use a different manifest path")
            mapping = json.loads(Path(args.mapping).read_text(encoding="utf-8")) if args.mapping else None
            binding = make_binding(get_schema(args.file_id), args.file_id, mapping)
            attach_backend(binding, info)
            save_json(binding_path, binding)
            remember_binding(binding_path, binding)
            result = {"bound": True, "file_id": args.file_id, "tables": len(binding["tables"])}
        else:
            binding = json.loads(binding_path.read_text(encoding="utf-8"))
            if (binding.get("cli") != info["cli"] or binding.get("cli_version") != info["version"]
                    or binding.get("backend_contract") != CONTRACT):
                verify_binding(binding, get_schema(binding["file_id"]))
                attach_backend(binding, info)
                save_json(binding_path, binding)
            if args.command == "read":
                snapshot = read_snapshot(binding, args.page_size)
                save_json(Path(args.out), snapshot)
                result = {"read_complete": True, "out": str(Path(args.out).resolve())}
            elif args.command == "sync":
                snapshot = read_snapshot(binding, args.page_size)
                if args.out:
                    save_json(Path(args.out), snapshot)
                result = sync_display(binding, binding_path, snapshot)
            elif args.command == "repair":
                result = repair_items(binding, binding_path)
            elif args.command == "overview":
                result = workbench(read_snapshot(binding))["spending_overview"]
            elif args.command in business:
                request = json.loads(Path(args.input).read_text(encoding="utf-8"))
                if args.preview:
                    from workflows import PLANNERS, merged_snapshot
                    current = read_snapshot(binding)
                    operation = PLANNERS[args.command](current, request)
                    result = {"preview": True, "plan": operation,
                              "spending_overview": workbench(merged_snapshot(current, operation))["spending_overview"]}
                else:
                    result = execute_workflow(binding, binding_path, args.command, request)
            else:
                result = apply_records(binding, binding_path, json.loads(Path(args.input).read_text(encoding="utf-8")))
    print(json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
