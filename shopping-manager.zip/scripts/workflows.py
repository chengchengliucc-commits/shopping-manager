#!/usr/bin/env python3
"""Pure business-operation planners. Browser/OCR extraction stays with the Agent."""
import copy
from datetime import datetime
from decimal import Decimal
import hashlib
import json

from shopping import DISPLAY_LABELS, InputError, budget, fen, fulfilled_by_item, id_list, intent_active, option, positive, snapshot, text

SPEC_FIELDS = ("category", "brand", "color", "memory", "storage", "size", "pack_spec", "spec_notes")
BUSINESS_KEYS = {"items": "item_id", "offers": "offer_id", "purchases": "purchase_id",
                 "events": "event_id", "tasks": "task_id"}


def stable_id(kind, source):
    return kind + "-" + hashlib.sha256(source.encode()).hexdigest()[:24]


def details(value):
    if value in (None, ""):
        return {}
    if isinstance(value, str):
        value = json.loads(value)
    if not isinstance(value, dict):
        raise InputError("details_json must be an object")
    return copy.deepcopy(value)


def quantity(value):
    number = positive(value, "quantity")
    return int(number) if number == number.to_integral_value() else float(number)


def timestamp(value):
    value = text(value, "captured_at")
    try:
        result = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        raise InputError("captured_at must be an ISO timestamp with timezone") from None
    if result.tzinfo is None:
        raise InputError("captured_at needs a timezone")
    return result


def normalized_option(table, field, value):
    labels = DISPLAY_LABELS[table][field]
    reverse = {label: token for token, label in labels.items()}
    return option(reverse.get(value, value), set(labels), table + "." + field)


def plan(request, records, notes=None):
    operation_id = text(request.get("operation_id"), "operation_id")
    batches = []
    for table in ("items", "offers", "purchases", "events", "tasks"):
        identities = [record["fields"][BUSINESS_KEYS[table]] for record in records.get(table, [])]
        if len(identities) != len(set(identities)):
            raise InputError("duplicate " + BUSINESS_KEYS[table] + " in business operation")
        for offset in range(0, len(records.get(table, [])), 50):
            batches.append({"table": table, "operation_id": operation_id + ":" + table + ":" + str(offset // 50 + 1),
                            "records": records[table][offset:offset + 50]})
    return {"operation_id": operation_id, "batches": batches, "notes": notes or {}}


def merged_snapshot(data, operation):
    """Validate the complete proposed business state before the first write."""
    result = copy.deepcopy(data)
    for batch in operation["batches"]:
        table, key = batch["table"], BUSINESS_KEYS[batch["table"]]
        rows = {row[key]: row for row in result.get(table, [])}
        for record in batch["records"]:
            fields = record["fields"]
            rows[fields[key]] = {**rows.get(fields[key], {}), **fields}
        result[table] = list(rows.values())
    return result


def cart(data, request):
    items, purchases, *_ = snapshot(data)
    fulfilled = fulfilled_by_item(purchases)
    platform = text(request.get("platform"), "platform")
    cart_id = text(request.get("cart_id", platform), "cart_id")
    captured_at = request.get("captured_at")
    captured = timestamp(captured_at)
    lines = request.get("items")
    if not isinstance(lines, list) or any(not isinstance(row, dict) for row in lines):
        raise InputError("cart.items must be an array of normalized rows")
    if not isinstance(request.get("complete", False), bool):
        raise InputError("cart.complete must be a boolean")
    offers = data.get("offers", [])
    proposed_items, proposed_offers, seen = {}, {}, set()
    for row in lines:
        source_item = text(row.get("source_item_id", row.get("sku")), "source_item_id or sku")
        source = "cart:" + cart_id + ":" + source_item
        if source in seen:
            raise InputError("duplicate cart source row: " + source_item)
        seen.add(source)
        existing = [offer for offer in offers if offer.get("source_key") == source]
        if len(existing) > 1:
            raise InputError("cart source maps to multiple offers; reconcile before importing")
        previous = existing[0] if existing else {}
        previous_capture = details(previous.get("details_json")).get("captured_at") or previous.get("evidence_at")
        if previous_capture and captured < timestamp(previous_capture):
            raise InputError("older cart observation cannot overwrite a newer one")
        item_id = row.get("item_id") or previous.get("item_id")
        if item_id and item_id not in items:
            raise InputError("explicit cart item_id is missing from the ledger")
        old_item = proposed_items.get(item_id, items.get(item_id, {})) if item_id else {}
        if not item_id:
            candidates = [item for item in items.values() if item.get("source_key") == source + "#intent"]
            if len(candidates) > 1:
                raise InputError("cart source maps to multiple shopping intents")
            old_item = candidates[0] if candidates else {}
            item_id = old_item.get("item_id") or stable_id("item", source + "#intent")
        name = text(row.get("name") or old_item.get("name"), "cart.name")
        count = quantity(row.get("quantity"))
        meta = details(old_item.get("details_json"))
        observations = meta.setdefault("cart_observations", {})
        if not isinstance(observations, dict):
            raise InputError("cart_observations must be an object")
        observations[source] = {"quantity": count, "captured_at": captured_at}
        owner = meta.get("quantity_source_key")
        if row.get("item_id") and not previous and "quantity_mode" not in row:
            raise InputError("linking a new cart source to an item needs quantity_mode=remaining or candidate")
        mode = row.get("quantity_mode", "candidate" if (owner and owner != source) or
                       (row.get("item_id") and not previous) else "remaining")
        option(mode, {"remaining", "candidate"}, "quantity_mode")
        if mode == "remaining":
            meta["quantity_source_key"] = source
            planned = quantity(fulfilled.get(item_id, Decimal(0)) + Decimal(str(count)))
        else:
            planned = old_item.get("planned_quantity", count)
        if row.get("intent_status") is not None:
            meta["intent_status"] = option(row["intent_status"], {"active", "paused", "dropped"}, "intent_status")
        elif "intent_status" not in meta:
            meta["intent_status"] = "active" if not old_item.get("not_bought_reason") else "dropped"
        item = {**old_item, "item_id": item_id, "name": name, "planned_quantity": planned,
                "source_key": old_item.get("source_key") or source + "#intent", "details_json": meta}
        for key in (*SPEC_FIELDS, "unit", "item_type"):
            if key in row:
                item[key] = row[key]
        proposed_items[item_id] = item
        offer_meta = details(previous.get("details_json"))
        offer_meta.update(details(row.get("details_json")))
        offer_meta.update(captured_at=captured_at, source_kind="cart")
        if row.get("unit_price_fen") is not None:
            offer_meta.update(quantity_pricing="linear", unit_price_fen=fen(row["unit_price_fen"], "unit_price_fen", False))
        offer = {**previous, "offer_id": previous.get("offer_id") or stable_id("offer", source),
                 "item_id": item_id, "name": name, "platform": platform, "sku": row.get("sku", source_item),
                 "quantity": count, "basis": row.get("basis", "item_price"),
                 "base_fen": fen(row.get("price_fen"), "price_fen"),
                 "shipping_fen": fen(row.get("shipping_fen"), "shipping_fen"),
                 "verification_status": "PAGE_DISPLAYED", "source_key": source,
                 "evidence_at": captured_at, "details_json": offer_meta}
        for key in (*SPEC_FIELDS, "seller", "source_url", "condition", "promotions_json"):
            if key in row:
                offer[key] = row[key]
        proposed_offers[offer["offer_id"]] = offer
    removed = [{"item_id": offer.get("item_id"), "name": offer.get("name"), "source_key": offer["source_key"]}
               for offer in offers if request.get("complete") is True and
               str(offer.get("source_key", "")).startswith("cart:" + cart_id + ":") and offer["source_key"] not in seen
               and offer.get("item_id") in items and intent_active(items[offer["item_id"]])
               and positive(items[offer["item_id"]]["planned_quantity"], "planned_quantity") > fulfilled.get(offer["item_id"], 0)]
    return plan(request, {"items": [{"fields": row} for row in proposed_items.values()],
                          "offers": [{"fields": row} for row in proposed_offers.values()]},
                {"observed_rows": len(lines), "removed_from_cart_needs_decision": removed})


def purchase(data, request):
    items, existing_purchases, existing_events, existing_tasks, *_ = snapshot(data)
    source = text(request.get("source_key"), "source_key")
    lines = request.get("purchases")
    if lines is None:
        lines = [request]
    if not isinstance(lines, list) or not lines or any(not isinstance(row, dict) for row in lines):
        raise InputError("purchases must contain at least one purchase row")
    order_no = request.get("order_no")
    existing_groups = {existing_purchases[line["purchase_id"]]["order_group_id"] for line in lines
                       if line.get("purchase_id") in existing_purchases}
    if len(existing_groups) > 1 and not request.get("order_group_id"):
        raise InputError("purchase updates span different orders; identify the order explicitly")
    group = request.get("order_group_id") or (next(iter(existing_groups)) if existing_groups else
            stable_id("order", str(request.get("platform", "")) + ":" + str(order_no or source)))
    payment = request.get("payment")
    if payment is None and request.get("paid_fen") is not None:
        payment = {"amount_fen": request["paid_fen"], "identity_key": request.get("payment_identity")}
    if payment is not None and not isinstance(payment, dict):
        raise InputError("payment must be an object")
    paid = fen(payment.get("amount_fen"), "payment.amount_fen") if payment else None
    complete = request.get("payment_complete", False)
    if not isinstance(complete, bool):
        raise InputError("payment_complete must be a boolean")
    if complete and not payment:
        raise InputError("payment_complete requires a recorded payment")
    remaining = fen(request.get("remaining_fen"), "remaining_fen")
    if remaining == 0 and payment:
        complete = True
    if complete and remaining not in (None, 0):
        raise InputError("payment_complete conflicts with remaining_fen")
    records = {name: [] for name in BUSINESS_KEYS}
    purchases = []
    for index, line in enumerate(lines):
        line_source = text(line.get("purchase_source_key", source + "#line:" + str(line.get("source_item_id", index + 1))), "purchase_source_key")
        pid = line.get("purchase_id") or stable_id("purchase", line_source)
        previous = existing_purchases.get(pid, {})
        iid = line.get("item_id") or previous.get("item_id")
        if iid and iid not in items:
            raise InputError("purchase item_id is missing; omit it to create a new item")
        count = quantity(line.get("quantity", previous.get("quantity")))
        name = line.get("name") or previous.get("name") or items.get(iid, {}).get("name")
        name = text(name, "purchase.name")
        if not iid:
            iid = stable_id("item", line_source + "#intent")
            if iid not in items:
                item = {"item_id": iid, "name": name, "planned_quantity": count,
                        "source_key": line_source + "#intent", "details_json": {"intent_status": "active"}}
                item.update({key: line[key] for key in (*SPEC_FIELDS, "unit") if key in line})
                records["items"].append({"fields": item})
        meta = details(previous.get("details_json"))
        meta.update(details(line.get("details_json")))
        if complete:
            meta["payment_complete"] = True
        row = {**previous, "purchase_id": pid, "item_id": iid, "order_group_id": group, "name": name,
               "quantity": count, "order_status": normalized_option("purchases", "order_status", line.get("order_status", previous.get("order_status", "ordered"))),
               "source_key": previous.get("source_key") or line_source, "details_json": meta}
        for key in ("platform", "retained_quantity", "offer_id"):
            if key in line:
                row[key] = line[key]
        if request.get("platform"):
            row["platform"] = request["platform"]
        records["purchases"].append({"fields": row})
        purchases.append(row)
    member_ids = {p["purchase_id"] for p in existing_purchases.values() if p["order_group_id"] == group} | {p["purchase_id"] for p in purchases}
    target_type, target_id = ("purchase", purchases[0]["purchase_id"]) if len(member_ids) == 1 else ("order_group", group)
    task_id = None
    if payment:
        identity = payment.get("identity_key")
        known_events = [e for e in existing_events.values() if identity and e.get("identity_key") == identity]
        if len(known_events) > 1:
            raise InputError("payment identity is ambiguous")
        event_id = payment.get("event_id") or stable_id("event", source + "#payment")
        previous_event = known_events[0] if known_events else existing_events.get(event_id, {})
        if previous_event and (previous_event["kind"], previous_event["target_type"], previous_event["target_id"], previous_event.get("amount_fen")) != (
                "payment", target_type, target_id, paid):
            raise InputError("existing payment has a different amount or target; reconcile it explicitly")
        event = {**previous_event, "event_id": previous_event.get("event_id") or payment.get("event_id") or stable_id("event", source + "#payment"),
                 "kind": "payment", "status": "confirmed", "amount_fen": paid, "target_type": target_type, "target_id": target_id,
                 "source_key": previous_event.get("source_key") or source + "#payment", "order_no": order_no,
                 "occurred_at": payment.get("occurred_at", request.get("occurred_at"))}
        if identity:
            event["identity_key"] = identity
        records["events"].append({"fields": event})
        stages = {t["task_id"]: t for t in budget(data)["payment_tasks"]
                  if (t["target_type"], t["target_id"]) == (target_type, target_id)}
        linked = [t for t in existing_tasks.values() if event["event_id"] in id_list(t.get("payment_event_ids"), "payment_event_ids")]
        task_id = payment.get("task_id")
        if not task_id and linked:
            task_id = linked[0]["task_id"]
        if not task_id and not previous_event:
            matches = [tid for tid, t in stages.items() if t["status"] == "active" and
                       paid is not None and t["remaining_fen"] == paid]
            if len(matches) > 1:
                raise InputError("payment matches several stages; identify payment.task_id")
            task_id = matches[0] if matches else None
        if task_id:
            stage = stages.get(task_id)
            if not stage:
                raise InputError("payment.task_id must identify a non-cancelled payment stage with the same target")
            task = copy.deepcopy(existing_tasks[task_id])
            refs = id_list(task.get("payment_event_ids"), "payment_event_ids")
            if event["event_id"] not in refs:
                due = stage["remaining_fen"]
                if due is None or paid is None or paid > due:
                    raise InputError("stage payment needs a known amount no greater than the outstanding stage")
                if remaining is not None and remaining != due - paid:
                    raise InputError("remaining_fen conflicts with the selected payment stage")
                refs.append(event["event_id"])
                task.update(payment_event_ids=refs, status="paid" if paid == due else "active")
                records["tasks"].append({"fields": task})
        elif complete and any(t["remaining_fen"] != 0 for t in stages.values()):
            raise InputError("full settlement conflicts with an unpaid stage; identify payment.task_id or reconcile it")
        if not task_id and remaining is not None and remaining > 0:
            records["tasks"].append({"fields": {"task_id": stable_id("task", source + "#deposit"), "name": name + "已付阶段",
                "source_key": source + "#deposit", "target_type": target_type, "target_id": target_id,
                "kind": "deposit", "status": "paid", "amount_fen": paid, "payment_event_ids": [event["event_id"]]}})
    if remaining is not None and remaining > 0 and not task_id:
        records["tasks"].append({"fields": {"task_id": stable_id("task", source + "#balance"), "name": name + "待付尾款",
            "source_key": source + "#balance", "target_type": target_type, "target_id": target_id,
            "kind": "balance", "status": "active", "amount_fen": remaining, "payment_event_ids": [],
            "due_at": request.get("due_at"), "time_source": request.get("time_source")}})
    return plan(request, records, {"purchase_rows": len(purchases), "payment_recorded": bool(payment), "payment_complete": complete})


def refund(data, request):
    _, purchases, events, _, groups, *_ = snapshot(data)
    source = text(request.get("source_key"), "source_key")
    target_type = option(request.get("target_type", "purchase"), {"purchase", "order_group"}, "target_type")
    target_id = request.get("target_id", request.get("purchase_id"))
    if target_id not in (purchases if target_type == "purchase" else groups):
        raise InputError("refund target is missing")
    identity = request.get("identity_key")
    event_id = request.get("event_id") or stable_id("event", source)
    matches = [e for e in events.values() if (identity and e.get("identity_key") == identity) or e["event_id"] == event_id]
    if len(matches) > 1:
        raise InputError("refund identity is ambiguous")
    old = matches[0] if matches else {}
    if old and (old["kind"], old["target_type"], old["target_id"]) != ("refund", target_type, target_id):
        raise InputError("refund cannot replace another transaction")
    status = normalized_option("events", "status", request.get("status", "pending"))
    amount = fen(request.get("amount_fen", old.get("amount_fen")), "refund.amount_fen")
    if old.get("status") == "confirmed" and (status != "confirmed" or amount != old.get("amount_fen")):
        raise InputError("confirmed refund corrections require an explicit reversal or replacement")
    event = {**old, "event_id": old.get("event_id") or request.get("event_id") or stable_id("event", source),
             "source_key": old.get("source_key") or source, "kind": "refund", "status": status,
             "target_type": target_type, "target_id": target_id, "amount_fen": amount,
             "order_no": request.get("order_no", old.get("order_no")), "occurred_at": request.get("occurred_at", old.get("occurred_at"))}
    if identity:
        event["identity_key"] = identity
    records = {"events": [{"fields": event}]}
    if "retained_quantity" in request:
        if target_type != "purchase":
            raise InputError("returned quantity must identify a purchase row")
        row = copy.deepcopy(purchases[target_id]); row["retained_quantity"] = request["retained_quantity"]
        records["purchases"] = [{"fields": row}]
    return plan(request, records, {"refund_status": status})


def decision(data, request):
    items, *_ = snapshot(data)
    item_id = request.get("item_id")
    if item_id not in items:
        raise InputError("item_id is missing")
    row = copy.deepcopy(items[item_id]); meta = details(row.get("details_json"))
    meta["intent_status"] = option(request.get("intent_status"), {"active", "paused", "dropped"}, "intent_status")
    row["details_json"] = meta
    if "reason" in request:
        row["not_bought_reason"] = request["reason"]
    return plan(request, {"items": [{"fields": row}]})


PLANNERS = {"import-cart": cart, "record-purchase": purchase, "record-refund": refund, "set-intent": decision}
