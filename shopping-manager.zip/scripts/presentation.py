#!/usr/bin/env python3
"""Compile user-facing view requests from real schema; never executes remote calls."""
import argparse
import json
import sys
from pathlib import Path

from ledger import unwrap

ROOT = Path(__file__).resolve().parents[1]


def compile_views(raw, file_id):
    schema = unwrap(raw)
    sheets = schema.get("detail", schema).get("sheets")
    if not isinstance(sheets, list):
        raise ValueError("provide a real get-schema response containing sheets")
    template = json.loads((ROOT / "assets/schema.json").read_text(encoding="utf-8"))
    policy = json.loads((ROOT / "assets/presentation.json").read_text(encoding="utf-8"))
    requests, limitations = [], []
    by_name = {s["name"]: s for s in sheets}
    for table in template["tables"]:
        if table["name"] not in by_name:
            limitations.append("missing_table:" + table["name"])
            continue
        sheet = by_name[table["name"]]
        view_policy = policy["tables"][table["logical_name"]]
        field_names = [f["name"] for f in sheet["fields"]]
        names = {f["key"]: f["name"] for f in table["fields"] if f["name"] in field_names}
        # Bind legacy names without renaming unrelated user columns.
        for key, aliases in {"name": ["需求名称"],
                             "status": ["确认状态", "到账支付状态", "待办状态"],
                             "planned_quantity": ["数量", "计划数量"],
                             "unit": ["单位", "数量单位"]}.items():
            if key not in names:
                for alias in aliases:
                    if alias in field_names:
                        names[key] = alias
                        break
        missing_display = []
        for definition in policy.get("display_fields", {}).get(table["logical_name"], []):
            if definition["name"] in field_names:
                continue
            payload = {k: v for k, v in definition.items()
                       if k not in {"source_key", "link_table", "labels", "hidden"}}
            if definition["type"] == "Formula":
                source = names.get(definition["source_key"])
                if not source:
                    limitations.append("missing_money_source:" + table["name"] + ":" + definition["source_key"])
                    continue
                if definition.get("labels"):
                    expression = '[' + source + ']'
                    for token, label in reversed(list(definition["labels"].items())):
                        expression = 'IF([' + source + ']="' + token + '","' + label + '",' + expression + ')'
                    payload["formula"] = '=IF(ISBLANK([' + source + ']),"",' + expression + ')'
                else:
                    payload["formula"] = '=IF(ISBLANK([' + source + ']),"",[' + source + ']/100)'
            elif definition["type"] == "Link":
                target = next(t for t in template["tables"] if t["logical_name"] == definition["link_table"])
                target_sheet = by_name.get(target["name"])
                if not target_sheet:
                    limitations.append("missing_link_target:" + target["name"])
                    continue
                payload.update(linkSheet=target_sheet["id"], isAuto=False, multipleLinks=False)
            missing_display.append(payload)
        if missing_display:
            requests.append({"service": "dbsheet", "action": "create-fields", "payload": {
                "file_id": file_id, "sheet_id": sheet["id"], "fields": missing_display}})
            limitations.append("recompile_after_display_fields:" + table["name"])
            continue
        hidden = {names[k] for k in policy["technical_keys"] if k in names}
        hidden.update(definition["name"] for definition in policy.get("display_fields", {}).get(table["logical_name"], [])
                      if definition.get("hidden") and definition["name"] in field_names)
        hidden.update(name for name in policy.get("retired_fields", {}).get(table["logical_name"], [])
                      if name in field_names)
        # Raw provenance codes belong to the detailed evidence, not the main price comparison.
        if table["logical_name"] == "offers" and "verification_status" in names:
            hidden.add(names["verification_status"])
        visible = []
        for key in view_policy["visible"]:
            name = names.get(key, key)
            if name not in field_names:
                limitations.append("missing_visible_field:" + table["name"] + ":" + name)
            elif name not in visible:
                visible.append(name)
        # Preserve unknown custom business columns; only explicitly classified technical fields are hidden.
        known_names = {f["name"] for f in table["fields"]}
        known_names.update(f["name"] for f in policy.get("display_fields", {}).get(table["logical_name"], []))
        for name in field_names:
            if name not in known_names and name not in hidden and name not in visible:
                visible.append(name)
        primary = names.get(view_policy["primary"], view_policy["primary"])
        if primary not in field_names:
            limitations.append("missing_business_primary:" + table["name"] + ":" + primary)
            continue
        requests.append({"service": "dbsheet", "action": "update-sheet", "payload": {
            "file_id": file_id, "sheet_id": sheet["id"], "primary_field": primary}})
        candidates = [v for v in sheet.get("views", []) if v["name"] == view_policy["view"]]
        if not candidates:
            candidates = [v for v in sheet.get("views", []) if v["name"] == "默认视图" and v["type"].lower() == "grid"]
        if not candidates:
            limitations.append("create_view_then_recompile:" + table["name"] + ":" + view_policy["view"])
            requests.append({"service": "dbsheet", "action": "create-view", "payload": {
                "file_id": file_id, "sheet_id": sheet["id"], "name": view_policy["view"], "type": "Grid"}})
            continue
        ordered = visible + [n for n in field_names if n not in visible]
        widths = []
        for name in visible:
            key = next((k for k, n in names.items() if n == name), name)
            width = view_policy.get("widths", {}).get(key, 2400 if "名称" in name or "时间" in name else 1500)
            widths.append({"field": name, "width": width})
        requests.append({"service": "dbsheet", "action": "update-view", "payload": {
            "file_id": file_id, "sheet_id": sheet["id"], "view_id": candidates[0]["id"],
            "name": view_policy["view"], "prefer_id": False,
            "order_fields": ordered,
            "fields_attribute": [{"field": name, "hidden": name not in visible} for name in field_names],
            "widths": widths,
            **({"height": view_policy["row_height_twip"]} if "row_height_twip" in view_policy else {})}})
        for secondary in view_policy.get("secondary_views", []):
            found = [v for v in sheet.get("views", []) if v["name"] == secondary["name"]]
            if not found:
                requests.append({"service": "dbsheet", "action": "create-view", "payload": {
                    "file_id": file_id, "sheet_id": sheet["id"], "name": secondary["name"], "type": secondary["type"]}})
                limitations.append("recompile_after_secondary_view:" + table["name"] + ":" + secondary["name"])
                continue
            card_fields = []
            for key in secondary["visible"]:
                name = names.get(key, key)
                if name not in field_names:
                    limitations.append("missing_visible_field:" + table["name"] + ":" + secondary["name"] + ":" + name)
                elif name not in card_fields:
                    card_fields.append(name)
            requests.append({"service": "dbsheet", "action": "update-view", "payload": {
                "file_id": file_id, "sheet_id": sheet["id"], "view_id": found[0]["id"], "prefer_id": False,
                "order_fields": card_fields + [n for n in field_names if n not in card_fields],
                "fields_attribute": [{"field": n, "hidden": n not in card_fields} for n in field_names]}})
    return {"requests": requests, "limitations": limitations,
            "note": "Execution, missing display fields and navigation are verified separately; no remote calls performed."}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--schema", required=True)
    parser.add_argument("--file-id", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    try:
        result = compile_views(json.loads(Path(args.schema).read_text(encoding="utf-8")), args.file_id)
        Path(args.out).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        print(json.dumps({"requests": len(result["requests"]), "limitations": result["limitations"]}, ensure_ascii=False))
    except (ValueError, OSError, KeyError, TypeError) as error:
        print(json.dumps({"error": str(error)}, ensure_ascii=False), file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
