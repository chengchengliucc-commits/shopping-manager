#!/usr/bin/env python3
"""Discover and inspect the two supported transports for the same dbsheet API."""
from contextlib import contextmanager
from contextvars import ContextVar
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess


SUPPORTED = ("dbsheet-cli", "kdocs-cli")
CONTRACT = "kdocs-dbsheet-v1"
ACTIVE_CLI = ContextVar("shopping_cli", default=None)
ACTIVE_EXECUTABLE = ContextVar("shopping_cli_executable", default=None)
ACTION_GROUPS = {
    "read": ("get-schema", "records-list"),
    "write": ("create-records", "update-records", "update-fields"),
    "setup": ("create-sheet", "create-fields", "update-sheet", "create-view", "update-view"),
}


class BackendError(ValueError):
    pass


class MissingCLI(BackendError):
    pass


def default_bin_dir():
    if os.name == "nt":
        return Path(os.environ.get("LOCALAPPDATA", str(Path.home() / "AppData" / "Local"))) / "dbsheet-cli"
    return Path.home() / ".local" / "bin"


def find_cli(name):
    found = shutil.which(name)
    if found:
        return found
    candidate = default_bin_dir() / (name + ".exe" if os.name == "nt" else name)
    return str(candidate) if candidate.is_file() and os.access(candidate, os.X_OK) else None


def cli_executable(name):
    if ACTIVE_CLI.get() == name and ACTIVE_EXECUTABLE.get():
        return ACTIVE_EXECUTABLE.get()
    path = find_cli(name)
    if not path:
        raise MissingCLI(name + " is unavailable; run python3 scripts/ledger.py bootstrap")
    return path


def select_cli(preference="auto"):
    """Fallback is discovery at startup, never a retry after a failed request."""
    selected = ACTIVE_CLI.get()
    if selected:
        return selected
    preference = os.environ.get("SHOPPING_CLI", preference)
    if preference not in ("auto", *SUPPORTED):
        raise BackendError("unsupported CLI; choose auto, dbsheet-cli or kdocs-cli")
    candidates = SUPPORTED if preference == "auto" else (preference,)
    for name in candidates:
        if find_cli(name):
            return name
    if preference == "auto":
        raise MissingCLI("no supported CLI found; install dbsheet-cli or kdocs-cli with python3 scripts/ledger.py bootstrap")
    raise MissingCLI(preference + " is unavailable; use auto for installation-based discovery")


@contextmanager
def cli_session(name):
    if name not in SUPPORTED:
        raise BackendError("unsupported CLI transport")
    token = ACTIVE_CLI.set(name)
    executable_token = ACTIVE_EXECUTABLE.set(find_cli(name))
    try:
        yield
    finally:
        ACTIVE_EXECUTABLE.reset(executable_token)
        ACTIVE_CLI.reset(token)


def _local(name, *arguments):
    """Never include stdout/stderr from authentication or failed processes in diagnostics."""
    try:
        result = subprocess.run([cli_executable(name), *arguments], capture_output=True, text=True, timeout=10)
    except (OSError, subprocess.SubprocessError):
        raise BackendError(name + ": local check failed for " + " ".join(arguments)) from None
    if result.returncode:
        raise BackendError(name + ": local check failed for " + " ".join(arguments) +
                           ", exit=" + str(result.returncode))
    # These CLIs print help to stderr even on a successful --help invocation.
    return result.stdout + "\n" + result.stderr if arguments[-1:] == ("--help",) else result.stdout


def cli_version(name):
    version = _local(name, "--version").strip()
    match = re.fullmatch(r"v?(\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?)", version)
    if not match:
        raise BackendError(name + ": unrecognized version response")
    return match.group(1)


def _actions(help_text):
    return set(re.findall(r"^\s{2,}([a-z][a-z0-9-]+)\s{2,}", help_text, re.MULTILINE))


def inspect_cli(name):
    """Local capability/auth checks; this does not verify remote file permissions."""
    if name not in SUPPORTED:
        raise BackendError("unsupported CLI transport")
    version = cli_version(name)
    global_help = _local(name, "--help")
    actions = _actions(_local(name, "dbsheet", "--help"))
    try:
        drive_actions = _actions(_local(name, "drive", "--help"))
    except BackendError:
        drive_actions = set()
    raw_auth = _local(name, "auth", "status")
    try:
        auth = json.loads(raw_auth)
    except json.JSONDecodeError:
        raise BackendError(name + ": authentication status is not valid JSON") from None
    if not isinstance(auth, dict) or not isinstance(auth.get("authenticated"), bool):
        raise BackendError(name + ": authentication status lacks an authenticated boolean")
    flags = [flag for flag in ("--file", "--output") if flag not in global_help]
    missing, required = {}, set()
    for group, group_actions in ACTION_GROUPS.items():
        required.update(group_actions)
        missing[group] = flags + ["dbsheet " + action for action in sorted(required - actions)]
    missing["create"] = list(missing["setup"])
    if "create-empty-file" not in drive_actions:
        missing["create"].append("drive create-empty-file")
    capabilities = {group: not absent for group, absent in missing.items()}
    auth_argv = [cli_executable(name), "auth", "login"]
    return {"cli": name, "version": version, "backend_contract": CONTRACT,
            "authenticated": auth["authenticated"], "auth_command": subprocess.list2cmdline(auth_argv) if os.name == "nt" else shlex.join(auth_argv),
            "auth_argv": auth_argv,
            "capabilities": capabilities, "missing_capabilities": missing,
            "ready": {group: available and auth["authenticated"] for group, available in capabilities.items()},
            "probe": "local_help_and_auth"}


def require_capability(info, group):
    if not info["capabilities"].get(group):
        raise BackendError(info["cli"] + " lacks required capabilities: " +
                           ", ".join(info["missing_capabilities"].get(group, [group])))
    if not info["authenticated"]:
        raise BackendError(info["cli"] + " is not authenticated; run " + info["auth_command"])
