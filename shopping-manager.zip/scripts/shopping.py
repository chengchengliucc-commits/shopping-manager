#!/usr/bin/env python3
"""Deterministic shopping calculations. Standard library only; no remote writes."""
import argparse
from datetime import date
import json
import re
import sys
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path

MAX_FEN = 9007199254740991
KINDS = {"payment", "refund", "payment_reversal", "refund_reversal"}
PAYMENT_TASKS = {"deposit", "balance", "full_payment"}
# A reference quote older than this is flagged in the reference summary; the
# threshold is a display rule, not a financial one.
STALE_REFERENCE_DAYS = 7

# Human-facing dropdown labels; normalize copies before financial calculations.
DISPLAY_LABELS = {
    "purchases": {"order_status": {"ordered": "已下单", "shipped": "已发货", "received": "已收货", "cancelled": "已取消"}},
    "events": {"kind": {"payment": "支付", "refund": "现金退款", "payment_reversal": "支付冲回", "refund_reversal": "退款冲回"},
               "status": {"pending": "处理中", "confirmed": "已确认", "void": "已作废"}},
    "tasks": {"kind": {"deposit": "定金", "balance": "尾款", "full_payment": "一次性付款", "evidence": "补资料", "price_protection": "价保核实"},
              "status": {"active": "待处理", "paid": "已支付", "cancelled": "已取消", "done": "已完成"}},
}


class InputError(ValueError):
    pass


def fen(value, label, nullable=True):
    if value is None and nullable:
        return None
    if isinstance(value, bool):
        raise InputError(label + " must be a nonnegative integer number of fen, or null")
    # Number columns often come back as an integral float or Decimal; accept those,
    # but never accept a fractional amount.
    if isinstance(value, int):
        result = value
    elif isinstance(value, Decimal) and value.is_finite() and value == value.to_integral_value():
        result = int(value)
    elif isinstance(value, float) and value.is_integer():
        result = int(value)
    else:
        raise InputError(label + " must be a nonnegative integer number of fen, or null")
    if not 0 <= result <= MAX_FEN:
        raise InputError(label + " must be a nonnegative integer number of fen, or null")
    return result


def dec(value, label):
    if isinstance(value, bool) or value is None:
        raise InputError(label + " must be a decimal number")
    try:
        result = Decimal(str(value))
    except (InvalidOperation, ValueError):
        raise InputError(label + " must be a decimal number") from None
    if not result.is_finite():
        raise InputError(label + " must be finite")
    return result


def positive(value, label):
    result = dec(value, label)
    if result <= 0:
        raise InputError(label + " must be greater than zero")
    return result


def text(value, label):
    if not isinstance(value, str) or not value.strip():
        raise InputError(label + " must be a nonempty string")
    return value


def option(value, choices, label):
    if value not in choices:
        raise InputError(label + " must be one of " + ", ".join(sorted(choices)))
    return value


def rows(value, label):
    if not isinstance(value, list) or any(not isinstance(x, dict) for x in value):
        raise InputError(label + " must be an array of objects")
    return value


def id_list(value, label):
    """Accept an array of IDs, or the same array stored as JSON text in a text column."""
    if value is None or value == "":
        return []
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except ValueError:
            raise InputError(label + " must be an array of IDs or a JSON array string") from None
    if not isinstance(value, list) or any(not isinstance(item, str) for item in value):
        raise InputError(label + " must be an array of IDs or a JSON array string")
    return value


def unique(records, key, label):
    result = {}
    duplicate_count = 0
    for row in rows(records, label):
        identity = text(row.get(key), label + "." + key)
        if identity in result:
            if result[identity] != row:
                raise InputError("conflicting " + key + ": " + identity)
            duplicate_count += 1
        else:
            result[identity] = row
    return result, duplicate_count


def money(data):
    raw = str(data.get("amount", ""))
    if not re.fullmatch(r"\d+(?:\.\d{1,2})?", raw):
        raise InputError("amount must be nonnegative yuan with at most two decimal places")
    amount = fen(int(Decimal(raw) * 100), "amount_fen", False)
    return {"amount_fen": amount, "yuan": format(Decimal(amount) / 100, ".2f")}


def price(data):
    basis = option(data.get("basis"), {"item_price", "checkout_total"}, "basis")
    base = fen(data.get("base_fen"), "base_fen")
    promotions = rows(data.get("promotions", []), "promotions")
    shipping = fen(data.get("shipping_fen"), "shipping_fen")
    if basis == "checkout_total":
        if promotions or shipping not in (None, 0):
            raise InputError("checkout_total already includes shipping and discounts; do not subtract again")
        return {"result_kind": "checkout_input", "total_fen": base, "known_subtotal_fen": base,
                "applied": [], "unapplied": [], "missing": [] if base is not None else ["base_fen"]}
    missing = [key for key, value in (("base_fen", base), ("shipping_fen", shipping)) if value is None]
    current = base
    applied, unapplied = [], []
    usable = [p for p in promotions if p.get("status") == "confirmed" and p.get("eligible") is True]
    if len(usable) > 1 and data.get("stacking_verified") is not True:
        raise InputError("multiple usable promotions require stacking_verified=true and evidence of order")
    for index, rule in enumerate(promotions):
        ident = rule.get("promotion_id", str(index + 1))
        status = option(rule.get("status"), {"confirmed", "pending", "expired"}, "promotion.status")
        if status != "confirmed" or rule.get("eligible") is not True:
            unapplied.append({"promotion_id": ident, "reason": "conditions_not_confirmed_or_not_applicable"})
            continue
        kind = option(rule.get("kind"), {"fixed", "percent", "full_reduction", "per_threshold"},
                      "promotion.kind")
        if rule.get("already_included") is True:
            raise InputError("promotion already included in base; choose a consistent price basis")
        if current is None:
            unapplied.append({"promotion_id": ident, "reason": "base_missing"})
            continue
        if kind in {"full_reduction", "per_threshold"}:
            threshold_basis = option(rule.get("threshold_basis"), {"original", "current"}, "threshold_basis")
            threshold_value = base if threshold_basis == "original" else current
        if kind == "full_reduction":
            threshold = fen(rule.get("threshold_fen"), "threshold_fen", False)
            if threshold_value < threshold:
                unapplied.append({"promotion_id": ident, "reason": "threshold_not_met"})
                continue
        if kind == "percent":
            rate = rule.get("discount_bps")
            if isinstance(rate, bool) or not isinstance(rate, int) or not 0 <= rate <= 10000:
                raise InputError("discount_bps must be an integer from 0 to 10000; 2000 means 20% off")
            discount = (current * rate + 5000) // 10000
        elif kind == "per_threshold":
            step = fen(rule.get("step_fen"), "step_fen", False)
            if step <= 0:
                raise InputError("step_fen must be greater than zero")
            steps = threshold_value // step
            if steps == 0:
                unapplied.append({"promotion_id": ident, "reason": "threshold_not_met"})
                continue
            discount = steps * fen(rule.get("amount_fen"), "promotion.amount_fen", False)
        else:
            discount = fen(rule.get("amount_fen"), "promotion.amount_fen", False)
        if kind in {"percent", "per_threshold"}:
            cap = fen(rule.get("cap_fen"), "cap_fen")
            if cap is not None:
                discount = min(discount, cap)
        if discount > current:
            raise InputError("discount exceeds remaining item amount; verify rule instead of clamping")
        current -= discount
        applied.append({"promotion_id": ident, "discount_fen": discount})
    known = (current or 0) + (shipping or 0)
    return {"result_kind": "estimate_from_confirmed_conditions",
            "total_fen": known if not missing else None, "known_subtotal_fen": known,
            "applied": applied, "unapplied": unapplied, "missing": missing}


def unit_price(data):
    amount = fen(data.get("amount_fen"), "amount_fen", False)
    units = positive(data.get("total_units"), "total_units")
    scale = positive(data.get("per_units", 1), "per_units")
    unit = text(data.get("unit"), "unit")
    value = Decimal(amount) * scale / (100 * units)
    return {"yuan_per_unit": format(value.quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP), ".4f"),
            "per_units": str(scale), "unit": unit,
            "note": "A mathematical unit price only; product comparability must be checked separately."}


def snapshot(data):
    if data.get("read_complete") is not True:
        raise InputError("read_complete=true is required; finish pagination before a complete budget or review")
    collections, duplicates = {}, {}
    for name, key in (("items", "item_id"), ("purchases", "purchase_id"),
                      ("events", "event_id"), ("tasks", "task_id")):
        collections[name], duplicates[name] = unique(data.get(name), key, name)
        collections[name] = {key: dict(row) for key, row in collections[name].items()}
        for row in collections[name].values():
            for field, labels in DISPLAY_LABELS.get(name, {}).items():
                reverse = {label: token for token, label in labels.items()}
                if isinstance(row.get(field), str) and row[field] in reverse:
                    row[field] = reverse[row[field]]
    items, purchases, events, tasks = [collections[k] for k in ("items", "purchases", "events", "tasks")]
    groups = {}
    for item in items.values():
        positive(item.get("planned_quantity"), "planned_quantity")
    for purchase in purchases.values():
        if purchase.get("item_id") not in items:
            raise InputError("purchase references missing item; every purchase belongs to an item row")
        option(purchase.get("order_status"), {"ordered", "shipped", "received", "cancelled"}, "order_status")
        quantity = positive(purchase.get("quantity"), "purchase.quantity")
        retained = purchase.get("retained_quantity")
        if retained is not None and not 0 <= dec(retained, "retained_quantity") <= quantity:
            raise InputError("retained_quantity must be between zero and purchased quantity")
        details = purchase.get("details_json")
        if isinstance(details, str) and details:
            try:
                details = json.loads(details)
            except ValueError:
                raise InputError("purchase.details_json must be a JSON object") from None
        if details in (None, ""):
            details = {}
        if not isinstance(details, dict):
            raise InputError("purchase.details_json must be a JSON object")
        purchase["details_json"] = dict(details)
        for field in ("item_paid_fen", "item_refund_fen"):
            if field in details:
                purchase["details_json"][field] = fen(details[field], "purchase." + field)
        if "payment_complete" in details and not isinstance(details["payment_complete"], bool):
            raise InputError("purchase.payment_complete must be a boolean")
        group = text(purchase.get("order_group_id"), "purchase.order_group_id")
        groups.setdefault(group, []).append(purchase["purchase_id"])
    for task in tasks.values():
        option(task.get("kind"), set(DISPLAY_LABELS["tasks"]["kind"]), "task.kind")
        option(task.get("status"), set(DISPLAY_LABELS["tasks"]["status"]), "task.status")
    aliases, financial_keys = {}, {}
    for eid, event in list(events.items()):
        option(event.get("kind"), KINDS, "event.kind")
        option(event.get("status"), {"pending", "confirmed", "void"}, "event.status")
        event["amount_fen"] = fen(event.get("amount_fen"), "event.amount_fen")
        target_type = option(event.get("target_type"), {"purchase", "order_group"}, "event.target_type")
        targets = purchases if target_type == "purchase" else groups
        if event.get("target_id") not in targets and event.get("status") != "void":
            # void 是作废留痕：对象被删除后允许悬空，金额不参与任何聚合。
            raise InputError("event references a missing " + target_type)
        key = event.get("identity_key")
        if key:
            text(key, "identity_key")
            financial = {k: event.get(k) for k in ("kind", "status", "amount_fen",
                                                   "target_type", "target_id", "reverses_event_id")}
            if key in financial_keys:
                previous_id, previous = financial_keys[key]
                if previous != financial:
                    raise InputError("conflicting financial identity_key: " + key)
                aliases[eid] = previous_id
                del events[eid]
                duplicates["events"] += 1
            else:
                financial_keys[key] = (eid, financial)
    issues = []
    reversed_amounts = {}
    for event in events.values():
        if event["kind"].endswith("_reversal") and event["status"] != "void":
            old_id = aliases.get(event.get("reverses_event_id"), event.get("reverses_event_id"))
            old = events.get(old_id)
            if not old or old["kind"] != event["kind"].removesuffix("_reversal"):
                raise InputError("reversal must reference the matching original event kind")
            if (old["target_type"], old["target_id"]) != (event["target_type"], event["target_id"]):
                raise InputError("reversal target differs from original event")
            if old["status"] != "confirmed":
                raise InputError("reversal must reference a confirmed event; void pending mistakes instead")
            if event["status"] == "confirmed":
                amount = event["amount_fen"]
                if amount is None or old["amount_fen"] is None:
                    issues.append("reversal_amount_unknown:" + event["event_id"])
                    reversed_amounts[old_id] = None
                elif reversed_amounts.get(old_id, 0) is not None:
                    reversed_amounts[old_id] = reversed_amounts.get(old_id, 0) + amount
                    if reversed_amounts[old_id] > old["amount_fen"]:
                        raise InputError("reversal exceeds original event amount")
    # Same amount and target alone is a warning, never a deletion rule.
    seen = {}
    for event in events.values():
        if event["kind"] == "payment" and event["status"] == "confirmed" and not event.get("identity_key"):
            key = (event["target_type"], event["target_id"], event["amount_fen"])
            if key in seen:
                issues.append("possible_duplicate_payment:" + seen[key] + "," + event["event_id"])
            else:
                seen[key] = event["event_id"]
    return items, purchases, events, tasks, groups, aliases, reversed_amounts, duplicates, issues


def aggregate(events, kind, status="confirmed", target=None):
    total, unknown = 0, 0
    for event in events.values():
        if event["status"] != status or (target and (event["target_type"], event["target_id"]) != target):
            continue
        if event["kind"] == kind:
            sign = 1
        elif status == "confirmed" and event["kind"] == kind + "_reversal":
            sign = -1
        else:
            continue
        if event["amount_fen"] is None:
            unknown += 1
        else:
            total += sign * event["amount_fen"]
    return {"known_fen": total, "unknown_count": unknown, "total_fen": None if unknown else total}


def _active_purchased_by_item(purchases):
    """Item-keyed quantity from non-cancelled purchase rows; the only purchase fact."""
    result = {}
    for purchase in purchases.values():
        if purchase["order_status"] != "cancelled":
            key = purchase.get("item_id")
            result[key] = result.get(key, Decimal(0)) + positive(purchase["quantity"], "purchase.quantity")
    return result


def fulfilled_by_item(purchases):
    """A confirmed return reopens the need; a cash refund alone never changes quantity."""
    result = {}
    for purchase in purchases.values():
        if purchase["order_status"] == "cancelled":
            continue
        quantity = (dec(purchase["retained_quantity"], "retained_quantity")
                    if purchase.get("retained_quantity") is not None else positive(purchase["quantity"], "quantity"))
        key = purchase.get("item_id")
        result[key] = result.get(key, Decimal(0)) + quantity
    return result


def intent_active(item):
    status = _object_json(item.get("details_json")).get("intent_status")
    if status is not None:
        option(status, {"active", "paused", "dropped"}, "item.intent_status")
        return status == "active"
    # Existing ledgers used the reason as their only exit marker. New workflows
    # persist an explicit internal decision so free-form notes do not control it.
    return not item.get("not_bought_reason")


def item_net_spend(item_id, purchases, events, groups):
    """Net cash attributable to one item, with complete allocation coverage checks."""
    known, complete, has_payment, allocated = 0, True, False, False
    issues = []
    for group, ids in groups.items():
        own = [pid for pid in ids if purchases[pid].get("item_id") == item_id]
        if not own:
            continue
        related = {eid: e for eid, e in events.items() if e["status"] != "void" and (
            (e["target_type"] == "order_group" and e["target_id"] == group) or
            (e["target_type"] == "purchase" and e["target_id"] in ids))}
        paid, refunds = aggregate(related, "payment"), aggregate(related, "refund")
        if not any(e["kind"] == "payment" and e["status"] == "confirmed" for e in related.values()):
            complete = False
            issues.append("payment_missing:" + group)
            continue
        has_payment = True
        if paid["total_fen"] is None or refunds["total_fen"] is None:
            complete = False
            issues.append("cash_amount_unknown:" + group)
            continue
        if all(purchases[pid].get("item_id") == item_id for pid in ids):
            value = paid["total_fen"] - refunds["total_fen"]
        else:
            own_events = {eid: e for eid, e in related.items() if e["target_type"] == "purchase" and e["target_id"] in own}
            direct_paid, direct_refund = aggregate(own_events, "payment"), aggregate(own_events, "refund")
            shared_paid = aggregate(related, "payment", target=("order_group", group))
            shared_refund = aggregate(related, "refund", target=("order_group", group))
            if shared_paid["known_fen"]:
                amounts = {pid: purchases[pid]["details_json"].get("item_paid_fen") for pid in ids}
                if any(value is None for value in amounts.values()) or sum(amounts.values()) != paid["total_fen"]:
                    complete = False
                    issues.append("payment_allocation_incomplete:" + group)
                    continue
                value = sum(amounts[pid] for pid in own) - direct_refund["known_fen"]
                allocated = True
            else:
                value = direct_paid["known_fen"] - direct_refund["known_fen"]
            if shared_refund["known_fen"]:
                refunds_by_purchase = {pid: purchases[pid]["details_json"].get("item_refund_fen") for pid in ids}
                if (any(value is None for value in refunds_by_purchase.values()) or
                        sum(refunds_by_purchase.values()) != shared_refund["total_fen"]):
                    complete = False
                    issues.append("refund_allocation_incomplete:" + group)
                    continue
                value -= sum(refunds_by_purchase[pid] for pid in own)
                allocated = True
        if value < 0:
            complete = False
            issues.append("item_refund_exceeds_payment:" + group)
        else:
            known += value
    return {"known_fen": known, "total_fen": known if complete and has_payment else None,
            "complete": complete and has_payment, "allocated": allocated, "issues": issues}


def budget(data, budget_fen=None):
    items, purchases, events, tasks, groups, aliases, reversals, duplicate, issues = snapshot(data)
    paid = aggregate(events, "payment")
    refunds = aggregate(events, "refund")
    pending_refunds = aggregate(events, "refund", "pending")
    for label, result in (("payment", paid), ("refund", refunds)):
        if result["known_fen"] < 0:
            issues.append("negative_net_" + label)
    # Index events by order group once instead of rescanning every event per group.
    events_by_group = {group: {} for group in groups}
    for eid, event in events.items():
        if event["status"] == "void":
            continue
        if event["target_type"] == "order_group":
            group = event["target_id"]
        else:
            group = purchases[event["target_id"]]["order_group_id"]
        if group in events_by_group:
            events_by_group[group][eid] = event
    invalid_refund_group = False
    for group, group_events in events_by_group.items():
        group_paid, group_refund = aggregate(group_events, "payment"), aggregate(group_events, "refund")
        if (group_paid["total_fen"] is not None and group_refund["total_fen"] is not None
                and group_refund["total_fen"] > group_paid["total_fen"]):
            issues.append("order_refund_exceeds_payment:" + group)
            invalid_refund_group = True
    net = None if paid["total_fen"] is None or refunds["total_fen"] is None else paid["total_fen"] - refunds["total_fen"]
    if invalid_refund_group:
        net = None
    if net is not None and net < 0:
        issues.append("refund_exceeds_payment")
        net = None
    outstanding_known, outstanding_unknown, used, task_results = 0, 0, {}, []
    scheduled = set()
    settled = {pid for pid, purchase in purchases.items() if purchase["details_json"].get("payment_complete") is True
               and any(e["kind"] == "payment" and e["status"] == "confirmed" and (
                   (e["target_type"] == "purchase" and e["target_id"] == pid) or
                   (e["target_type"] == "order_group" and e["target_id"] == purchase["order_group_id"]))
                   for e in events.values())}
    for task in tasks.values():
        kind = task.get("kind")
        if kind not in PAYMENT_TASKS:
            continue
        status = option(task.get("status"), {"active", "paid", "cancelled"}, "task.status")
        if status == "cancelled":
            continue
        due = fen(task.get("amount_fen"), "task.amount_fen")
        refs = id_list(task.get("payment_event_ids"), "payment_event_ids")
        allocated, allocated_unknown = 0, False
        canonical_refs = set()
        target = (task.get("target_type"), task.get("target_id"))
        if target[0] not in {"purchase", "order_group"} or target[1] not in (purchases if target[0] == "purchase" else groups):
            raise InputError("payment task must reference an existing purchase or order_group")
        scheduled.add(target)
        for ref in refs:
            ref = aliases.get(ref, ref)
            if ref in canonical_refs:
                continue
            canonical_refs.add(ref)
            event = events.get(ref)
            if not event or event["kind"] != "payment" or event["status"] != "confirmed":
                raise InputError("payment task references missing/unconfirmed/non-payment event")
            if (event["target_type"], event["target_id"]) != target:
                raise InputError("task and payment event must have the same target")
            if ref in used:
                raise InputError("one payment event assigned to multiple payment tasks")
            used[ref] = task["task_id"]
            if event["amount_fen"] is None or reversals.get(ref, 0) is None:
                allocated_unknown = True
            else:
                allocated += event["amount_fen"] - reversals.get(ref, 0)
        if target[0] == "purchase" and purchases[target[1]]["order_status"] == "cancelled":
            issues.append("active_payment_task_for_cancelled_purchase:" + task["task_id"])
        if target[0] == "order_group" and all(purchases[p]["order_status"] == "cancelled" for p in groups[target[1]]):
            issues.append("active_payment_task_for_cancelled_order:" + task["task_id"])
        remaining = None if due is None or allocated_unknown else due - allocated
        if remaining is not None and remaining < 0:
            issues.append("task_overpaid:" + task["task_id"])
            remaining = None
        if status == "paid" and remaining != 0:
            issues.append("paid_task_without_matching_payment:" + task["task_id"])
        task_results.append({"task_id": task["task_id"], "kind": kind, "status": status,
                             "target_type": target[0], "target_id": target[1],
                             "amount_fen": due, "due_at": task.get("due_at"),
                             "time_source": task.get("time_source"), "remaining_fen": remaining})
    # A successful payment write and a failed task update must not count the same
    # cash both as paid and still payable. Do not guess which stage it belongs to.
    unreconciled_groups, unallocated_payments = set(), []
    covered = set()
    for task in tasks.values():
        if task["kind"] not in {"balance", "full_payment"}:
            continue
        # A cancelled balance is an explicitly discharged obligation, unlike an
        # absent balance whose amount and existence have never been recorded.
        if task.get("target_type") == "purchase" and task.get("target_id") in purchases:
            covered.add(task["target_id"])
        elif task.get("target_type") == "order_group" and task.get("target_id") in groups:
            covered.update(groups[task["target_id"]])
    for task in task_results:
        if task["kind"] != "deposit":
            continue
        target_ids = ({task["target_id"]} if task["target_type"] == "purchase" else set(groups[task["target_id"]]))
        active_ids = {pid for pid in target_ids if purchases[pid]["order_status"] != "cancelled"}
        if active_ids - covered:
            issues.append("deposit_missing_balance_schedule:" + task["task_id"])
            unreconciled_groups.update(purchases[pid]["order_group_id"] for pid in active_ids - covered)
    for eid, event in events.items():
        if event["kind"] != "payment" or event["status"] != "confirmed" or eid in used:
            continue
        amount, reversed_amount = event["amount_fen"], reversals.get(eid, 0)
        if amount is not None and reversed_amount is not None and amount == reversed_amount:
            continue
        if ((event["target_type"] == "purchase" and event["target_id"] in settled) or
                (event["target_type"] == "order_group" and set(groups[event["target_id"]]).issubset(settled))):
            continue
        if event["target_type"] == "purchase":
            purchase = purchases[event["target_id"]]
            if purchase["order_status"] == "cancelled":
                continue
            group = purchase["order_group_id"]
        else:
            group = event["target_id"]
            if all(purchases[pid]["order_status"] == "cancelled" for pid in groups[group]):
                continue
        issues.append("payment_unallocated:" + eid)
        unallocated_payments.append(eid)
        unreconciled_groups.add(group)
    for task in task_results:
        group = (task["target_id"] if task["target_type"] == "order_group"
                 else purchases[task["target_id"]]["order_group_id"])
        if group in unreconciled_groups:
            task["remaining_fen"] = None
        if task["remaining_fen"] is None:
            outstanding_unknown += 1
        else:
            outstanding_known += task["remaining_fen"]
    for purchase in purchases.values():
        if purchase["order_status"] != "cancelled":
            if (purchase["purchase_id"] not in settled and ("purchase", purchase["purchase_id"]) not in scheduled
                    and ("order_group", purchase["order_group_id"]) not in scheduled):
                issues.append("purchase_missing_payment_schedule:" + purchase["purchase_id"])
                outstanding_unknown += 1
    # 已删除未承诺计划金额：想买多少钱由仪表盘"已录参考价小计"承载，用户自行与
    # 心里预算比较；预算占用只含已发生与已承诺的现金（净支出+待付）。
    outstanding = None if outstanding_unknown else outstanding_known
    summary = {"paid": paid, "refunds_received": refunds, "refunds_pending": pending_refunds,
               "net_cash_spend_fen": net,
               "outstanding": {"known_fen": outstanding_known, "unknown_count": outstanding_unknown, "total_fen": outstanding},
               "payment_tasks": task_results, "unallocated_payment_ids": unallocated_payments,
               "duplicate_records_ignored": duplicate, "issues": issues,
               "complete": not issues and all(v is not None for v in (net, outstanding))}
    # 预算是用户当次给的约束，不是账本里的事实：给了才算占用与余额。
    # 占用只含已发生与已承诺的现金；想买多少钱看参考价小计，不进预算占用。
    if budget_fen is not None:
        occupied = None if any(v is None for v in (net, outstanding)) else net + outstanding
        summary["budget"] = {"budget_fen": budget_fen, "occupied_fen": occupied,
                             "remaining_fen": None if occupied is None else budget_fen - occupied}
    return summary


def review(data):
    summary = budget(data)
    items, purchases, events, tasks, groups, aliases, reversals, duplicates, issues = snapshot(data)
    by_item = {}
    for purchase in purchases.values():
        by_item.setdefault(purchase.get("item_id"), []).append(purchase)
    results = []
    for item in items.values():
        all_orders = by_item.get(item["item_id"], [])
        active = [p for p in all_orders if p["order_status"] != "cancelled"]
        quantity = sum((positive(p["quantity"], "quantity") for p in active), Decimal(0))
        retained = None if any(p.get("retained_quantity") is None for p in active) else sum(
            (dec(p["retained_quantity"], "retained_quantity") for p in active), Decimal(0))
        if active:
            result = "purchased" if quantity >= positive(item.get("planned_quantity"), "planned_quantity") else "partial"
        elif not intent_active(item):
            result = "not_bought"
        elif all_orders:
            result = "cancelled_only"
        else:
            result = "purchase_result_unknown"
        results.append({"item_id": item["item_id"], "name": item.get("name"),
                        "result": result, "reason": item.get("not_bought_reason"),
                        "purchase_ids": [p["purchase_id"] for p in active],
                        "cancelled_purchase_ids": [p["purchase_id"] for p in all_orders if p["order_status"] == "cancelled"],
                        "purchased_quantity": str(quantity),
                        "retained_quantity": str(retained) if active and retained is not None else None})
    group_events_index = {group: {} for group in groups}
    for eid, event in events.items():
        if event["status"] == "void":
            continue
        group = event["target_id"] if event["target_type"] == "order_group" else purchases[event["target_id"]]["order_group_id"]
        if group in group_events_index:
            group_events_index[group][eid] = event
    unallocated = []
    for group, ids in groups.items():
        if len(ids) > 1:
            target = ("order_group", group)
            group_events = group_events_index[group]
            unallocated.append({"order_group_id": group, "purchase_ids": ids,
                                "paid": aggregate(group_events, "payment"),
                                "refunds_received": aggregate(group_events, "refund"),
                                "unallocated_paid": aggregate(group_events, "payment", target=target),
                                "unallocated_refunds_received": aggregate(group_events, "refund", target=target),
                                "note": "Order totals include direct and shared events; shared amounts are not allocated by guess."})
    summary["complete"] = summary["complete"] and not summary["issues"]
    return {"summary": summary, "items": results, "multi_item_order_groups": unallocated}


def _object_json(value):
    if isinstance(value, dict):
        return value
    if isinstance(value, str) and value.strip():
        try:
            parsed = json.loads(value)
            return parsed if isinstance(parsed, dict) else {}
        except ValueError:
            return {}
    return {}


def _dropped(offer, cause, bucket):
    """Record an excluded quote with a short reason so notes can name cheaper alternatives."""
    try:
        amount = fen(offer.get("base_fen"), "offer.base_fen")
    except InputError:
        amount = None
    bucket.append({"offer": offer, "amount": amount, "cause": cause})


def _reference_offer(item, offers, item_details, required_quantity):
    """Choose the cheapest recorded reference among compatible current offers."""
    candidates, exclusions, dropped = [], [], []
    selected_id = item.get("selected_offer_id")
    by_id = {o.get("offer_id"): o for o in offers if o.get("offer_id")}
    successors = {}
    for offer in offers:
        old_id = offer.get("supersedes_offer_id")
        if not old_id:
            continue
        if old_id in by_id and by_id[old_id].get("item_id") != offer.get("item_id"):
            raise InputError("replacement quote must belong to the same item")
        successors.setdefault(old_id, set()).add(offer.get("offer_id"))
        seen, cursor = set(), offer
        while cursor.get("supersedes_offer_id") in by_id:
            predecessor = cursor["supersedes_offer_id"]
            if predecessor in seen:
                raise InputError("quote replacement chain contains a cycle")
            seen.add(predecessor)
            cursor = by_id[predecessor]
    selected_ids = {selected_id} if selected_id else set()
    for _ in range(len(offers)):
        expanded = selected_ids | {child for parent in selected_ids for child in successors.get(parent, set())}
        if expanded == selected_ids:
            break
        selected_ids = expanded
    preferred_colors = item_details.get("preferred_colors", [])
    if not isinstance(preferred_colors, list):
        preferred_colors = []
    selected_exists = False
    for offer in offers:
        if offer.get("item_id") != item["item_id"]:
            continue
        if selected_id and offer.get("offer_id") == selected_id:
            selected_exists = True
        if offer.get("offer_id") in successors:
            _dropped(offer, "已有更新报价", dropped)
            continue
        if selected_id and offer.get("offer_id") not in selected_ids:
            continue
        if offer.get("verification_status") not in {"ORDER_ACTUAL", "CHECKOUT_VERIFIED", "PAGE_DISPLAYED", "USER_PROVIDED"}:
            exclusions.append("报价证据尚未核实或已过期")
            _dropped(offer, "证据未核实", dropped)
            continue
        mismatch = []
        for key in ("category", "brand", "memory", "storage", "size", "pack_spec"):
            wanted, quoted = item.get(key), offer.get(key)
            if wanted not in (None, "", "不限") and wanted != quoted:
                mismatch.append((key, wanted, quoted))
        # A pinned color is a hard requirement. 颜色不限 keeps every color
        # comparable: preferred_colors only ranks candidates below, so a cheaper
        # non-preferred color stays in play with its caveat in the note.
        color = item.get("color")
        quoted_color = offer.get("color")
        if color not in (None, "", "不限") and color != quoted_color:
            mismatch.append(("color", color, quoted_color))
        if mismatch:
            for key, wanted, quoted in mismatch:
                exclusions.append("%s需要%s，报价为%s" % (key, wanted, quoted or "未提供"))
            _dropped(offer, "颜色或规格不符", dropped)
            continue
        condition = offer.get("condition")
        required_condition = item_details.get("condition_preference")
        lowered = str(condition or "").lower()
        # 二手市场话术会把用过的商品说成"几乎全新/99新/非全新"；这些都不能当全新比价。
        is_used = any(term in lowered for term in
                      ("二手", "成新", "新机", "拆封", "翻新", "退货", "展示机", "样机",
                       "几乎全新", "准新", "99新", "95新", "非全新"))
        if required_condition and condition != required_condition:
            exclusions.append("销售条件不符：" + str(condition or "未提供"))
            _dropped(offer, "成色不符", dropped)
            continue
        if is_used and not required_condition:
            exclusions.append("二手/拆封等销售条件未被选定")
            _dropped(offer, "成色未选", dropped)
            continue
        amount = fen(offer.get("base_fen"), "offer.base_fen")
        try:
            offer_quantity = positive(offer.get("quantity"), "offer.quantity")
        except InputError:
            exclusions.append("报价数量未明确")
            _dropped(offer, "数量未明确", dropped)
            continue
        quote_details = _object_json(offer.get("details_json"))
        if (amount is not None and offer_quantity != required_quantity and
                quote_details.get("quantity_pricing") == "linear" and quote_details.get("unit_price_fen") is not None):
            unit = fen(quote_details["unit_price_fen"], "offer.unit_price_fen", False)
            amount = fen(int((Decimal(unit) * required_quantity).quantize(Decimal(1), rounding=ROUND_HALF_UP)),
                         "reference_amount_fen", False)
        elif amount is None or offer_quantity != required_quantity:
            exclusions.append("报价数量与计划剩余数量不同，无法汇总")
            _dropped(offer, "数量不符", dropped)
            continue
        if offer.get("basis") not in {"item_price", "checkout_total"}:
            exclusions.append("报价价格口径无法汇总")
            _dropped(offer, "价格口径不符", dropped)
            continue
        shipping = fen(offer.get("shipping_fen"), "offer.shipping_fen")
        if offer.get("basis") == "item_price" and shipping is not None:
            amount = fen(amount + shipping, "reference_amount_fen", False)
        candidates.append((offer, amount))
    if candidates and not required_condition:
        with_condition = [c for c in candidates if c[0].get("condition")]
        new_condition = [c for c in with_condition if "全新" in str(c[0].get("condition"))]
        reduced = None
        if new_condition:
            if len(candidates) != len(new_condition):
                exclusions.append("未注明成色的报价未与全新商品混比")
            reduced = new_condition
        elif with_condition:
            reduced = with_condition
        if reduced is not None and len(reduced) != len(candidates):
            kept = {id(c[0]) for c in reduced}
            for candidate in candidates:
                if id(candidate[0]) not in kept:
                    dropped.append({"offer": candidate[0], "amount": candidate[1], "cause": "成色未注明"})
            candidates = reduced
    if selected_id and not selected_exists:
        exclusions.insert(0, "选定报价记录缺失")
    if not candidates:
        return None, None, list(dict.fromkeys(exclusions))
    # Explicit user selection wins; otherwise follow the recorded decision rule:
    # cheapest comparable quote first, preferred_colors order breaks price ties,
    # stronger evidence breaks preference ties, newest evidence time breaks the rest.
    def rank(candidate):
        offer, amount = candidate
        preference = preferred_colors.index(offer.get("color")) if offer.get("color") in preferred_colors else len(preferred_colors)
        confidence = {"ORDER_ACTUAL": 3, "CHECKOUT_VERIFIED": 2, "PAGE_DISPLAYED": 1, "USER_PROVIDED": 0}[offer["verification_status"]]
        return amount, preference, -confidence
    best = min(rank(candidate) for candidate in candidates)
    offer, amount = max((candidate for candidate in candidates if rank(candidate) == best),
                        key=lambda candidate: str(candidate[0].get("evidence_at") or ""))
    detail = _object_json(offer.get("details_json"))
    evidence = {"ORDER_ACTUAL": "订单实付", "CHECKOUT_VERIFIED": "结算核对",
                "PAGE_DISPLAYED": "页面展示", "USER_PROVIDED": "用户提供"}[offer["verification_status"]]
    note_parts = [str(offer.get("seller") or offer.get("platform") or "报价来源"), evidence]
    if positive(offer.get("quantity"), "offer.quantity") != required_quantity:
        note_parts.append("按已明确单价估算剩余数量")
    warnings = []
    if offer.get("shipping_fen") is not None:
        note_parts.append("含运费" + format(Decimal(offer["shipping_fen"]) / 100, ".2f") + "元")
    raw_label = detail.get("price_as_displayed") or detail.get("price_label")
    if raw_label and any(word in str(raw_label) for word in ("补贴", "国补", "PLUS", "优惠", "领后", "红包")):
        warnings.append("补贴/优惠待核")
    for question in detail.get("open_questions", []):
        if any(word in str(question) for word in ("券", "优惠", "补贴", "资格")):
            warnings.append("优惠资格待核")
        if any(word in str(question).lower() for word in ("运费", "shipping")):
            warnings.append("运费待核")
        if any(word in str(question) for word in ("成色", "销售方式")):
            warnings.append("成色待核")
    if offer.get("condition") is None and any(
            candidate.get("item_id") == item["item_id"] and candidate.get("condition")
            for candidate in offers):
        warnings.append("成色待核")
    if warnings:
        note_parts.append("/".join(list(dict.fromkeys(warnings))))
    # Keep the decision traceable: name cheaper quotes that were left out and why.
    cheaper = [d for d in dropped if d["amount"] is not None and d["amount"] < amount]
    for drop in cheaper[:2]:
        row = drop["offer"]
        label = "·".join(str(row.get(k)) for k in ("platform", "color") if row.get(k))
        prefix = (label + " ") if label else ""
        note_parts.append("另有%s%.2f元未计入（%s）" % (prefix, Decimal(drop["amount"]) / 100, drop["cause"]))
    return offer, amount, list(dict.fromkeys(note_parts))


def _ymd(value):
    """Best-effort calendar date from an ISO-ish timestamp; None when unknown."""
    if not isinstance(value, str):
        return None
    match = re.match(r"(\d{4})-(\d{2})-(\d{2})", value.strip())
    if not match:
        return None
    try:
        return date(int(match.group(1)), int(match.group(2)), int(match.group(3)))
    except ValueError:
        return None


def workbench(data):
    """Derive readable, refreshable display text without changing financial facts."""
    report = review(data)
    items, purchases, events, tasks, groups, *_ = snapshot(data)
    read_date = _ymd(data.get("read_at"))
    payment_tasks = report["summary"]["payment_tasks"]
    offers = data.get("offers", [])
    if not isinstance(offers, list):
        raise InputError("offers must be an array")
    active_purchased_by_item = _active_purchased_by_item(purchases)
    fulfilled = fulfilled_by_item(purchases)

    def yuan(amount):
        return format(Decimal(amount) / 100, ".2f") + "元"

    def task_text(task, shared=False):
        remaining = task["remaining_fen"]
        if remaining is None:
            value = "待付金额待核对"
        elif remaining == 0:
            value = "本阶段已付清"
        else:
            value = ("整单" if shared else "") + "待付" + DISPLAY_LABELS["tasks"]["kind"][task["kind"]] + yuan(remaining)
        return value + ("；截止 " + str(task["due_at"]) if task.get("due_at") and remaining != 0 else "")

    rows = []
    reference_priced_count, reference_missing_count = 0, 0
    reference_active_count, reference_subtotal_fen = 0, 0
    stale_items, undated_reference_count = [], 0
    for item in items.values():
        item_purchases = [p for p in purchases.values() if p.get("item_id") == item["item_id"]]
        orders = {p["purchase_id"] for p in item_purchases}
        order_groups = {purchases[pid]["order_group_id"] for pid in orders}
        shared_groups = {g for g in order_groups if not set(groups[g]).issubset(orders)}
        related = {eid: e for eid, e in events.items() if
                   (e["target_type"] == "purchase" and e["target_id"] in orders) or
                   (e["target_type"] == "order_group" and e["target_id"] in order_groups)}
        cash = item_net_spend(item["item_id"], purchases, events, groups)
        if not orders:
            amount = "尚无购买明细"
        elif cash["total_fen"] is None:
            amount = "单品净支出待核对（未录支付、分摊不完整或退款归属未知）"
        else:
            amount = ("分摊净支出 " if cash["allocated"] else "净现金支出 ") + yuan(cash["total_fen"])
        related_tasks = [t for t in payment_tasks if
                         (t["target_type"] == "purchase" and t["target_id"] in orders) or
                         (t["target_type"] == "order_group" and t["target_id"] in order_groups)]
        pending = [t for t in related_tasks if t["remaining_fen"] != 0]
        if any(eid in report["summary"]["unallocated_payment_ids"] for eid in related):
            next_step = "核对支付流水与付款待办的关联"
        elif pending:
            next_step = "；".join(task_text(t, t["target_type"] == "order_group" and t["target_id"] in shared_groups)
                                  for t in pending)
        elif any(e["kind"] == "refund" and e["status"] == "pending" for e in related.values()):
            next_step = "核对退款是否到账"
        elif any(t.get("item_id") == item["item_id"] and t["kind"] in {"evidence", "price_protection"}
                 and t["status"] == "active" for t in tasks.values()):
            next_step = "处理关联待办中的待补资料或价保线索"
        elif not intent_active(item) and not orders:
            next_step = "未购买" + ("：" + str(item["not_bought_reason"]) if item.get("not_bought_reason") else "")
        elif orders and all(purchases[pid]["order_status"] == "received" and
                            purchases[pid].get("retained_quantity") is not None for pid in orders) and related_tasks:
            next_step = "已收货，暂无已录待办"
        elif orders:
            next_step = "核对购买、付款及收货结果" if not related_tasks else "核对收货与最终保留数量"
        else:
            next_step = "比较候选报价或补充规格"
        specs = []
        for key in ("memory", "storage", "size", "color", "pack_spec", "spec_notes"):
            value = item.get(key)
            if value not in (None, "") and str(value) not in specs:
                specs.append(str(value))
        details = _object_json(item.get("details_json"))
        planned_quantity = positive(item.get("planned_quantity"), "planned_quantity")
        purchased_quantity = active_purchased_by_item.get(item["item_id"], Decimal(0))
        fulfilled_quantity = fulfilled.get(item["item_id"], Decimal(0))
        remaining_quantity = max(Decimal(0), planned_quantity - fulfilled_quantity)
        if fulfilled_quantity > 0:
            purchase_progress = "已购买" if remaining_quantity == 0 else "部分购买"
        elif purchased_quantity > 0:
            purchase_progress = "待购" if intent_active(item) else "未购买"
        elif item_purchases:
            purchase_progress = "订单已取消，结果待确认"
        elif not intent_active(item):
            purchase_progress = "未购买"
        else:
            purchase_progress = "待购"
        quote, reference_fen, reference_note = _reference_offer(item, offers, details, remaining_quantity)
        active_for_reference = remaining_quantity > 0 and intent_active(item)
        # 报价龄：页面展示价会过期，日期与账龄和金额一起可见，不伪装成实时价。
        reference_date = ""
        if active_for_reference and reference_fen is not None:
            evidence_date = _ymd(quote.get("evidence_at"))
            if evidence_date is None:
                undated_reference_count += 1
            elif read_date is None:
                # 无法定账龄时至少给出无歧义的全日期，不猜新鲜程度。
                undated_reference_count += 1
                reference_date = evidence_date.isoformat()
            else:
                if (read_date - evidence_date).days > STALE_REFERENCE_DAYS:
                    stale_items.append(str(item.get("name") or item["item_id"]))
                reference_date = (evidence_date.strftime("%m-%d") if evidence_date.year == read_date.year
                                  else evidence_date.isoformat())
        if active_for_reference:
            reference_active_count += 1
            if reference_fen is None:
                reference_missing_count += 1
            else:
                reference_priced_count += 1
                reference_subtotal_fen += reference_fen
        estimate_fen = reference_fen if active_for_reference else None
        legacy_price = cash["total_fen"] if purchased_quantity > 0 else estimate_fen
        rows.append({"item_id": item["item_id"], "name": str(item.get("name") or ""),
                     "display": {
                         "规格摘要": " / ".join(specs), "购买状态": purchase_progress,
                         "预估金额（元）": float(Decimal(estimate_fen) / 100) if estimate_fen is not None else None,
                         "净支出（元）": float(Decimal(cash["total_fen"]) / 100) if cash["total_fen"] is not None else None,
                         "参考价缺项标记": 1 if active_for_reference and reference_fen is None else 0,
                         "参考价日期": reference_date},
                     "legacy_display": {"价格（元）": float(Decimal(legacy_price) / 100) if legacy_price is not None else None},
                     "amounts": {"estimated_remaining_fen": estimate_fen, "net_spend_fen": cash["total_fen"],
                                 "net_spend_kind": "allocated" if cash["allocated"] else "direct",
                                 "issues": cash["issues"]},
                     "assistant_notes": {"金额概况": amount, "下一步": next_step,
                                         "价格说明": "；".join(reference_note) if active_for_reference else amount}})
    by_task = {t["task_id"]: t for t in payment_tasks}
    reference_note = "已录%d/%d项同规格参考报价；小计仅汇总已知金额，缺价项、未知运费与未核优惠需另核对" % (
        reference_priced_count, reference_active_count)
    reference_pricing = {"known_subtotal_fen": reference_subtotal_fen,
                                  "total_fen": reference_subtotal_fen if reference_missing_count == 0 else None,
                                  "priced_item_count": reference_priced_count,
                                  "missing_item_count": reference_missing_count,
                                  "active_item_count": reference_active_count,
                                  "complete": reference_missing_count == 0, "note": reference_note,
                                  "stale_days": STALE_REFERENCE_DAYS,
                                  "stale_item_count": len(stale_items),
                                  "stale_items": stale_items,
                                  "undated_item_count": undated_reference_count}
    outstanding = report["summary"]["outstanding"]
    net = report["summary"]["net_cash_spend_fen"]
    remaining = (outstanding["total_fen"] + reference_pricing["total_fen"]
                 if outstanding["total_fen"] is not None and reference_pricing["total_fen"] is not None else None)
    return {"summary": report["summary"], "reference_pricing": reference_pricing,
            "spending_overview": {"net_paid_fen": net, "committed_unpaid_fen": outstanding["total_fen"],
                                  "unbought_estimate_fen": reference_pricing["total_fen"],
                                  "known_unbought_subtotal_fen": reference_subtotal_fen,
                                  "estimated_remaining_fen": remaining,
                                  "estimated_total_fen": net + remaining if net is not None and remaining is not None else None,
                                  "missing_price_items": reference_missing_count, "stale_price_items": len(stale_items)},
            "items": rows,
            "tasks": [{"task_id": t["task_id"], "display": {
                "待付提示": (task_text(by_task[t["task_id"]]) if t["task_id"] in by_task else
                             ("付款义务已取消" if t["kind"] in PAYMENT_TASKS else ""))}}
                for t in tasks.values()],
            "note": "Display text is a cache of this full snapshot. Refresh after related writes; calculate from raw records."}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["money", "price", "unit-price", "budget", "review", "workbench", "overview"])
    parser.add_argument("--input", required=True, help="UTF-8 JSON path, or - for stdin")
    parser.add_argument("--budget", help="optional stated budget in yuan, e.g. 20000 or 20000.50; a conversational input, not ledger fact")
    args = parser.parse_args()
    try:
        raw = sys.stdin.read() if args.input == "-" else Path(args.input).read_text(encoding="utf-8")
        data = json.loads(raw, parse_float=Decimal)
        if not isinstance(data, dict):
            raise InputError("input root must be an object")
        budget_fen = None
        if args.budget is not None:
            if not re.fullmatch(r"\d+(?:\.\d{1,2})?", str(args.budget)):
                raise InputError("budget must be nonnegative yuan with at most two decimal places")
            budget_fen = int(Decimal(args.budget) * 100)
        result = {"money": money, "price": price, "unit-price": unit_price,
                  "budget": lambda d: budget(d, budget_fen),
                  "review": review, "workbench": workbench,
                  "overview": lambda d: workbench(d)["spending_overview"]}[args.command](data)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (InputError, OSError, ValueError, TypeError, KeyError, ArithmeticError) as error:
        message = str(error)
        if isinstance(error, ArithmeticError) and not isinstance(error, ValueError):
            message = "number out of the supported range: " + error.__class__.__name__
        elif not message:
            message = error.__class__.__name__
        print(json.dumps({"error": message}, ensure_ascii=False), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
