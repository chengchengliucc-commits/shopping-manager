#!/usr/bin/env python3
"""Install the pinned official dependency Skill and its platform CLI on first use."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import subprocess
import tempfile
import zipfile

from cli_backend import (BackendError, MissingCLI, cli_session, default_bin_dir,
                         inspect_cli, select_cli)

ROOT = Path(__file__).resolve().parents[1]
BUNDLE = ROOT / "assets" / "vendor" / "dbsheet.json"


def install_dependency_skill(skills_dir=None):
    manifest = json.loads(BUNDLE.read_text(encoding="utf-8"))
    archive = BUNDLE.parent / manifest["archive"]
    if archive.parent.resolve() != BUNDLE.parent.resolve():
        raise BackendError("invalid bundled archive path")
    if hashlib.sha256(archive.read_bytes()).hexdigest() != manifest["sha256"]:
        raise BackendError("bundled dbsheet archive checksum mismatch; restore the original distribution")
    skills_dir = Path(skills_dir) if skills_dir else Path(os.environ.get("CODEX_HOME", str(Path.home() / ".codex"))) / "skills"
    skills_dir.mkdir(parents=True, exist_ok=True)
    target = skills_dir / "dbsheet"
    with tempfile.TemporaryDirectory(prefix=".dbsheet-install-", dir=skills_dir) as directory:
        staging = Path(directory)
        seen = set()
        with zipfile.ZipFile(archive) as package:
            for entry in package.infolist():
                # The official v2.7.3 archive uses Windows backslashes on all platforms.
                relative = PurePosixPath(entry.filename.replace("\\", "/"))
                if (not relative.parts or relative.is_absolute() or ".." in relative.parts
                        or relative.parts[0] != "dbsheet" or any(":" in part for part in relative.parts)
                        or stat.S_ISLNK(entry.external_attr >> 16)):
                    raise BackendError("invalid path in bundled dbsheet archive")
                identity = str(relative).casefold()
                if identity in seen:
                    raise BackendError("duplicate path in bundled dbsheet archive")
                seen.add(identity)
                output = staging.joinpath(*relative.parts)
                if entry.is_dir() or entry.filename.endswith(("/", "\\")):
                    output.mkdir(parents=True, exist_ok=True)
                else:
                    output.parent.mkdir(parents=True, exist_ok=True)
                    output.write_bytes(package.read(entry))
        source = staging / "dbsheet"
        if not (source / "SKILL.md").is_file() or not (source / "scripts" / "setup.sh").is_file():
            raise BackendError("bundled dependency is incomplete")
        if target.exists() or target.is_symlink():
            for original in source.rglob("*"):
                if original.is_file():
                    existing = target / original.relative_to(source)
                    if not existing.is_file() or existing.is_symlink() or existing.read_bytes() != original.read_bytes():
                        raise BackendError("existing dbsheet Skill differs; preserve it and choose another --skills-dir")
            return target.resolve(), False, manifest
        source.rename(target)
    return target.resolve(), True, manifest


def installer_command(skill_path):
    if os.name == "nt":
        shell = shutil.which("powershell") or shutil.which("pwsh")
        if not shell:
            raise BackendError("PowerShell is required for the bundled Windows installer")
        return [shell, "-NoProfile", "-File", str(skill_path / "scripts" / "setup.ps1")]
    shell = shutil.which("bash") or shutil.which("sh")
    if not shell:
        raise BackendError("a POSIX shell is required for the bundled installer")
    return [shell, str(skill_path / "scripts" / "setup.sh")]


def bootstrap_environment(skills_dir=None, bin_dir=None, install_skill=False):
    preference = json.loads((ROOT / "config.json").read_text(encoding="utf-8")).get("cli", "auto")
    preference = os.environ.get("SHOPPING_CLI", preference)
    try:
        selected = select_cli(preference)
    except MissingCLI:
        if preference == "kdocs-cli":
            raise BackendError("only dbsheet-cli is bundled; use auto or install the explicitly selected kdocs-cli") from None
        selected = None
    skill_path, created, manifest = None, False, None
    if install_skill or not selected:
        skill_path, created, manifest = install_dependency_skill(skills_dir)
    installed_cli = False
    previous_path = os.environ.get("PATH", "")
    try:
        if not selected:
            destination = Path(bin_dir).expanduser().resolve() if bin_dir else default_bin_dir()
            environment = dict(os.environ, DBSHEET_CLI_VERSION=manifest["version"], DBSHEET_CLI_DIR=str(destination))
            try:
                result = subprocess.run(installer_command(skill_path), env=environment,
                                        capture_output=True, text=True, timeout=180)
            except (OSError, subprocess.SubprocessError):
                raise BackendError("official dbsheet installer did not finish; rerun bootstrap after checking network and system tools") from None
            if result.returncode:
                raise BackendError("official dbsheet installer failed, exit=" + str(result.returncode) +
                                   "; inspect " + str(skill_path / "scripts"))
            os.environ["PATH"] = str(destination) + os.pathsep + previous_path
            selected = select_cli("dbsheet-cli")
            installed_cli = True
        with cli_session(selected):
            info = inspect_cli(selected)
    finally:
        os.environ["PATH"] = previous_path
    return {"bootstrapped": True, "cli_installed": installed_cli,
            "dependency_skill": str(skill_path) if skill_path else None,
            "dependency_skill_installed": created, "doctor": info}
