import copy
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from contextlib import redirect_stderr, redirect_stdout
from unittest.mock import patch

sys.path[:0] = [str(Path(__file__).resolve().parents[1] / "scripts"), str(Path(__file__).parent)]
import cli_backend
import ledger
from test_ledger import Remote


class CliHarness:
    """Exercise the actual adapter/JSON-file boundary against a local service."""
    def __init__(self):
        self.remote = Remote()
        self.invocations = []
        self.authenticated = True
        self.missing = set()
        self.delay_create = False
        self.late_payload = None
        self.invalid_schema = False
        self.local_failure = None

    def __call__(self, argv, **kwargs):
        self.invocations.append(list(argv))
        args = argv[1:]
        result = SimpleNamespace(returncode=0, stdout="", stderr="")
        if args == self.local_failure:
            return SimpleNamespace(returncode=1, stdout="PRIVATE_TEST_TOKEN", stderr="PRIVATE_TEST_TOKEN")
        if args == ["--version"]:
            result.stdout = "2.7.3\n"
        elif args == ["--help"]:
            result.stderr = "  --file <path>      JSON input\n  --output <format>  JSON output\n"
        elif args == ["dbsheet", "--help"]:
            result.stderr = "\n".join("  " + action + "  description" for group in cli_backend.ACTION_GROUPS.values()
                                      for action in group if "dbsheet " + action not in self.missing)
        elif args == ["drive", "--help"]:
            result.stderr = "" if "drive create-empty-file" in self.missing else "  create-empty-file  description\n"
        elif args == ["auth", "status"]:
            result.stdout = json.dumps({"authenticated": self.authenticated, "token": "PRIVATE_TEST_TOKEN"})
        else:
            service, action = args[:2]
            assert args[-2:] == ["--output", "json"]
            payload = json.loads(Path(args[args.index("--file") + 1]).read_text())
            if self.delay_create and action == "create-records":
                self.delay_create = False
                self.late_payload = copy.deepcopy(payload)
                raise subprocess.TimeoutExpired(argv, 45)
            if self.invalid_schema and action == "get-schema":
                data = {"sheets": []}
            else:
                data = self.remote(service, action, payload)
            result.stdout = json.dumps({"code": 0, "data": data})
        return result


class BackendTests(unittest.TestCase):
    def setUp(self):
        self.env = patch.dict(os.environ, {}, clear=False)
        self.env.start()
        os.environ.pop("SHOPPING_CLI", None)
        self.addCleanup(self.env.stop)
        self.managed = tempfile.TemporaryDirectory()
        self.addCleanup(self.managed.cleanup)
        default_dir = patch.object(cli_backend, "default_bin_dir", return_value=Path(self.managed.name))
        default_dir.start()
        self.addCleanup(default_dir.stop)

    def invoke(self, arguments, harness, installed):
        out, err = io.StringIO(), io.StringIO()
        with patch.object(cli_backend.shutil, "which", side_effect=lambda name: name if name in installed else None), \
             patch.object(ledger.subprocess, "run", side_effect=harness), \
             patch.object(sys, "argv", ["ledger.py", *arguments]), redirect_stdout(out), redirect_stderr(err):
            code = ledger.main()
        return code, json.loads(out.getvalue() or err.getvalue())

    def binding(self, path, harness):
        with patch.object(ledger, "cli_name", return_value="dbsheet-cli"):
            binding = ledger.make_binding(harness.remote("dbsheet", "get-schema", {}), "synthetic-file")
        binding.pop("backend_contract")  # A v0.6.0 manifest must migrate without recreating resources.
        binding["cli_version"] = "2.7.3"
        ledger.save_json(path, binding)
        return binding

    def test_default_prefers_dbsheet_and_falls_back_only_when_it_is_absent(self):
        for installed, selected in ((set(cli_backend.SUPPORTED), "dbsheet-cli"), ({"kdocs-cli"}, "kdocs-cli")):
            harness = CliHarness()
            code, result = self.invoke(["doctor"], harness, installed)
            self.assertEqual(code, 0)
            self.assertEqual(result["cli"], selected)
            self.assertTrue(result["ready"]["create"])
            self.assertNotIn("PRIVATE_TEST_TOKEN", json.dumps(result))
            self.assertEqual({command[0] for command in harness.invocations}, {selected})

    def test_missing_both_tools_reports_installation_without_invoking_a_process(self):
        harness = CliHarness()
        code, result = self.invoke(["doctor"], harness, set())
        self.assertEqual(code, 2)
        self.assertIn("dbsheet-cli or kdocs-cli", result["error"])
        self.assertEqual(harness.invocations, [])

    def test_explicit_transport_override_and_legacy_fixed_config_do_not_silently_switch(self):
        with patch.object(cli_backend.shutil, "which", return_value="installed"):
            os.environ["SHOPPING_CLI"] = "kdocs-cli"
            self.assertEqual(cli_backend.select_cli("dbsheet-cli"), "kdocs-cli")
            os.environ["SHOPPING_CLI"] = "unknown-cli"
            with self.assertRaises(cli_backend.BackendError):
                cli_backend.select_cli()
        os.environ.pop("SHOPPING_CLI")
        with patch.object(cli_backend.shutil, "which", side_effect=lambda name: name if name == "kdocs-cli" else None):
            with self.assertRaises(cli_backend.BackendError):
                cli_backend.select_cli("dbsheet-cli")

    def test_selected_transport_stays_fixed_during_the_command(self):
        with cli_backend.cli_session("dbsheet-cli"), patch.object(cli_backend.shutil, "which", return_value=None):
            os.environ["SHOPPING_CLI"] = "kdocs-cli"
            self.assertEqual(ledger.cli_name(), "dbsheet-cli")

    def test_auth_failure_does_not_fallback_and_never_exposes_tokens(self):
        harness = CliHarness(); harness.authenticated = False
        code, result = self.invoke(["doctor"], harness, set(cli_backend.SUPPORTED))
        self.assertEqual(code, 2)
        self.assertFalse(result["ready"]["write"])
        self.assertEqual(result["auth_command"], "dbsheet-cli auth login")
        self.assertNotIn("PRIVATE_TEST_TOKEN", json.dumps(result))
        self.assertEqual({command[0] for command in harness.invocations}, {"dbsheet-cli"})
        with tempfile.TemporaryDirectory() as directory:
            code, result = self.invoke(["setup", "--name", "合成账本", "--binding", str(Path(directory) / "binding.json")],
                                       harness, set(cli_backend.SUPPORTED))
            self.assertEqual(code, 2)
            self.assertIn("auth login", result["error"])
            self.assertFalse(any(command[1:3] == ["drive", "create-empty-file"] for command in harness.invocations))

    def test_missing_write_or_setup_commands_do_not_disable_reading(self):
        harness = CliHarness(); harness.missing = {"dbsheet update-records", "drive create-empty-file"}
        code, result = self.invoke(["doctor"], harness, set(cli_backend.SUPPORTED))
        self.assertEqual(code, 0)
        self.assertTrue(result["ready"]["read"])
        self.assertFalse(result["ready"]["write"])
        self.assertFalse(result["ready"]["create"])
        self.assertIn("dbsheet update-records", result["missing_capabilities"]["write"])
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "binding.json"
            self.binding(path, harness)
            code, result = self.invoke(["sync", "--binding", str(path)], harness, set(cli_backend.SUPPORTED))
            self.assertEqual(code, 2)
            self.assertIn("lacks required capabilities", result["error"])
            self.assertFalse(any(command[1:3] == ["dbsheet", "update-records"] for command in harness.invocations))

    def test_absent_drive_service_only_blocks_creating_files(self):
        harness = CliHarness(); harness.local_failure = ["drive", "--help"]
        code, result = self.invoke(["doctor"], harness, set(cli_backend.SUPPORTED))
        self.assertEqual(code, 0)
        self.assertTrue(result["ready"]["setup"])
        self.assertFalse(result["ready"]["create"])
        self.assertNotIn("PRIVATE_TEST_TOKEN", json.dumps(result))

    def test_broken_primary_process_does_not_switch_or_echo_its_output(self):
        harness = CliHarness(); harness.local_failure = ["auth", "status"]
        code, result = self.invoke(["doctor"], harness, set(cli_backend.SUPPORTED))
        self.assertEqual(code, 2)
        self.assertIn("local check failed for auth status", result["error"])
        self.assertNotIn("PRIVATE_TEST_TOKEN", json.dumps(result))
        self.assertEqual({command[0] for command in harness.invocations}, {"dbsheet-cli"})

    def test_legacy_binding_can_continue_through_kdocs_with_same_schema_and_ids(self):
        with tempfile.TemporaryDirectory() as directory:
            harness = CliHarness(); path = Path(directory) / "binding.json"
            previous = self.binding(path, harness)
            code, result = self.invoke(["overview", "--binding", str(path)], harness, {"kdocs-cli"})
            self.assertEqual(code, 0)
            self.assertEqual(result["estimated_total_fen"], 0)
            current = json.loads(path.read_text())
            self.assertEqual(current["cli"], "kdocs-cli")
            self.assertEqual(current["tables"], previous["tables"])
            self.assertEqual(current["verified_cli_versions"], {"dbsheet-cli": "2.7.3", "kdocs-cli": "2.7.3"})
            self.assertFalse(any(action.startswith("create-") for action, _ in harness.remote.calls))

    def test_transport_switch_cannot_overwrite_a_binding_with_a_different_schema(self):
        with tempfile.TemporaryDirectory() as directory:
            harness = CliHarness(); path = Path(directory) / "binding.json"
            self.binding(path, harness); before = path.read_text()
            harness.invalid_schema = True
            code, result = self.invoke(["overview", "--binding", str(path)], harness, {"kdocs-cli"})
            self.assertEqual(code, 2)
            self.assertIn("bound table is missing", result["error"])
            self.assertEqual(path.read_text(), before)

    def test_cart_purchase_refund_use_the_same_json_transport_for_each_cli(self):
        for name in cli_backend.SUPPORTED:
            with self.subTest(cli=name), tempfile.TemporaryDirectory() as directory:
                harness = CliHarness(); path = Path(directory) / "binding.json"
                self.binding(path, harness)
                request_path = Path(directory) / "request.json"

                def execute(command, request):
                    ledger.save_json(request_path, request)
                    code, result = self.invoke([command, "--binding", str(path), "--input", str(request_path)], harness, {name})
                    self.assertEqual(code, 0, result)
                    return result

                cart = {"operation_id": "cart", "platform": "demo", "captured_at": "2026-10-19T12:00:00+08:00",
                        "items": [{"sku": "demo", "name": "合成商品", "quantity": 1, "price_fen": 10000, "condition": "全新"}]}
                self.assertEqual(execute("import-cart", cart)["spending_overview"]["estimated_total_fen"], 10000)
                binding = json.loads(path.read_text()); sid = binding["tables"]["items"]["sheet_id"]
                iid = harness.remote.records[sid][0]["fields"]["item_id"]
                execute("record-purchase", {"operation_id": "buy", "source_key": "receipt", "item_id": iid,
                                          "quantity": 1, "paid_fen": 9000, "payment_complete": True})
                sid = binding["tables"]["purchases"]["sheet_id"]
                pid = harness.remote.records[sid][0]["fields"]["purchase_id"]
                result = execute("record-refund", {"operation_id": "refund", "source_key": "refund-demo", "purchase_id": pid,
                                                   "amount_fen": 1000, "status": "confirmed"})
                self.assertEqual(result["spending_overview"]["net_paid_fen"], 8000)
                self.assertEqual({command[0] for command in harness.invocations}, {name})

    def test_transport_switch_preserves_unknown_write_journals_without_reissuing(self):
        with tempfile.TemporaryDirectory() as directory:
            harness = CliHarness(); path = Path(directory) / "binding.json"
            binding = self.binding(path, harness); request_path = Path(directory) / "request.json"
            ledger.save_json(request_path, {"operation_id": "cart", "platform": "demo", "captured_at": "2026-10-19T12:00:00+08:00",
                            "items": [{"sku": "demo", "name": "合成商品", "quantity": 1, "price_fen": 10000}]})
            args = ["import-cart", "--binding", str(path), "--input", str(request_path)]
            harness.delay_create = True
            code, _ = self.invoke(args, harness, set(cli_backend.SUPPORTED))
            self.assertEqual(code, 2)
            self.assertEqual({command[0] for command in harness.invocations}, {"dbsheet-cli"})
            code, _ = self.invoke(args, harness, {"kdocs-cli"})
            self.assertEqual(code, 2)
            creates = [command for command in harness.invocations if command[1:3] == ["dbsheet", "create-records"]]
            self.assertEqual(len(creates), 1)
            harness.remote("dbsheet", "create-records", harness.late_payload)
            code, result = self.invoke(args, harness, {"kdocs-cli"})
            self.assertEqual(code, 0, result)
            self.assertTrue(result["saved"])
            self.assertEqual(len(harness.remote.records[binding["tables"]["items"]["sheet_id"]]), 1)


if __name__ == "__main__":
    unittest.main()
