import copy
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

sys.path[:0] = [str(Path(__file__).resolve().parents[1] / "scripts"), str(Path(__file__).parent)]
import ledger
import shopping
import workflows
from test_ledger import Remote


def empty():
    return {"read_complete": True, "read_at": "2026-10-16T12:00:00+08:00",
            "items": [], "offers": [], "purchases": [], "events": [], "tasks": []}


def paid_item():
    data = empty()
    data["items"] = [{"item_id": "i", "name": "演示商品", "planned_quantity": 1, "source_key": "item-source"}]
    data["purchases"] = [{"purchase_id": "p", "name": "演示商品", "item_id": "i", "order_group_id": "g",
                          "quantity": 1, "order_status": "received", "retained_quantity": 1,
                          "source_key": "purchase-source", "details_json": {"item_paid_fen": 10000, "payment_complete": True}}]
    data["events"] = [{"event_id": "pay", "kind": "payment", "status": "confirmed", "amount_fen": 10000,
                       "target_type": "purchase", "target_id": "p", "source_key": "payment-source"}]
    return data


def quote(oid="o", amount=10000, **changes):
    return {"offer_id": oid, "item_id": "i", "name": "演示商品", "quantity": 1,
            "platform": "demo", "sku": "sku", "condition": "全新", "base_fen": amount,
            "basis": "item_price", "verification_status": "PAGE_DISPLAYED", **changes}


class AmountAndQuoteTests(unittest.TestCase):
    def test_refund_net_is_identical_with_or_without_item_paid_metadata(self):
        data = paid_item()
        data["events"].append({"event_id": "refund", "kind": "refund", "status": "confirmed", "amount_fen": 2000,
                               "target_type": "purchase", "target_id": "p"})
        first = shopping.workbench(data)
        data["purchases"][0]["details_json"].pop("item_paid_fen")
        second = shopping.workbench(data)
        for report in (first, second):
            self.assertEqual(report["summary"]["net_cash_spend_fen"], 8000)
            self.assertEqual(report["items"][0]["display"]["净支出（元）"], 80)
            self.assertIsNone(report["items"][0]["display"]["预估金额（元）"])

    def test_incomplete_or_nonconserving_shared_allocation_stays_unknown(self):
        data = paid_item()
        data["items"].append({"item_id": "other", "name": "另一商品", "planned_quantity": 1})
        data["purchases"].append({"purchase_id": "p2", "item_id": "other", "order_group_id": "g",
                                  "quantity": 1, "order_status": "received", "details_json": {"payment_complete": True}})
        data["events"][0].update(target_type="order_group", target_id="g", amount_fen=30000)
        for amount in (None, 1):
            data["purchases"][1]["details_json"]["item_paid_fen"] = amount
            result = shopping.workbench(data)
            self.assertEqual(result["summary"]["net_cash_spend_fen"], 30000)
            self.assertTrue(all(row["display"]["净支出（元）"] is None for row in result["items"]))
        data["purchases"][1]["details_json"]["item_paid_fen"] = 20000
        self.assertEqual([row["display"]["净支出（元）"] for row in shopping.workbench(data)["items"]], [100, 200])

    def test_shared_refund_needs_complete_refund_allocation(self):
        data = paid_item()
        data["items"].append({"item_id": "other", "name": "另一商品", "planned_quantity": 1})
        data["purchases"].append({"purchase_id": "p2", "item_id": "other", "order_group_id": "g", "quantity": 1,
                                  "order_status": "received", "details_json": {"payment_complete": True, "item_paid_fen": 20000}})
        data["events"][0].update(target_type="order_group", target_id="g", amount_fen=30000)
        data["events"].append({"event_id": "rf", "kind": "refund", "status": "confirmed", "amount_fen": 3000,
                               "target_type": "order_group", "target_id": "g"})
        self.assertTrue(all(row["display"]["净支出（元）"] is None for row in shopping.workbench(data)["items"]))
        data["purchases"][0]["details_json"]["item_refund_fen"] = 1000
        data["purchases"][1]["details_json"]["item_refund_fen"] = 2000
        self.assertEqual([row["display"]["净支出（元）"] for row in shopping.workbench(data)["items"]], [90, 180])

    def test_nested_amounts_are_validated(self):
        for amount in (-1, True, "10000", 1.5):
            data = paid_item(); data["purchases"][0]["details_json"]["item_paid_fen"] = amount
            with self.subTest(amount=amount), self.assertRaises(shopping.InputError):
                shopping.workbench(data)

    def test_paid_complete_purchase_needs_no_artificial_payment_task(self):
        result = shopping.workbench(paid_item())
        self.assertEqual(result["summary"]["outstanding"]["total_fen"], 0)
        self.assertTrue(result["summary"]["complete"])

    def test_returned_quantity_reopens_estimate_without_erasing_cash_history(self):
        data = paid_item(); data["purchases"][0]["retained_quantity"] = 0
        data["offers"] = [quote()]
        result = shopping.workbench(data)
        self.assertEqual(result["items"][0]["display"]["购买状态"], "待购")
        self.assertEqual(result["items"][0]["display"]["预估金额（元）"], 100)
        self.assertEqual(result["items"][0]["display"]["净支出（元）"], 100)

    def test_free_form_reason_does_not_deactivate_an_explicit_active_intent(self):
        data = empty(); data["items"] = [{"item_id": "i", "name": "演示商品", "planned_quantity": 1,
            "not_bought_reason": "还没选店铺", "details_json": {"intent_status": "active"}}]; data["offers"] = [quote()]
        self.assertEqual(shopping.workbench(data)["reference_pricing"]["total_fen"], 10000)

    def test_superseded_quote_is_excluded_and_a_pinned_old_quote_follows_update(self):
        data = empty(); data["items"] = [{"item_id": "i", "name": "演示商品", "planned_quantity": 1}]
        data["offers"] = [quote("old", 10000), quote("new", 12000, supersedes_offer_id="old")]
        for selected in (None, "old"):
            data["items"][0]["selected_offer_id"] = selected
            self.assertEqual(shopping.workbench(data)["reference_pricing"]["total_fen"], 12000)

    def test_quote_cycle_is_rejected(self):
        data = empty(); data["items"] = [{"item_id": "i", "name": "演示商品", "planned_quantity": 1}]
        data["offers"] = [quote("a", supersedes_offer_id="b"), quote("b", supersedes_offer_id="a")]
        with self.assertRaisesRegex(shopping.InputError, "cycle"):
            shopping.workbench(data)

    def test_only_explicit_linear_unit_price_can_scale_quantity(self):
        data = empty(); data["items"] = [{"item_id": "i", "name": "演示商品", "planned_quantity": 2}]
        data["offers"] = [quote(shipping_fen=500)]
        self.assertIsNone(shopping.workbench(data)["reference_pricing"]["total_fen"])
        data["offers"][0]["details_json"] = {"quantity_pricing": "linear", "unit_price_fen": 10000}
        self.assertEqual(shopping.workbench(data)["reference_pricing"]["total_fen"], 20500)

    def test_overview_adds_paid_unpaid_and_unbought_without_double_counting(self):
        data = paid_item(); data["purchases"][0]["details_json"] = {}
        data["tasks"] = [{"task_id": "deposit", "kind": "deposit", "status": "paid", "amount_fen": 10000,
                          "target_type": "purchase", "target_id": "p", "payment_event_ids": ["pay"]},
                         {"task_id": "balance", "kind": "balance", "status": "active", "amount_fen": 79900,
                          "target_type": "purchase", "target_id": "p", "payment_event_ids": []}]
        data["items"].append({"item_id": "other", "name": "待买商品", "planned_quantity": 1})
        data["offers"] = [quote(item_id="other", amount=30000)]
        result = shopping.workbench(data)["spending_overview"]
        self.assertEqual((result["net_paid_fen"], result["committed_unpaid_fen"], result["unbought_estimate_fen"]), (10000, 79900, 30000))
        self.assertEqual(result["estimated_total_fen"], 119900)


class BusinessOperationTests(unittest.TestCase):
    def cart_request(self, count=2, price=20000, **changes):
        return {"operation_id": "cart-one", "platform": "demo", "captured_at": "2026-10-16T12:00:00+08:00",
                "complete": True, "items": [{"sku": "sku-1", "name": "演示纸品", "quantity": count,
                "price_fen": price, "condition": "全新", "unit": "箱"}], **changes}

    def test_partial_purchase_and_reimport_preserve_total_intent_quantity(self):
        data = workflows.merged_snapshot(empty(), workflows.cart(empty(), self.cart_request()))
        iid = data["items"][0]["item_id"]
        bought = {"operation_id": "buy-one", "source_key": "order-demo", "item_id": iid, "quantity": 1,
                  "paid_fen": 10000, "payment_complete": True}
        data = workflows.merged_snapshot(data, workflows.purchase(data, bought))
        request = self.cart_request(1, 12000, operation_id="cart-two", captured_at="2026-10-16T13:00:00+08:00")
        data = workflows.merged_snapshot(data, workflows.cart(data, request))
        result = shopping.workbench(data)
        self.assertEqual(len(data["items"]), 1)
        self.assertEqual(data["items"][0]["planned_quantity"], 2)
        self.assertEqual(result["items"][0]["display"]["购买状态"], "部分购买")
        self.assertEqual(result["spending_overview"]["estimated_total_fen"], 22000)
        again = workflows.merged_snapshot(data, workflows.cart(data, request))
        self.assertEqual(len(again["items"]), 1)
        self.assertEqual(again["items"][0]["planned_quantity"], 2)

    def test_older_cart_cannot_overwrite_and_removal_never_invents_purchase(self):
        data = workflows.merged_snapshot(empty(), workflows.cart(empty(), self.cart_request()))
        with self.assertRaisesRegex(shopping.InputError, "older cart"):
            workflows.cart(data, self.cart_request(captured_at="2026-10-15T12:00:00+08:00"))
        operation = workflows.cart(data, self.cart_request(items=[]))
        self.assertEqual(len(operation["notes"]["removed_from_cart_needs_decision"]), 1)
        self.assertEqual(operation["batches"], [])

    def test_cross_platform_candidate_does_not_replace_intent_quantity(self):
        data = workflows.merged_snapshot(empty(), workflows.cart(empty(), self.cart_request()))
        iid = data["items"][0]["item_id"]
        request = self.cart_request(1, 9000, platform="other")
        request["items"][0]["item_id"] = iid
        request["items"][0]["quantity_mode"] = "candidate"
        operation = workflows.cart(data, request)
        result = workflows.merged_snapshot(data, operation)
        self.assertEqual(len(result["items"]), 1)
        self.assertEqual(result["items"][0]["planned_quantity"], 2)
        self.assertEqual(len(result["offers"]), 2)

    def test_refund_pending_to_received_updates_same_transaction(self):
        data = paid_item()
        request = {"operation_id": "refund-start", "source_key": "refund-source", "purchase_id": "p", "amount_fen": 2000}
        data = workflows.merged_snapshot(data, workflows.refund(data, request))
        self.assertEqual(shopping.budget(data)["net_cash_spend_fen"], 10000)
        request.update(operation_id="refund-received", status="confirmed")
        data = workflows.merged_snapshot(data, workflows.refund(data, request))
        self.assertEqual(len(data["events"]), 2)
        self.assertEqual(shopping.budget(data)["net_cash_spend_fen"], 8000)
        with self.assertRaisesRegex(shopping.InputError, "corrections"):
            workflows.refund(data, dict(request, amount_fen=3000))

    def test_full_paid_workflow_needs_no_manual_task(self):
        request = {"operation_id": "buy-one", "source_key": "oral-example", "name": "演示商品", "quantity": 1,
                   "paid_fen": 10000, "payment_complete": True}
        data = workflows.merged_snapshot(empty(), workflows.purchase(empty(), request))
        self.assertEqual(data["tasks"], [])
        self.assertTrue(shopping.budget(data)["complete"])

    def test_executor_is_idempotent_across_the_whole_operation(self):
        remote = Remote()
        with tempfile.TemporaryDirectory() as directory, patch.object(ledger, "cli_name", return_value="dbsheet-cli"), patch.object(ledger, "call", side_effect=remote):
            binding = ledger.make_binding(remote("dbsheet", "get-schema", {}), "demo")
            path = Path(directory) / "binding.json"
            first = ledger.execute_workflow(binding, path, "import-cart", self.cart_request())
            second = ledger.execute_workflow(binding, path, "import-cart", self.cart_request())
            self.assertTrue(first["saved"] and second["saved"])
            self.assertEqual(len(remote.records[binding["tables"]["items"]["sheet_id"]]), 1)
            self.assertEqual(len(remote.records[binding["tables"]["offers"]["sheet_id"]]), 1)

    def test_saved_chinese_statuses_support_refund_confirmation_and_old_operation_replay(self):
        remote = Remote()
        with tempfile.TemporaryDirectory() as directory, patch.object(ledger, "cli_name", return_value="dbsheet-cli"), patch.object(ledger, "call", side_effect=remote):
            binding = ledger.make_binding(remote("dbsheet", "get-schema", {}), "demo")
            path = Path(directory) / "binding.json"
            original_cart = self.cart_request()
            ledger.execute_workflow(binding, path, "import-cart", original_cart)
            iid = ledger.read_snapshot(binding)["items"][0]["item_id"]
            purchase = {"operation_id": "buy", "source_key": "receipt", "item_id": iid,
                        "quantity": 1, "paid_fen": 10000, "payment_complete": True}
            ledger.execute_workflow(binding, path, "record-purchase", purchase)
            saved = ledger.read_snapshot(binding)
            pid, eid = saved["purchases"][0]["purchase_id"], saved["events"][0]["event_id"]
            # A receipt enriches the existing payment after its enum was stored in Chinese.
            enrichment = {"operation_id": "enrich", "source_key": "receipt-photo", "purchase_id": pid,
                          "quantity": 1, "order_no": "DEMO-1", "payment_complete": True,
                          "payment": {"event_id": eid, "amount_fen": 10000, "identity_key": "payment-demo-1"}}
            ledger.execute_workflow(binding, path, "record-purchase", enrichment)
            latest_cart = self.cart_request(1, 12000, operation_id="cart-new", captured_at="2026-10-16T13:00:00+08:00")
            ledger.execute_workflow(binding, path, "import-cart", latest_cart)
            pending = {"operation_id": "refund-pending", "source_key": "refund-demo", "purchase_id": pid,
                       "amount_fen": 2000}
            self.assertEqual(ledger.execute_workflow(binding, path, "record-refund", pending)["spending_overview"]["net_paid_fen"], 10000)
            confirmed = dict(pending, operation_id="refund-confirmed", status="confirmed")
            self.assertEqual(ledger.execute_workflow(binding, path, "record-refund", confirmed)["spending_overview"]["estimated_total_fen"], 20000)
            for command, request in (("import-cart", original_cart), ("record-purchase", purchase),
                                     ("record-refund", pending), ("record-refund", confirmed)):
                result = ledger.execute_workflow(binding, path, command, request)
                self.assertTrue(result["already_processed"])
                self.assertEqual(result["spending_overview"]["estimated_total_fen"], 20000)
            final = ledger.read_snapshot(binding)
            self.assertEqual((len(final["items"]), len(final["purchases"]), len(final["events"])), (1, 1, 2))
            self.assertEqual(final["offers"][0]["base_fen"], 12000)

    def test_pause_and_resume_do_not_require_a_free_form_reason(self):
        data = workflows.merged_snapshot(empty(), workflows.cart(empty(), self.cart_request()))
        iid = data["items"][0]["item_id"]
        paused = workflows.merged_snapshot(data, workflows.decision(data, {
            "operation_id": "pause", "item_id": iid, "intent_status": "paused"}))
        self.assertEqual(shopping.workbench(paused)["spending_overview"]["unbought_estimate_fen"], 0)
        resumed = workflows.merged_snapshot(paused, workflows.decision(paused, {
            "operation_id": "resume", "item_id": iid, "intent_status": "active"}))
        self.assertEqual(shopping.workbench(resumed)["spending_overview"]["unbought_estimate_fen"], 20000)

    def test_later_balance_payments_settle_existing_stages_after_remote_readback(self):
        remote = Remote()
        with tempfile.TemporaryDirectory() as directory, patch.object(ledger, "cli_name", return_value="dbsheet-cli"), patch.object(ledger, "call", side_effect=remote):
            binding = ledger.make_binding(remote("dbsheet", "get-schema", {}), "demo")
            path = Path(directory) / "binding.json"
            first = {"operation_id": "deposit", "source_key": "order-deposit", "name": "演示预售商品", "quantity": 1,
                     "paid_fen": 5000, "payment_identity": "deposit-payment", "remaining_fen": 15000}
            result = ledger.execute_workflow(binding, path, "record-purchase", first)
            self.assertEqual(result["spending_overview"]["estimated_total_fen"], 20000)
            saved = ledger.read_snapshot(binding)
            pid = saved["purchases"][0]["purchase_id"]
            balance = next(t["task_id"] for t in shopping.budget(saved)["payment_tasks"] if t["kind"] == "balance")
            partial = {"operation_id": "partial-balance", "source_key": "order-partial", "purchase_id": pid,
                       "payment": {"amount_fen": 5000, "identity_key": "partial-payment", "task_id": balance},
                       "remaining_fen": 10000}
            result = ledger.execute_workflow(binding, path, "record-purchase", partial)
            self.assertEqual(result["spending_overview"]["committed_unpaid_fen"], 10000)
            final = {"operation_id": "final-balance", "source_key": "order-final", "purchase_id": pid,
                     "paid_fen": 10000, "payment_identity": "final-payment", "payment_complete": True}
            result = ledger.execute_workflow(binding, path, "record-purchase", final)
            self.assertEqual(result["spending_overview"]["net_paid_fen"], 20000)
            self.assertEqual(result["spending_overview"]["committed_unpaid_fen"], 0)
            saved = ledger.read_snapshot(binding)
            self.assertEqual((len(saved["purchases"]), len(saved["events"]), len(saved["tasks"])), (1, 3, 2))
            self.assertTrue(shopping.budget(saved)["complete"])
            final["operation_id"] = "same-payment-new-receipt"
            ledger.execute_workflow(binding, path, "record-purchase", final)
            self.assertEqual(len(ledger.read_snapshot(binding)["events"]), 3)

    def test_settlement_cannot_leave_an_existing_balance_unpaid(self):
        request = {"operation_id": "deposit", "source_key": "order-deposit", "name": "演示预售商品", "quantity": 1,
                   "paid_fen": 5000, "remaining_fen": 15000}
        data = workflows.merged_snapshot(empty(), workflows.purchase(empty(), request))
        pid = data["purchases"][0]["purchase_id"]
        with self.assertRaisesRegex(shopping.InputError, "unpaid stage"):
            workflows.purchase(data, {"operation_id": "bad-final", "source_key": "another-payment", "purchase_id": pid,
                                     "paid_fen": 10000, "payment_complete": True})

    def test_business_operation_resumes_after_late_payment_without_repeating_it(self):
        class LatePayment(Remote):
            pending = None
            failed = False

            def __call__(self, service, action, payload):
                event_sheet = next(s["id"] for s in self.sheets if s["name"] == "交易流水")
                if action == "create-records" and payload["sheet_id"] == event_sheet and not self.failed:
                    self.failed = True
                    self.pending = copy.deepcopy(payload)
                    self.calls.append((action, copy.deepcopy(payload)))
                    raise ledger.LedgerError("request outcome unknown")
                return super().__call__(service, action, payload)

        remote = LatePayment()
        request = {"operation_id": "bought", "source_key": "receipt", "name": "演示商品", "quantity": 1,
                   "paid_fen": 10000, "payment_complete": True}
        with tempfile.TemporaryDirectory() as directory, patch.object(ledger, "cli_name", return_value="dbsheet-cli"), patch.object(ledger, "call", side_effect=remote):
            binding = ledger.make_binding(remote("dbsheet", "get-schema", {}), "demo")
            path = Path(directory) / "binding.json"
            with self.assertRaises(ledger.LedgerError):
                ledger.execute_workflow(binding, path, "record-purchase", request)
            item = ledger.read_snapshot(binding)["items"][0]
            ledger.execute_workflow(binding, path, "set-intent", {"operation_id": "pause-later",
                                    "item_id": item["item_id"], "intent_status": "paused"})
            sid = remote.pending["sheet_id"]
            remote.records[sid].append({"id": "late-pay", "fields": copy.deepcopy(remote.pending["records"][0]["fields"])})
            result = ledger.execute_workflow(binding, path, "record-purchase", request)
            self.assertTrue(result["saved"])
            self.assertEqual(result["spending_overview"]["net_paid_fen"], 10000)
            self.assertEqual(sum(action == "create-records" and p["sheet_id"] == sid for action, p in remote.calls), 1)
            final = ledger.read_snapshot(binding)
            self.assertEqual(final["items"][0]["details_json"]["intent_status"], "paused")

    def test_repair_adopts_named_rows_but_reports_missing_quantity(self):
        remote = Remote()
        with tempfile.TemporaryDirectory() as directory, patch.object(ledger, "cli_name", return_value="dbsheet-cli"), patch.object(ledger, "call", side_effect=remote):
            binding = ledger.make_binding(remote("dbsheet", "get-schema", {}), "demo")
            sheet = binding["tables"]["items"]["sheet_id"]
            remote.records[sheet] = [{"id": "r1", "fields": {"name": "有效商品", "planned_quantity": 2}},
                                      {"id": "r2", "fields": {"name": "未给数量"}}]
            result = ledger.repair_items(binding, Path(directory) / "binding.json")
            self.assertEqual(len(result["repaired"]), 1)
            self.assertEqual(result["needs_input"][0]["record_id"], "r2")
            self.assertEqual(len(remote.records[sheet]), 2)

    def test_unknown_request_is_not_replayed_even_under_a_new_operation_id(self):
        remote = Remote(); remote.timeout_without_write = True
        with tempfile.TemporaryDirectory() as directory, patch.object(ledger, "cli_name", return_value="dbsheet-cli"), patch.object(ledger, "call", side_effect=remote):
            binding = ledger.make_binding(remote("dbsheet", "get-schema", {}), "demo")
            path = Path(directory) / "binding.json"
            request = {"operation_id": "first", "table": "items", "records": [{"fields": {
                "item_id": "i", "name": "演示商品", "planned_quantity": 1, "source_key": "source"}}]}
            with self.assertRaises(ledger.LedgerError): ledger.apply_records(binding, path, request)
            with self.assertRaisesRegex(ledger.LedgerError, "earlier write"):
                ledger.apply_records(binding, path, dict(request, operation_id="another-id"))
            self.assertEqual(sum(action == "create-records" for action, _ in remote.calls), 1)


class SetupRemote(Remote):
    def __init__(self):
        super().__init__(); self.sheets = []; self.records = {}; self.file_creates = 0

    def __call__(self, service, action, payload):
        if service == "drive":
            self.file_creates += 1
            return {"id": "new-file"}
        if action == "create-sheet":
            sid = len(self.sheets) + 1
            fields = [{**copy.deepcopy(f), "id": "f" + str(i + 1)} for i, f in enumerate(payload["fields"])]
            self.sheets.append({"id": sid, "name": payload["name"], "fields": fields,
                                "views": [{"id": "default", "name": "默认视图", "type": "Grid"}]})
            self.records[sid] = []
            return {"id": sid}
        if action in {"create-fields", "create-view", "update-view", "update-sheet", "update-fields"}:
            sheet = next(s for s in self.sheets if s["id"] == payload["sheet_id"])
            if action == "create-fields":
                for field in payload["fields"]:
                    self.assert_unique(sheet, field["name"])
                    sheet["fields"].append({**copy.deepcopy(field), "id": "f" + str(len(sheet["fields"]) + 1)})
                    if field["type"] == "Link":
                        target = next(s for s in self.sheets if s["id"] == field["linkSheet"])
                        if not any(f["name"] == sheet["name"] for f in target["fields"]):
                            target["fields"].append({"id": "f" + str(len(target["fields"]) + 1), "name": sheet["name"], "type": "Link"})
            elif action == "create-view":
                sheet["views"].append({"id": "v" + str(len(sheet["views"]) + 1), "name": payload["name"], "type": payload["type"]})
            elif action == "update-view":
                if set(payload["order_fields"]) != {f["name"] for f in sheet["fields"]}:
                    raise AssertionError("view omitted a field")
                view = next(v for v in sheet["views"] if v["id"] == payload["view_id"])
                view.update(name=payload.get("name", view["name"]), fieldsAttribute=payload["fields_attribute"])
            elif action == "update-fields":
                for update in payload["fields"]:
                    next(f for f in sheet["fields"] if f["id"] == update["id"]).update(update)
            return {"saved": True}
        return super().__call__(service, action, payload)

    def assert_unique(self, sheet, name):
        if any(f["name"] == name for f in sheet["fields"]):
            raise AssertionError("duplicate field: " + name)


class SetupTests(unittest.TestCase):
    def test_setup_is_additive_repeatable_and_preserves_amount_field_id(self):
        remote = SetupRemote()
        with tempfile.TemporaryDirectory() as directory, patch.object(ledger, "cli_name", return_value="dbsheet-cli"), patch.object(ledger, "call", side_effect=remote), patch.object(ledger.subprocess, "run", return_value=SimpleNamespace(stdout="2.7.3", returncode=0)):
            path = Path(directory) / "binding.json"
            first = ledger.setup_ledger(path, name="演示账本")
            count = sum(len(s["fields"]) for s in remote.sheets)
            binding = json.loads(path.read_text())
            sid = binding["tables"]["items"]["sheet_id"]
            sheet = next(s for s in remote.sheets if s["id"] == sid)
            amount = next(f for f in sheet["fields"] if f["name"] == "预估金额（元）")
            amount_id = amount["id"]; amount["name"] = "价格（元）"
            product_name = next(f for f in sheet["fields"] if f["name"] == "商品名称")
            name_id = product_name["id"]; product_name["name"] = "需求名称"
            remote.records[sid].append({"id": "user-record", "fields": {}})
            second = ledger.setup_ledger(path)
            self.assertTrue(first["ready"] and second["ready"])
            self.assertEqual(remote.file_creates, 1)
            self.assertEqual(sum(len(s["fields"]) for s in remote.sheets), count)
            self.assertEqual(next(f for f in sheet["fields"] if f["name"] == "预估金额（元）")["id"], amount_id)
            self.assertEqual(next(f for f in sheet["fields"] if f["name"] == "商品名称")["id"], name_id)
            self.assertEqual(len(remote.records[sid]), 1)

    def test_ledger_discovery_prefers_workspace_and_requires_an_ambiguous_choice(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            registry = root / "ledgers.json"
            first = root / "one" / "binding.json"
            second = root / "two" / "binding.json"
            ledger.save_json(first, {"file_id": "one"})
            ledger.remember_binding(first, {"file_id": "one"}, registry)
            self.assertEqual(ledger.resolve_binding(workspace=root, registry=registry), first.resolve())
            ledger.save_json(second, {"file_id": "two"})
            ledger.remember_binding(second, {"file_id": "two"}, registry)
            with self.assertRaisesRegex(ledger.LedgerError, "choose a ledger"):
                ledger.resolve_binding(workspace=root, registry=registry)
            local = root / ".shopping-ledger" / "binding.json"
            ledger.save_json(local, {"file_id": "local"})
            self.assertEqual(ledger.resolve_binding(workspace=root, registry=registry), local.resolve())


if __name__ == "__main__":
    unittest.main()
