import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import zipfile

sys.path[:0] = [str(Path(__file__).resolve().parents[1] / "scripts"), str(Path(__file__).parent)]
import bootstrap
import cli_backend
from test_cli_backend import CliHarness


class BootstrapTests(unittest.TestCase):
    def test_real_bundled_archive_extracts_windows_paths_and_reuses_identical_installation(self):
        with tempfile.TemporaryDirectory() as directory:
            target, created, manifest = bootstrap.install_dependency_skill(directory)
            self.assertTrue(created)
            self.assertEqual(manifest["version"], "2.7.3")
            self.assertTrue((target / "SKILL.md").is_file())
            self.assertTrue((target / "scripts" / "setup.sh").is_file())
            self.assertTrue((target / "references" / "auth.md").is_file())
            self.assertFalse(any("\\" in path.name for path in target.rglob("*")))
            extra = target / "user-note.txt"; extra.write_text("preserve")
            _, created, _ = bootstrap.install_dependency_skill(directory)
            self.assertFalse(created)
            self.assertEqual(extra.read_text(), "preserve")
            (target / "SKILL.md").write_text("personal version")
            with self.assertRaisesRegex(cli_backend.BackendError, "existing dbsheet Skill differs"):
                bootstrap.install_dependency_skill(directory)
            self.assertEqual((target / "SKILL.md").read_text(), "personal version")

    def test_tampered_distribution_stops_before_installing(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "bundle.zip").write_bytes(b"tampered")
            manifest = root / "bundle.json"
            manifest.write_text(json.dumps({"archive": "bundle.zip", "sha256": "0" * 64}))
            with patch.object(bootstrap, "BUNDLE", manifest), self.assertRaisesRegex(cli_backend.BackendError, "checksum mismatch"):
                bootstrap.install_dependency_skill(root / "skills")
            self.assertFalse((root / "skills").exists())

    def test_zip_path_traversal_is_rejected_after_windows_separator_normalization(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            archive = root / "bundle.zip"
            with zipfile.ZipFile(archive, "w") as package:
                package.writestr("dbsheet\\..\\outside.txt", "bad")
            manifest = root / "bundle.json"
            manifest.write_text(json.dumps({"archive": archive.name, "sha256": hashlib.sha256(archive.read_bytes()).hexdigest()}))
            with patch.object(bootstrap, "BUNDLE", manifest), self.assertRaisesRegex(cli_backend.BackendError, "invalid path"):
                bootstrap.install_dependency_skill(root / "skills")
            self.assertFalse((root / "skills" / "outside.txt").exists())

    def test_fresh_user_installs_from_bundle_and_cli_remains_discoverable_outside_path(self):
        with tempfile.TemporaryDirectory(prefix="shopping bootstrap ") as directory:
            root = Path(directory).resolve(); binary_dir = root / "bin"
            harness = CliHarness(); installs = []

            def run(argv, **kwargs):
                if str(argv[-1]).endswith("setup.sh"):
                    installs.append((argv, kwargs["env"]))
                    binary_dir.mkdir()
                    (binary_dir / "dbsheet-cli").write_text("fake executable")
                    (binary_dir / "dbsheet-cli").chmod(0o755)
                    return SimpleNamespace(returncode=0, stdout="installed", stderr="")
                return harness(argv, **kwargs)

            def which(name):
                return "/bin/sh" if name in {"sh", "bash"} else None

            environment = dict(os.environ); environment.pop("SHOPPING_CLI", None)
            with patch.dict(os.environ, environment, clear=True), patch.object(cli_backend, "default_bin_dir", return_value=binary_dir), \
                 patch.object(cli_backend.shutil, "which", side_effect=which), patch.object(bootstrap.subprocess, "run", side_effect=run):
                previous_path = os.environ.get("PATH")
                result = bootstrap.bootstrap_environment(root / "skills", binary_dir)
                self.assertTrue(result["cli_installed"])
                self.assertTrue(result["doctor"]["authenticated"])
                self.assertEqual(result["doctor"]["cli"], "dbsheet-cli")
                self.assertEqual(os.environ.get("PATH"), previous_path)
                self.assertEqual(cli_backend.select_cli(), "dbsheet-cli")
                self.assertEqual(cli_backend.cli_executable("dbsheet-cli"), str(binary_dir / "dbsheet-cli"))
                self.assertEqual(result["doctor"]["auth_argv"], [str(binary_dir / "dbsheet-cli"), "auth", "login"])
            self.assertEqual(len(installs), 1)
            self.assertEqual(installs[0][1]["DBSHEET_CLI_VERSION"], "2.7.3")
            self.assertEqual(installs[0][1]["DBSHEET_CLI_DIR"], str(binary_dir))

    def test_existing_kdocs_is_reused_without_installing_dbsheet(self):
        harness = CliHarness()
        with tempfile.TemporaryDirectory() as directory, patch.object(cli_backend, "default_bin_dir", return_value=Path(directory)), \
             patch.object(cli_backend.shutil, "which", side_effect=lambda name: name if name == "kdocs-cli" else None), \
             patch.object(bootstrap.subprocess, "run", side_effect=harness), patch.dict(os.environ, {"SHOPPING_CLI": "auto"}):
            result = bootstrap.bootstrap_environment()
            self.assertFalse(result["cli_installed"])
            self.assertIsNone(result["dependency_skill"])
            self.assertEqual(result["doctor"]["cli"], "kdocs-cli")
            self.assertEqual({command[0] for command in harness.invocations}, {"kdocs-cli"})


if __name__ == "__main__":
    unittest.main()
