import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import ledger


class Remote:
    """In-memory service with the observed CLI's JSON-text record fields."""
    def __init__(self):
        self.sheets = []
        for i, t in enumerate(ledger.TABLES, 1):
            fields = []
            for f in t["fields"]:
                entry = {"id": f["key"], "name": f["name"], "type": f["suggested_cli_type"]}
                if f.get("suggested_cli_type") == "SingleSelect":
                    options = f.get("items") or [{"value": v} for v in f.get("suggested_options", [])]
                    entry["items"] = copy.deepcopy(options)
                    entry["autoAddItem"] = True
                fields.append(entry)
            core_names = {f["name"] for f in t["fields"]}
            for definition in ledger.DISPLAY_FIELDS.get(t["logical_name"], []):
                if definition["name"] in core_names or definition["name"] in {x["name"] for x in fields}:
                    continue
                entry = {"id": "d-" + definition["name"], "name": definition["name"], "type": definition["type"]}
                if definition["type"] == "SingleSelect":
                    entry["items"] = copy.deepcopy(definition.get("items") or [])
                    entry["autoAddItem"] = True
                fields.append(entry)
            self.sheets.append({"id": i, "name": t["name"], "recordsCount": 0, "fields": fields})
        self.records = {s["id"]: [] for s in self.sheets}
        self.calls = []
        self.timeout_after_write = False
        self.partial_failure = False
        self.timeout_without_write = False

    def __call__(self, service, action, payload):
        self.calls.append((action, copy.deepcopy(payload)))
        if action == "get-schema":
            sheets = copy.deepcopy(self.sheets)
            for sheet in sheets:
                sheet["recordsCount"] = len(self.records[sheet["id"]])
            return {"sheets": sheets}
        rows = self.records[payload["sheet_id"]]
        if action == "records-list":
            offset, size = int(payload.get("page_token") or 0), payload.get("page_size", 100)
            selected = copy.deepcopy(rows[offset:offset + size])
            for row in selected:
                row["fields"] = json.dumps(row["fields"], ensure_ascii=False)
            return {"records": selected, "page_token": str(offset + size) if len(rows) > offset + size else ""}
        if self.timeout_without_write:
            raise ledger.LedgerError("timeout")
        if action == "update-fields":
            sheet = next(s for s in self.sheets if s["id"] == payload["sheet_id"])
            for patch in payload["fields"]:
                target = next(f for f in sheet["fields"] if f["id"] == patch["id"])
                if "items" in patch:
                    target["items"] = copy.deepcopy(patch["items"])
                if "type" in patch:
                    target["type"] = patch["type"]
            return {"updated": True}
        if action == "create-records":
            for row in payload["records"]:
                rows.append({"id": "r" + str(len(rows) + 1), "fields": copy.deepcopy(row["fields"])})
                if self.partial_failure:
                    raise ledger.LedgerError("partial failure")
        elif action == "update-records":
            for row in payload["records"]:
                actual = next(r for r in rows if r["id"] == row["id"])
                actual["fields"].update(row["fields"])
        else:
            raise AssertionError(action)
        if self.timeout_after_write:
            raise ledger.LedgerError("timeout")
        return {"records": []}


class LedgerAdapterTests(unittest.TestCase):
    def setUp(self):
        self.remote = Remote()
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "binding.json"
        self.name_patch = patch.object(ledger, "cli_name", return_value="dbsheet-cli")
        self.call_patch = patch.object(ledger, "call", side_effect=self.remote)
        self.name_patch.start()
        self.call_patch.start()
        self.addCleanup(self.name_patch.stop)
        self.addCleanup(self.call_patch.stop)
        self.binding = ledger.make_binding(self.remote("dbsheet", "get-schema", {}), "test-file")

    def batch(self, **changes):
        data = {"operation_id": "op-1", "table": "items", "records": [{"fields": {
            "item_id": "i", "name": "商品", "planned_quantity": 1,
            "source_key": "receipt-1#line-1"}}]}
        data.update(changes)
        return data

    def test_envelopes_reject_inner_business_failure(self):
        self.assertEqual(ledger.unwrap({"code": 0, "data": {"result": "ok", "detail": {"sheets": []}}}),
                         {"sheets": []})
        for raw in ({"code": 0, "data": {"result": "error", "detail": {"sheets": []}}},
                    {"code": 0, "data": {"code": 403, "data": {}}}, {"code": False, "data": {}}):
            with self.subTest(raw=raw), self.assertRaises(ledger.LedgerError):
                ledger.unwrap(raw)

    def test_repeated_operation_does_not_create_duplicates_and_uses_chinese_options(self):
        first = ledger.apply_records(self.binding, self.path, self.batch())
        second = ledger.apply_records(self.binding, self.path, self.batch())
        self.assertEqual(first["created"], 1)
        self.assertEqual(second["created"], 0)
        rows = self.remote.records[self.binding["tables"]["items"]["sheet_id"]]
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["fields"]["name"], "商品")
        self.assertNotIn("operation_id", rows[0]["fields"])

    def test_json_text_update_keeps_serialized_wire_value(self):
        data = self.batch()
        data["records"][0]["fields"]["details_json"] = {"intent_status": "active"}
        ledger.apply_records(self.binding, self.path, data)
        updated = copy.deepcopy(data)
        updated["operation_id"] = "pause"
        updated["records"][0]["fields"]["details_json"] = {"intent_status": "paused"}
        ledger.apply_records(self.binding, self.path, updated)
        request = next(payload for action, payload in self.remote.calls if action == "update-records")
        value = request["records"][0]["fields"]["details_json"]
        self.assertIsInstance(value, str)
        self.assertEqual(json.loads(value), {"intent_status": "paused"})

    def test_timeout_after_success_is_resolved_by_readback(self):
        self.remote.timeout_after_write = True
        self.assertTrue(ledger.apply_records(self.binding, self.path, self.batch())["saved"])
        self.assertEqual(len([c for c in self.remote.calls if c[0] == "create-records"]), 1)

    def test_unknown_money_is_omitted_on_create_and_can_be_cleared_without_turning_into_zero(self):
        data = {"operation_id": "op-money", "table": "offers", "records": [{"fields": {
            "offer_id": "o", "name": "报价商品", "source_key": "s-offer", "base_fen": None}}]}
        ledger.apply_records(self.binding, self.path, data)
        create = next(payload for action, payload in self.remote.calls if action == "create-records")
        self.assertNotIn("base_fen", create["records"][0]["fields"])
        data["operation_id"] = "set-money"
        data["records"][0]["fields"]["base_fen"] = 100
        ledger.apply_records(self.binding, self.path, data)
        data["operation_id"] = "clear-money"
        data["records"][0]["fields"]["base_fen"] = None
        ledger.apply_records(self.binding, self.path, data)
        sheet = self.binding["tables"]["offers"]["sheet_id"]
        actual = self.remote.records[sheet][0]
        self.assertIsNone(ledger.logical_fields("offers", actual, self.binding)["base_fen"])

    def test_unresolved_timeout_is_not_resent_on_next_run(self):
        # 即时回读缺失不能证明原请求已停止；本次与后续操作均不盲目重发。
        self.remote.timeout_without_write = True
        for _ in range(2):
            with self.assertRaises(ledger.LedgerError):
                ledger.apply_records(self.binding, self.path, self.batch())
        self.assertEqual(len([c for c in self.remote.calls if c[0] == "create-records"]), 1)
        self.assertEqual(len(self.remote.records[self.binding["tables"]["items"]["sheet_id"]]), 0)

    def test_partial_server_failure_stops_and_reconciles_late_completion(self):
        data = self.batch()
        data["records"].append({"fields": dict(data["records"][0]["fields"], item_id="i2", source_key="receipt-1#line-2")})
        self.remote.partial_failure = True
        for _ in range(2):
            with self.assertRaisesRegex(ledger.LedgerError, "write unresolved|previous operation"):
                ledger.apply_records(self.binding, self.path, data)
        writes = [payload for action, payload in self.remote.calls if action == "create-records"]
        self.assertEqual(len(writes), 1)
        sheet = self.binding["tables"]["items"]["sheet_id"]
        self.assertEqual(len(self.remote.records[sheet]), 1)
        self.remote.records[sheet].append({"id": "r2", "fields": copy.deepcopy(writes[0]["records"][1]["fields"])})
        again = ledger.apply_records(self.binding, self.path, data)
        self.assertEqual((again["created"], again["updated"]), (0, 0))

    def test_operation_id_cannot_be_reused_with_different_content(self):
        ledger.apply_records(self.binding, self.path, self.batch())
        changed = self.batch()
        changed["records"][0]["fields"]["name"] = "另一个商品"
        with self.assertRaisesRegex(ledger.LedgerError, "operation_id"):
            ledger.apply_records(self.binding, self.path, changed)

    def test_same_evidence_under_new_business_id_does_not_create_another_record(self):
        ledger.apply_records(self.binding, self.path, self.batch())
        changed = self.batch(operation_id="op-2")
        changed["records"][0]["fields"]["item_id"] = "i2"
        with self.assertRaisesRegex(ledger.LedgerError, "source or transaction already exists"):
            ledger.apply_records(self.binding, self.path, changed)

    def test_explicit_record_id_adopts_existing_manual_row(self):
        sheet = self.binding["tables"]["items"]["sheet_id"]
        self.remote.records[sheet] = [{"id": "manual", "fields": {"name": "商品"}}]
        data = self.batch()
        data["records"][0]["record_id"] = "manual"
        result = ledger.apply_records(self.binding, self.path, data)
        self.assertEqual((result["created"], result["updated"]), (0, 1))
        self.assertEqual(self.remote.records[sheet][0]["fields"]["item_id"], "i")

    def test_a_manual_row_cannot_be_adopted_by_two_business_objects_in_one_batch(self):
        sheet = self.binding["tables"]["items"]["sheet_id"]
        self.remote.records[sheet] = [{"id": "manual", "fields": {"name": "商品"}}]
        data = self.batch()
        data["records"][0]["record_id"] = "manual"
        data["records"].append({"record_id": "manual", "fields": dict(data["records"][0]["fields"],
                                                                       item_id="i2", source_key="other-source")})
        with self.assertRaisesRegex(ledger.LedgerError, "adopted twice"):
            ledger.apply_records(self.binding, self.path, data)
        self.assertEqual(self.remote.records[sheet][0]["fields"], {"name": "商品"})

    def test_conflicting_same_transaction_in_one_batch_is_rejected_before_writing(self):
        data = {"operation_id": "financial", "table": "events", "records": []}
        for i, amount in enumerate((10000, 20000)):
            data["records"].append({"fields": {"event_id": "e" + str(i), "source_key": "source" + str(i),
                                               "identity_key": "same-bank-tx", "kind": "payment", "status": "confirmed",
                                               "target_type": "purchase", "target_id": "buy", "amount_fen": amount}})
        with self.assertRaisesRegex(ledger.LedgerError, "financial identity_key"):
            ledger.apply_records(self.binding, self.path, data)
        self.assertFalse(any(action == "create-records" for action, _ in self.remote.calls))

    def test_binding_accepts_legacy_item_field_names(self):
        schema = self.remote("dbsheet", "get-schema", {})
        items = next(s for s in schema["sheets"] if s["name"] == "购物清单")
        by_id = {f["id"]: f for f in items["fields"]}
        by_id["name"]["name"] = "需求名称"
        binding = ledger.make_binding(schema, "legacy-file")
        self.assertEqual(binding["tables"]["items"]["fields"]["name"]["name"], "需求名称")

    def test_binding_records_select_options_and_auto_add_flag(self):
        binding = self.binding
        category = binding["tables"]["items"]["select_options"]["category"]
        self.assertIn("手机", category["values"])
        self.assertTrue(category["auto_add"])

    def test_new_category_value_is_added_to_the_field_before_writing(self):
        data = self.batch()
        data["records"][0]["fields"]["category"] = "图书"
        ledger.apply_records(self.binding, self.path, data)
        extend = next(payload for action, payload in self.remote.calls if action == "update-fields")
        patch = next(f for f in extend["fields"] if f["id"] == "category")
        self.assertIn("图书", [i["value"] for i in patch["items"]])
        self.assertIn("手机", [i["value"] for i in patch["items"]])
        create = next(payload for action, payload in self.remote.calls if action == "create-records")
        self.assertFalse(create["add_select_item"])
        self.assertEqual(create["records"][0]["fields"]["category"], "图书")

    def test_known_values_write_without_extending_options(self):
        data = self.batch()
        data["records"][0]["fields"]["category"] = "手机"
        ledger.apply_records(self.binding, self.path, data)
        self.assertFalse(any(action == "update-fields" for action, _ in self.remote.calls))

    def test_unknown_option_on_non_auto_add_field_is_rejected(self):
        sheet = next(s for s in self.remote.sheets if s["name"] == "购物清单")
        next(f for f in sheet["fields"] if f["name"] == "品类")["autoAddItem"] = False
        data = self.batch()
        data["records"][0]["fields"]["category"] = "图书"
        with self.assertRaisesRegex(ledger.LedgerError, "unknown option"):
            ledger.apply_records(self.binding, self.path, data)
        self.assertFalse(any(action == "update-fields" for action, _ in self.remote.calls))
        self.assertFalse(any(action == "create-records" for action, _ in self.remote.calls))

    def test_unknown_engine_enum_still_rejected_before_writing(self):
        data = {"operation_id": "op-e", "table": "tasks", "records": [{"fields": {
            "task_id": "t", "name": "定金", "kind": "定金待付", "status": "active",
            "target_type": "purchase", "target_id": "buy", "amount_fen": 0,
            "payment_event_ids": [], "source_key": "s"}}]}
        with self.assertRaisesRegex(ledger.LedgerError, "unknown option"):
            ledger.apply_records(self.binding, self.path, data)
        self.assertFalse(any(action == "create-records" for action, _ in self.remote.calls))

    def test_complete_read_paginates_and_preserves_unknowns_and_json_values(self):
        demo = json.loads((ledger.ROOT / "assets/demo-ledger.json").read_text())
        for logical, table in self.binding["tables"].items():
            self.remote.records[table["sheet_id"]] = [
                {"id": "r" + str(i), "fields": {k: json.dumps(v) if isinstance(v, (dict, list)) else v
                                                 for k, v in row.items() if k in table["fields"]}}
                for i, row in enumerate(demo[logical])]
        result = ledger.read_snapshot(self.binding, page_size=2)
        self.assertEqual(len(result["events"]), 4)
        self.assertTrue(result["read_complete"])
        from shopping import review
        self.assertEqual(review(result)["summary"]["net_cash_spend_fen"], 1030000)

    def test_repeated_cursor_and_overlapping_pages_are_rejected(self):
        with patch.object(ledger, "call", return_value={"records": [], "page_token": "same"}):
            with self.assertRaisesRegex(ledger.LedgerError, "cursor"):
                ledger.list_records("f", 1)
        with patch.object(ledger, "call", return_value={"records": [{"id": "r", "fields": {}}], "page_token": "next"}):
            with self.assertRaisesRegex(ledger.LedgerError, "overlapping"):
                ledger.list_records("f", 1)

    def test_schema_row_count_mismatch_is_not_a_complete_read(self):
        original = self.remote.__call__

        def changed_count(service, action, payload):
            result = original(service, action, payload)
            if action == "get-schema":
                result["sheets"][0]["recordsCount"] += 1
            return result

        with patch.object(ledger, "call", side_effect=changed_count):
            with self.assertRaisesRegex(ledger.LedgerError, "record count"):
                ledger.read_snapshot(self.binding)

    def seed_display_ledger(self):
        sheet = self.binding["tables"]["items"]["sheet_id"]
        self.remote.records[sheet] = [
            {"id": "r1", "fields": {"item_id": "phone", "name": "手机", "source_key": "s-phone",
                                    "planned_quantity": 1}},
            {"id": "r2", "fields": {"item_id": "pad", "name": "平板", "source_key": "s-pad",
                                    "planned_quantity": 1}},
            {"id": "r3", "fields": {"item_id": "orphan", "name": "缺身份行",
                                    "planned_quantity": 1}},
            {"id": "r4", "fields": {"item_id": "tv", "name": "电视", "source_key": "s-tv",
                                     "planned_quantity": 2}}]
        offers = self.binding["tables"]["offers"]["sheet_id"]
        self.remote.records[offers] = [
            {"id": "o1", "fields": {"offer_id": "offer-1", "item_id": "phone", "source_key": "s-offer",
                                    "platform": "京东", "seller": "自营", "base_fen": 1299900,
                                    "basis": "item_price", "quantity": 1,
                                    "verification_status": "PAGE_DISPLAYED", "condition": "全新",
                                    "evidence_at": "2026-10-01T10:00:00+08:00"}}]
        purchases = self.binding["tables"]["purchases"]["sheet_id"]
        self.remote.records[purchases] = [
            {"id": "p1", "fields": {"purchase_id": "buy-tv1", "item_id": "tv", "source_key": "s-buy1",
                                    "quantity": 1, "order_status": "ordered", "order_group_id": "g1"}},
            {"id": "p2", "fields": {"purchase_id": "buy-tv2", "item_id": "tv", "source_key": "s-buy2",
                                    "quantity": 1, "order_status": "ordered", "order_group_id": "g1"}},
            {"id": "p3", "fields": {"purchase_id": "buy-tv3", "item_id": "tv", "source_key": "s-buy3",
                                    "quantity": 1, "order_status": "ordered", "order_group_id": "g2"}},
            {"id": "p4", "fields": {"purchase_id": "buy-pad-cancel", "item_id": "pad", "source_key": "s-buy4",
                                    "quantity": 1, "order_status": "cancelled", "order_group_id": "g2"}}]
        tasks = self.binding["tables"]["tasks"]["sheet_id"]
        self.remote.records[tasks] = [
            {"id": "t1", "fields": {"task_id": "t-evidence", "item_id": "phone", "source_key": "s-t1",
                                    "kind": "evidence", "status": "active", "amount_fen": 0,
                                    "payment_event_ids": [], "target_type": "purchase",
                                    "target_id": "buy-tv1"}},
            {"id": "t2", "fields": {"task_id": "t-group", "source_key": "s-t2",
                                    "kind": "full_payment", "status": "paid", "amount_fen": 100,
                                    "payment_event_ids": [], "target_type": "order_group",
                                    "target_id": "g1"}},
            {"id": "t3", "fields": {"task_id": "t-group-mixed", "source_key": "s-t3",
                                    "kind": "full_payment", "status": "paid", "amount_fen": 100,
                                    "payment_event_ids": [], "target_type": "order_group",
                                    "target_id": "g2"}}]

    def test_sync_writes_display_caches_and_reports_stale_quotes(self):
        self.seed_display_ledger()
        snapshot = ledger.read_snapshot(self.binding)
        snapshot["read_at"] = "2026-10-15T06:00:00+00:00"
        result = ledger.sync_display(self.binding, self.path, snapshot)
        self.assertTrue(result["synced"])
        self.assertEqual(result["skipped_no_source_key"]["items"], ["orphan"])
        self.assertEqual(result["operation_ids"]["items"],
                         ["sync:2026-10-15T06:00:00+00:00:items:1"])
        pricing = result["reference_pricing"]
        self.assertEqual((pricing["priced_item_count"], pricing["missing_item_count"]), (1, 2))
        self.assertEqual(pricing["active_item_count"], 3)
        self.assertEqual(pricing["stale_item_count"], 1)
        self.assertEqual(pricing["stale_items"], ["手机"])
        rows = {r["fields"]["item_id"]: r["fields"]
                for r in self.remote.records[self.binding["tables"]["items"]["sheet_id"]]}
        self.assertEqual(rows["phone"]["d-购买状态"], "待购")
        self.assertEqual(rows["phone"]["d-预估金额（元）"], 12999.0)
        self.assertEqual(rows["phone"]["d-参考价日期"], "10-01")
        self.assertEqual(rows["phone"]["d-参考价缺项标记"], 0)
        self.assertEqual(rows["pad"]["d-参考价缺项标记"], 1)
        self.assertNotIn("d-购买状态", rows["orphan"])
        update = next(payload for action, payload in self.remote.calls if action == "update-records")
        # 最小差异：展示缓存更新不携带无关核心字段，也不清空未变的展示列。
        written = update["records"][0]["fields"]
        self.assertNotIn("name", written)
        self.assertNotIn("d-规格摘要", written)

    def test_sync_is_idempotent_and_reports_notes_without_rewriting(self):
        self.seed_display_ledger()
        snapshot = ledger.read_snapshot(self.binding)
        snapshot["read_at"] = "2026-10-15T06:00:00+00:00"
        first = ledger.sync_display(self.binding, self.path, snapshot)
        self.assertEqual((first["applied"]["items"]["created"], first["applied"]["items"]["updated"]), (0, 3))
        writes_after_first = [c for c in self.remote.calls if c[0] in ("create-records", "update-records")]
        self.assertEqual(len(writes_after_first), 4)  # items/purchases/offers/tasks 各一次
        second = ledger.sync_display(self.binding, self.path, snapshot)
        self.assertEqual([c for c in self.remote.calls if c[0] in ("create-records", "update-records")],
                         writes_after_first)
        self.assertEqual((second["applied"]["items"]["created"], second["applied"]["items"]["updated"]), (0, 0))
        self.assertEqual([n["name"] for n in second["item_notes"]], ["手机", "平板", "缺身份行", "电视"])
        self.assertTrue(second["item_notes"][0]["assistant_notes"]["价格说明"])

    def test_sync_derives_associated_item_links_without_guessing_group_targets(self):
        self.seed_display_ledger()
        snapshot = ledger.read_snapshot(self.binding)
        snapshot["read_at"] = "2026-10-15T06:00:00+00:00"
        result = ledger.sync_display(self.binding, self.path, snapshot)
        purchases = {r["fields"]["purchase_id"]: r["fields"]
                     for r in self.remote.records[self.binding["tables"]["purchases"]["sheet_id"]]}
        self.assertEqual(purchases["buy-tv1"]["d-关联商品"], ["r4"])
        self.assertEqual(purchases["buy-tv3"]["d-关联商品"], ["r4"])
        self.assertEqual(purchases["buy-pad-cancel"]["d-关联商品"], ["r2"])
        offers = self.remote.records[self.binding["tables"]["offers"]["sheet_id"]][0]["fields"]
        self.assertEqual(offers["d-关联商品"], ["r1"])
        tasks = {r["fields"]["task_id"]: r["fields"]
                 for r in self.remote.records[self.binding["tables"]["tasks"]["sheet_id"]]}
        self.assertEqual(tasks["t-evidence"]["d-关联商品"], ["r1"])
        # 单一商品的订单组可派生；整单多品的付款待办不指认单一商品，链接留原状。
        self.assertEqual(tasks["t-group"]["d-关联商品"], ["r4"])
        self.assertNotIn("d-关联商品", tasks["t-group-mixed"])
        self.assertIn("d-待付提示", tasks["t-group-mixed"])
        self.assertEqual(result["applied"]["purchases"]["updated"], 4)
        self.assertEqual(result["applied"]["offers"]["updated"], 1)

    def test_link_display_values_accept_only_nonempty_record_id_lists(self):
        with self.assertRaisesRegex(ledger.LedgerError, "link display fields"):
            ledger.apply_records(self.binding, self.path, {
                "operation_id": "bad-link", "table": "purchases",
                "records": [{"fields": {"purchase_id": "b", "source_key": "s"},
                             "display": {"关联商品": []}}]})

    def test_lock_prevents_second_writer_and_is_released_after_failure(self):
        with self.assertRaises(RuntimeError):
            with ledger.writer_lock(self.path):
                with self.assertRaises(ledger.LedgerError):
                    with ledger.writer_lock(self.path):
                        pass
                raise RuntimeError("test")
        with ledger.writer_lock(self.path):
            pass


if __name__ == "__main__":
    unittest.main()
