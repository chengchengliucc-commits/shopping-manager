import copy
import importlib.util
import json
import subprocess
import sys
import unittest
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("shopping", ROOT / "scripts" / "shopping.py")
shopping = importlib.util.module_from_spec(spec)
spec.loader.exec_module(shopping)


def ledger():
    return {
        "read_complete": True,
        "items": [{"item_id": "i", "name": "商品", "planned_quantity": 1}],
        "purchases": [{"purchase_id": "buy", "plan_id": "p", "item_id": "i", "order_group_id": "g",
                       "quantity": 1, "order_status": "ordered", "retained_quantity": None}],
        "events": [{"event_id": "deposit", "plan_id": "p", "target_type": "purchase", "target_id": "buy",
                    "kind": "payment", "status": "confirmed", "amount_fen": 10000}],
        "tasks": [
            {"task_id": "deposit-task", "plan_id": "p", "target_type": "purchase", "target_id": "buy",
             "kind": "deposit", "status": "paid", "amount_fen": 10000, "payment_event_ids": ["deposit"]},
            {"task_id": "balance-task", "plan_id": "p", "target_type": "purchase", "target_id": "buy",
             "kind": "balance", "status": "active", "amount_fen": 79900, "payment_event_ids": []}]
    }


def extra_event(eid, kind, amount, status="confirmed"):
    return {"event_id": eid, "plan_id": "p", "target_type": "purchase", "target_id": "buy",
            "kind": kind, "status": status, "amount_fen": amount}


def offer(oid, amount, color=None, evidence="PAGE_DISPLAYED", condition="全新",
          evidence_at=None, platform="京东", seller="自营旗舰店", details=None):
    row = {"offer_id": oid, "plan_id": "p", "item_id": "i", "platform": platform, "seller": seller,
           "base_fen": amount, "basis": "item_price", "quantity": 1,
           "verification_status": evidence, "condition": condition, "source_key": "s-" + oid}
    if color is not None:
        row["color"] = color
    if evidence_at is not None:
        row["evidence_at"] = evidence_at
    if details is not None:
        row["details_json"] = details
    return row


def reference_ledger(item=None, offers=()):
    row = {"item_id": "i", "plan_id": "p", "name": "商品", "planned_quantity": 1}
    row.update(item or {})
    return {"read_complete": True, "plan": {"plan_id": "p", "currency": "CNY"},
            "items": [row], "purchases": [], "events": [], "tasks": [],
            "offers": list(offers)}


class ReferencePriceTests(unittest.TestCase):
    def workbench(self, item=None, offers=()):
        return shopping.workbench(reference_ledger(item, offers))

    def preferred(self, colors):
        return {"details_json": json.dumps({"preferred_colors": colors})}

    def test_unknown_condition_cheaper_quote_is_named_in_the_note(self):
        rows = [offer("jd", 1299900, color="酒红色"),
                offer("pdd", 1209900, color="黑色", evidence="USER_PROVIDED", condition=None,
                      platform="拼多多", seller=None,
                      details=json.dumps({"open_questions": ["券是否已领到/有效期未确认"]}))]
        result = self.workbench(self.preferred(["酒红色", "白色"]), rows)
        row = result["items"][0]
        # 未注明成色的报价不与全新混比，仍是全新报价入选，但更便宜的候选不再不可见。
        self.assertEqual(row["display"]["预估金额（元）"], 12999.0)
        self.assertIn("另有拼多多·黑色 12099.00元未计入（成色未注明）",
                      row["assistant_notes"]["价格说明"])

    def test_cheapest_comparable_color_wins_even_outside_preferences(self):
        rows = [offer("jd", 1299900, color="酒红色"),
                offer("pdd", 1209900, color="黑色", evidence="CHECKOUT_VERIFIED")]
        result = self.workbench(self.preferred(["酒红色", "白色"]), rows)
        row = result["items"][0]
        self.assertEqual(row["display"]["预估金额（元）"], 12099.0)
        self.assertIn("结算核对", row["assistant_notes"]["价格说明"])

    def test_equal_prices_follow_preferences_then_newest_evidence(self):
        rows = [offer("old", 1299900, color="酒红色", seller="旧店", evidence_at="2026-10-14T10:00:00+08:00"),
                offer("new", 1299900, color="酒红色", seller="新店", evidence_at="2026-10-15T10:00:00+08:00"),
                offer("black", 1299900, color="黑色", seller="黑店")]
        result = self.workbench(self.preferred(["酒红色", "白色"]), rows)
        note = result["items"][0]["assistant_notes"]["价格说明"]
        self.assertTrue(note.startswith("新店"), note)

    def test_pinned_color_still_requires_exact_match(self):
        rows = [offer("jd", 1299900, color="酒红色"),
                offer("pdd", 1209900, color="黑色", evidence="CHECKOUT_VERIFIED")]
        result = self.workbench(dict(self.preferred(["酒红色"]), color="黑色"), rows)
        self.assertEqual(result["items"][0]["display"]["预估金额（元）"], 12099.0)
        result = self.workbench(dict(self.preferred(["酒红色"]), color="白色"), rows)
        row = result["items"][0]
        self.assertIsNone(row["display"]["预估金额（元）"])
        self.assertIn("需要白色", row["assistant_notes"]["价格说明"])

    def test_second_hand_euphemisms_are_not_treated_as_new(self):
        rows = [offer("jd", 1299900, color="酒红色"),
                offer("xianyu", 999900, color="酒红色", platform="闲鱼", seller="个人", condition="几乎全新")]
        result = self.workbench(self.preferred(["酒红色"]), rows)
        row = result["items"][0]
        self.assertEqual(row["display"]["预估金额（元）"], 12999.0)
        self.assertIn("另有闲鱼·酒红色 9999.00元未计入（成色未选）",
                      row["assistant_notes"]["价格说明"])

    def test_workbench_reference_keeps_input_unchanged(self):
        data = reference_ledger(self.preferred(["酒红色"]),
                                [offer("jd", 1299900, color="酒红色"),
                                 offer("pdd", 1209900, color="黑色", condition=None)])
        before = copy.deepcopy(data)
        shopping.workbench(data)
        self.assertEqual(data, before)

    def test_reference_date_column_shows_same_year_short_date(self):
        data = reference_ledger(None, [offer("jd", 1299900, evidence_at="2026-10-08T10:00:00+08:00")])
        data["read_at"] = "2026-10-15T06:00:00+00:00"
        result = shopping.workbench(data)
        self.assertEqual(result["items"][0]["display"]["参考价日期"], "10-08")
        self.assertEqual(result["items"][0]["name"], "商品")
        self.assertEqual(result["reference_pricing"]["stale_item_count"], 0)
        self.assertEqual(result["reference_pricing"]["undated_item_count"], 0)

    def test_stale_reference_quotes_are_named_with_the_stale_threshold(self):
        data = reference_ledger(None, [offer("jd", 1299900, evidence_at="2026-10-07T10:00:00+08:00")])
        data["read_at"] = "2026-10-15T06:00:00+00:00"
        pricing = shopping.workbench(data)["reference_pricing"]
        self.assertEqual(pricing["stale_item_count"], 1)
        self.assertEqual(pricing["stale_items"], ["商品"])
        self.assertEqual(pricing["stale_days"], 7)
        self.assertEqual(pricing["undated_item_count"], 0)

    def test_cross_year_reference_date_stays_unambiguous(self):
        data = reference_ledger(None, [offer("jd", 1299900, evidence_at="2025-12-30T10:00:00+08:00")])
        data["read_at"] = "2026-10-15T06:00:00+00:00"
        result = shopping.workbench(data)
        self.assertEqual(result["items"][0]["display"]["参考价日期"], "2025-12-30")
        self.assertEqual(result["reference_pricing"]["stale_item_count"], 1)

    def test_missing_evidence_time_is_undated_not_fresh(self):
        data = reference_ledger(None, [offer("jd", 1299900)])
        data["read_at"] = "2026-10-15T06:00:00+00:00"
        result = shopping.workbench(data)
        self.assertEqual(result["items"][0]["display"]["参考价日期"], "")
        pricing = result["reference_pricing"]
        self.assertEqual((pricing["stale_item_count"], pricing["undated_item_count"]), (0, 1))

    def test_purchased_items_carry_no_reference_date(self):
        data = ledger()
        data["read_at"] = "2026-10-15T06:00:00+00:00"
        self.assertEqual(shopping.workbench(data)["items"][0]["display"]["参考价日期"], "")


class PricingTests(unittest.TestCase):
    def test_yuan_conversion_uses_decimal(self):
        self.assertEqual(shopping.money({"amount": "0.29"})["amount_fen"], 29)
        self.assertEqual(shopping.money({"amount": "10000.00"})["amount_fen"], 1000000)

    def test_money_rejects_extra_precision_negative_nan_and_bool(self):
        for value in ["1.001", "-1.00", "NaN", "1e4", True]:
            with self.subTest(value=value), self.assertRaises(shopping.InputError):
                shopping.money({"amount": value})

    def test_confirmed_ordered_discounts_and_shipping(self):
        result = shopping.price({"basis": "item_price", "base_fen": 10000, "shipping_fen": 500,
                                 "stacking_verified": True, "promotions": [
            {"kind": "fixed", "status": "confirmed", "eligible": True, "amount_fen": 1000},
            {"kind": "percent", "status": "confirmed", "eligible": True, "discount_bps": 1000}]})
        self.assertEqual(result["total_fen"], 8600)

    def test_unknown_coupon_not_deducted(self):
        result = shopping.price({"basis": "item_price", "base_fen": 10000, "shipping_fen": 0,
                                 "promotions": [{"kind": "fixed", "status": "pending", "eligible": True,
                                                 "amount_fen": 3000}]})
        self.assertEqual(result["total_fen"], 10000)
        self.assertEqual(len(result["unapplied"]), 1)

    def test_unknown_shipping_not_zero(self):
        result = shopping.price({"basis": "item_price", "base_fen": 89900, "shipping_fen": None})
        self.assertIsNone(result["total_fen"])
        self.assertEqual(result["known_subtotal_fen"], 89900)

    def test_checkout_discount_not_deducted_twice(self):
        with self.assertRaises(shopping.InputError):
            shopping.price({"basis": "checkout_total", "base_fen": 89900,
                            "promotions": [{"kind": "fixed", "amount_fen": 1000}]})

    def test_checkout_boolean_shipping_rejected(self):
        with self.assertRaises(shopping.InputError):
            shopping.price({"basis": "checkout_total", "base_fen": 100, "shipping_fen": False})

    def test_stacking_must_be_explicit(self):
        with self.assertRaises(shopping.InputError):
            shopping.price({"basis": "item_price", "base_fen": 10000, "shipping_fen": 0,
                            "promotions": [
                                {"kind": "fixed", "status": "confirmed", "eligible": True, "amount_fen": 100},
                                {"kind": "fixed", "status": "confirmed", "eligible": True, "amount_fen": 200}]})

    def test_percentage_rounding_and_cap(self):
        rule = {"kind": "percent", "status": "confirmed", "eligible": True, "discount_bps": 5000}
        self.assertEqual(shopping.price({"basis": "item_price", "base_fen": 3, "shipping_fen": 0,
                                        "promotions": [rule]})["total_fen"], 1)
        rule["cap_fen"] = 1
        self.assertEqual(shopping.price({"basis": "item_price", "base_fen": 3, "shipping_fen": 0,
                                        "promotions": [rule]})["total_fen"], 2)

    def test_current_threshold_after_previous_coupon(self):
        result = shopping.price({"basis": "item_price", "base_fen": 10000, "shipping_fen": 0,
                                 "stacking_verified": True, "promotions": [
            {"kind": "fixed", "status": "confirmed", "eligible": True, "amount_fen": 2000},
            {"kind": "full_reduction", "status": "confirmed", "eligible": True,
             "threshold_fen": 9000, "threshold_basis": "current", "amount_fen": 1000}]})
        self.assertEqual(result["total_fen"], 8000)
        self.assertEqual(result["unapplied"][0]["reason"], "threshold_not_met")

    def test_overlarge_discount_and_float_money_rejected(self):
        with self.assertRaises(shopping.InputError):
            shopping.price({"basis": "item_price", "base_fen": 100, "shipping_fen": 0,
                            "promotions": [{"kind": "fixed", "status": "confirmed", "eligible": True,
                                            "amount_fen": 101}]})
        with self.assertRaises(shopping.InputError):
            shopping.price({"basis": "item_price", "base_fen": 1.1, "shipping_fen": 0})

    def test_per_threshold_every_300_reduce_50(self):
        result = shopping.price({"basis": "item_price", "base_fen": 70000, "shipping_fen": 0,
                                 "promotions": [{"kind": "per_threshold", "status": "confirmed",
                                                 "eligible": True, "threshold_basis": "original",
                                                 "step_fen": 30000, "amount_fen": 5000}]})
        self.assertEqual(result["total_fen"], 60000)
        self.assertEqual(result["applied"][0]["discount_fen"], 10000)

    def test_per_threshold_below_one_step_is_unapplied(self):
        result = shopping.price({"basis": "item_price", "base_fen": 29999, "shipping_fen": 0,
                                 "promotions": [{"kind": "per_threshold", "status": "confirmed",
                                                 "eligible": True, "threshold_basis": "original",
                                                 "step_fen": 30000, "amount_fen": 5000}]})
        self.assertEqual(result["total_fen"], 29999)
        self.assertEqual(result["unapplied"][0]["reason"], "threshold_not_met")

    def test_per_threshold_cap(self):
        result = shopping.price({"basis": "item_price", "base_fen": 90000, "shipping_fen": 0,
                                 "promotions": [{"kind": "per_threshold", "status": "confirmed",
                                                 "eligible": True, "threshold_basis": "current",
                                                 "step_fen": 30000, "amount_fen": 5000, "cap_fen": 5000}]})
        self.assertEqual(result["total_fen"], 85000)

    def test_per_threshold_zero_step_rejected(self):
        with self.assertRaises(shopping.InputError):
            shopping.price({"basis": "item_price", "base_fen": 90000, "shipping_fen": 0,
                            "promotions": [{"kind": "per_threshold", "status": "confirmed",
                                            "eligible": True, "threshold_basis": "current",
                                            "step_fen": 0, "amount_fen": 5000}]})

    def test_integral_fen_from_number_column_accepted(self):
        self.assertEqual(shopping.fen(Decimal("10000.0"), "base_fen", False), 10000)
        self.assertEqual(shopping.fen(10000.0, "base_fen", False), 10000)
        result = shopping.price({"basis": "item_price", "base_fen": 10000.0, "shipping_fen": 0.0})
        self.assertEqual(result["total_fen"], 10000)

    def test_fractional_fen_still_rejected(self):
        for value in (Decimal("10000.5"), 10000.5, Decimal("NaN"), float("inf")):
            with self.subTest(value=value), self.assertRaises(shopping.InputError):
                shopping.fen(value, "base_fen", False)

    def test_unit_price_and_scale(self):
        self.assertEqual(shopping.unit_price({"amount_fen": 15000, "total_units": "50", "unit": "片"})["yuan_per_unit"],
                         "3.0000")
        self.assertEqual(shopping.unit_price({"amount_fen": 1000, "total_units": "500",
                                             "per_units": "100", "unit": "g"})["yuan_per_unit"], "2.0000")
        with self.assertRaises(shopping.InputError):
            shopping.unit_price({"amount_fen": 10, "total_units": 0, "unit": "片"})


class LedgerTests(unittest.TestCase):
    def test_unlinked_tail_payment_blocks_definitive_outstanding_until_reconciled(self):
        data = ledger()
        data["events"].append(extra_event("tail", "payment", 79900))
        result = shopping.budget(data)
        self.assertEqual(result["paid"]["total_fen"], 89900)
        self.assertEqual(result["net_cash_spend_fen"], 89900)
        self.assertIn("payment_unallocated:tail", result["issues"])
        self.assertIsNone(result["outstanding"]["total_fen"])
        self.assertNotIn("budget", result)
        self.assertFalse(result["complete"])
        self.assertTrue(all(t["remaining_fen"] is None for t in result["payment_tasks"]))
        data["tasks"][1].update(status="paid", payment_event_ids=["tail"])
        reconciled = shopping.budget(data, budget_fen=100000)
        self.assertEqual(reconciled["outstanding"]["total_fen"], 0)
        self.assertEqual(reconciled["budget"]["occupied_fen"], 89900)
        self.assertTrue(reconciled["complete"])

    def test_unknown_or_empty_task_kind_is_rejected(self):
        for kind in ("尾款待付", None, "", "full_paymant"):
            data = ledger()
            data["tasks"][1]["kind"] = kind
            with self.subTest(kind=kind), self.assertRaises(shopping.InputError):
                shopping.budget(data)

    def test_deposit_alone_does_not_prove_the_order_has_no_tail_payment(self):
        data = ledger()
        data["tasks"] = data["tasks"][:1]
        result = shopping.budget(data)
        self.assertEqual(result["paid"]["total_fen"], 10000)
        self.assertIsNone(result["outstanding"]["total_fen"])
        self.assertIn("deposit_missing_balance_schedule:deposit-task", result["issues"])
        self.assertIn("待核对", shopping.workbench(data)["items"][0]["assistant_notes"]["下一步"])
        data["tasks"].append({"task_id": "no-tail", "plan_id": "p", "kind": "balance", "status": "active",
                              "target_type": "purchase", "target_id": "buy", "amount_fen": 0, "payment_event_ids": []})
        self.assertTrue(shopping.budget(data)["complete"])

    def test_another_item_full_payment_does_not_prove_this_deposit_order_is_complete(self):
        data = ledger()
        data["tasks"] = data["tasks"][:1]
        data["items"].append(dict(data["items"][0], item_id="i2"))
        data["purchases"].append(dict(data["purchases"][0], purchase_id="buy2", item_id="i2"))
        data["tasks"].append({"task_id": "other-paid", "plan_id": "p", "kind": "full_payment", "status": "active",
                              "target_type": "purchase", "target_id": "buy2", "amount_fen": 0, "payment_event_ids": []})
        self.assertIsNone(shopping.budget(data)["outstanding"]["total_fen"])

    def test_fully_reversed_unallocated_payment_does_not_create_new_obligation(self):
        data = ledger()
        data["events"].append(extra_event("mistake", "payment", 500))
        data["events"].append(dict(extra_event("undo-mistake", "payment_reversal", 500),
                                   reverses_event_id="mistake"))
        self.assertTrue(shopping.budget(data)["complete"])

    def test_cancelled_refunded_order_needs_no_active_payment_task(self):
        data = ledger()
        data["purchases"][0]["order_status"] = "cancelled"
        data["items"][0]["not_bought_reason"] = "已取消购买"
        for task in data["tasks"]:
            task["status"] = "cancelled"
        data["events"].append(extra_event("return", "refund", 10000))
        result = shopping.budget(data)
        self.assertTrue(result["complete"], result["issues"])
        self.assertEqual(result["outstanding"]["total_fen"], 0)
        self.assertEqual(result["net_cash_spend_fen"], 0)

    def test_unallocated_group_payment_also_blocks_purchase_level_tasks(self):
        data = ledger()
        data["events"].append(dict(extra_event("tail", "payment", 79900),
                                   target_type="order_group", target_id="g"))
        result = shopping.budget(data)
        self.assertIsNone(result["outstanding"]["total_fen"])
        self.assertIn("payment_unallocated:tail", result["issues"])

    def test_workbench_uses_real_cash_and_shows_the_next_payment_without_mutating_input(self):
        data = ledger()
        data["read_at"] = "2026-10-15T06:00:00+00:00"
        data["items"][0].update(memory="16GB", storage="512GB")
        data["tasks"][1]["due_at"] = "2026-11-10T23:59:59+08:00"
        before = copy.deepcopy(data)
        result = shopping.workbench(data)
        display = result["items"][0]["display"]
        self.assertEqual(result["items"][0]["assistant_notes"]["金额概况"], "净现金支出 100.00元")
        self.assertEqual(display["规格摘要"], "16GB / 512GB")
        self.assertIn("799.00元", result["items"][0]["assistant_notes"]["下一步"])
        self.assertIn("2026-11-10T23:59:59+08:00", result["items"][0]["assistant_notes"]["下一步"])
        self.assertNotIn("金额概况", display)
        self.assertNotIn("下一步", display)
        self.assertEqual(data, before)

    def test_workbench_purchase_status_is_derived_from_purchase_rows(self):
        data = ledger()
        data["purchases"] = []
        data["events"] = []
        data["tasks"] = []
        self.assertEqual(shopping.workbench(data)["items"][0]["display"]["购买状态"], "待购")

        data = ledger()
        data["items"][0]["planned_quantity"] = 2
        data["purchases"][0]["quantity"] = 1
        self.assertEqual(shopping.workbench(data)["items"][0]["display"]["购买状态"], "部分购买")

        data = ledger()
        data["items"][0]["not_bought_reason"] = "等明年降价"
        data["purchases"] = []
        data["events"] = []
        data["tasks"] = []
        result = shopping.workbench(data)
        self.assertEqual(result["items"][0]["display"]["购买状态"], "未购买")
        self.assertIn("未购买：等明年降价", result["items"][0]["assistant_notes"]["下一步"])

        data = ledger()
        data["purchases"][0]["order_status"] = "cancelled"
        data["events"] = []
        data["tasks"] = []
        self.assertEqual(shopping.workbench(data)["items"][0]["display"]["购买状态"], "订单已取消，结果待确认")

    def test_workbench_does_not_show_unreconciled_payment_as_definitive_tail_due(self):
        data = ledger()
        data["events"].append(extra_event("tail", "payment", 79900))
        result = shopping.workbench(data)
        self.assertEqual(result["items"][0]["assistant_notes"]["下一步"], "核对支付流水与付款待办的关联")
        self.assertTrue(all(t["display"]["待付提示"] == "待付金额待核对" for t in result["tasks"]))

    def test_workbench_does_not_assign_shared_order_cash_to_a_single_item(self):
        data = ledger()
        data["items"].append(dict(data["items"][0], item_id="i2"))
        data["purchases"].append(dict(data["purchases"][0], purchase_id="buy2", item_id="i2"))
        data["events"][0].update(target_type="order_group", target_id="g")
        for task in data["tasks"]:
            task.update(target_type="order_group", target_id="g")
        result = shopping.workbench(data)
        for item in result["items"]:
            self.assertIsNone(item["display"]["净支出（元）"])
            self.assertIn("整单待付", item["assistant_notes"]["下一步"])

    def test_workbench_clears_cancelled_and_nonpayment_task_amount_prompts(self):
        data = ledger()
        data["tasks"][1]["status"] = "cancelled"
        data["tasks"].append({"task_id": "info", "plan_id": "p", "kind": "evidence", "status": "done"})
        tasks = {t["task_id"]: t["display"]["待付提示"] for t in shopping.workbench(data)["tasks"]}
        self.assertEqual(tasks["balance-task"], "付款义务已取消")
        self.assertEqual(tasks["info"], "")

    def test_deposit_and_balance_do_not_double_count(self):
        data = ledger()
        first = shopping.budget(data, budget_fen=100000)
        self.assertEqual(first["paid"]["total_fen"], 10000)
        self.assertEqual(first["outstanding"]["total_fen"], 79900)
        self.assertEqual(first["budget"]["occupied_fen"], 89900)
        self.assertEqual(first["budget"]["remaining_fen"], 10100)
        data["events"].append(extra_event("tail", "payment", 79900))
        data["tasks"][1].update(status="paid", payment_event_ids=["tail"])
        after = shopping.budget(data, budget_fen=100000)
        self.assertEqual(after["paid"]["total_fen"], 89900)
        self.assertEqual(after["outstanding"]["total_fen"], 0)
        self.assertEqual(after["budget"]["occupied_fen"], 89900)
        self.assertTrue(after["complete"])

    def test_refund_pending_vs_received(self):
        data = ledger()
        data["events"].append(extra_event("return", "refund", 500, "pending"))
        pending = shopping.budget(data)
        self.assertEqual(pending["net_cash_spend_fen"], 10000)
        self.assertEqual(pending["refunds_pending"]["total_fen"], 500)
        data["events"][-1]["status"] = "confirmed"
        received = shopping.budget(data, budget_fen=100000)
        self.assertEqual(received["net_cash_spend_fen"], 9500)
        self.assertEqual(received["budget"]["occupied_fen"], 89400)

    def test_first_version_does_not_treat_commission_as_refund(self):
        data = ledger()
        data["events"].append(extra_event("future-commission", "cashback", 100))
        with self.assertRaises(shopping.InputError):
            shopping.budget(data)
        result = shopping.budget(ledger())
        self.assertNotIn("cashback_received", result)
        self.assertNotIn("cashback_adjusted_cost_fen", result)

    def test_duplicate_rows_and_financial_identity(self):
        data = ledger()
        data["events"].append(copy.deepcopy(data["events"][0]))
        self.assertEqual(shopping.budget(data)["paid"]["total_fen"], 10000)
        data["events"] = data["events"][:1]
        data["events"][0]["identity_key"] = "receipt-unique"
        second = dict(data["events"][0], event_id="same-receipt-from-other-image")
        data["events"].append(second)
        data["tasks"][0]["payment_event_ids"] = [second["event_id"]]
        result = shopping.budget(data)
        self.assertEqual(result["paid"]["total_fen"], 10000)
        self.assertEqual(result["outstanding"]["total_fen"], 79900)

    def test_conflicting_identity_and_shared_payment_assignment_rejected(self):
        data = ledger()
        data["events"].append(dict(data["events"][0], amount_fen=20000))
        with self.assertRaises(shopping.InputError):
            shopping.budget(data)
        data = ledger()
        data["tasks"][1]["payment_event_ids"] = ["deposit"]
        with self.assertRaises(shopping.InputError):
            shopping.budget(data)

    def test_unknown_amounts_propagate(self):
        for mutate in ("event", "task"):
            data = ledger()
            if mutate == "event":
                data["events"][0]["amount_fen"] = None
            else:
                data["tasks"][1]["amount_fen"] = None
            result = shopping.budget(data)
            self.assertNotIn("budget", result)
            self.assertFalse(result["complete"])

    def test_paid_state_does_not_invent_payment_and_missing_schedule_is_unknown(self):
        data = ledger()
        data["tasks"][1]["status"] = "paid"
        result = shopping.budget(data)
        self.assertIn("paid_task_without_matching_payment:balance-task", result["issues"])
        self.assertEqual(result["outstanding"]["total_fen"], 79900)
        data["tasks"] = []
        self.assertIsNone(shopping.budget(data)["outstanding"]["total_fen"])

    def test_same_amount_different_real_payments_not_silently_deleted(self):
        data = ledger()
        data["events"].append(extra_event("another-payment", "payment", 10000))
        result = shopping.budget(data)
        self.assertEqual(result["paid"]["total_fen"], 20000)
        self.assertTrue(any(x.startswith("possible_duplicate_payment:") for x in result["issues"]))

    def test_payment_reversal_and_invalid_overreversal(self):
        data = ledger()
        reversal = extra_event("undo", "payment_reversal", 500)
        reversal["reverses_event_id"] = "deposit"
        data["events"].append(reversal)
        result = shopping.budget(data)
        self.assertEqual(result["paid"]["total_fen"], 9500)
        self.assertEqual(result["outstanding"]["total_fen"], 80400)
        data["events"][-1]["amount_fen"] = 10001
        with self.assertRaises(shopping.InputError):
            shopping.budget(data)

    def test_partial_snapshot_is_rejected_before_any_calculation(self):
        data = ledger()
        data["read_complete"] = False
        with self.assertRaises(shopping.InputError):
            shopping.budget(data)

    def test_multi_item_order_payment_counted_once(self):
        data = ledger()
        data["items"].append(dict(data["items"][0], item_id="i2", name="另一个商品"))
        data["purchases"].append(dict(data["purchases"][0], purchase_id="buy2", item_id="i2"))
        data["events"][0].update(target_type="order_group", target_id="g", amount_fen=50000)
        data["tasks"] = [{"task_id": "whole-order", "plan_id": "p", "kind": "full_payment", "status": "paid",
                          "target_type": "order_group", "target_id": "g", "amount_fen": 50000,
                          "payment_event_ids": ["deposit"]}]
        result = shopping.review(data)
        self.assertEqual(result["summary"]["paid"]["total_fen"], 50000)
        self.assertEqual(len(result["multi_item_order_groups"]), 1)
        self.assertEqual(result["multi_item_order_groups"][0]["paid"]["total_fen"], 50000)

    def test_no_purchase_is_not_automatically_not_bought(self):
        data = ledger()
        data["purchases"], data["events"], data["tasks"] = [], [], []
        result = shopping.review(data)
        self.assertEqual(result["items"][0]["result"], "purchase_result_unknown")
        data["items"][0]["not_bought_reason"] = "等下一代"
        self.assertEqual(shopping.review(data)["items"][0]["result"], "not_bought")

    def test_returned_goods_still_show_purchase_history(self):
        data = ledger()
        data["purchases"][0]["retained_quantity"] = 0
        result = shopping.review(data)
        self.assertEqual(result["items"][0]["purchased_quantity"], "1")
        self.assertEqual(result["items"][0]["retained_quantity"], "0")

    def test_nonpayment_completed_task_is_not_a_payment(self):
        data = ledger()
        data["tasks"].append({"task_id": "evidence", "plan_id": "p", "kind": "evidence", "status": "done"})
        self.assertEqual(shopping.budget(data)["outstanding"]["total_fen"], 79900)

    def test_unpurchased_cart_costs_nothing_and_mental_budget_stays_whole(self):
        # 想买多少钱不进预算占用：购物车价值由仪表盘参考价小计承载，用户自行比较心里预算。
        data = ledger()
        data["purchases"], data["events"], data["tasks"] = [], [], []
        result = shopping.review(data)
        self.assertEqual(result["summary"]["net_cash_spend_fen"], 0)
        self.assertTrue(result["summary"]["complete"])
        budgeted = shopping.budget(data, budget_fen=100000)
        self.assertEqual(budgeted["budget"]["occupied_fen"], 0)
        self.assertEqual(budgeted["budget"]["remaining_fen"], 100000)

    def test_missing_planned_quantity_not_assumed_one(self):
        data = ledger()
        del data["items"][0]["planned_quantity"]
        with self.assertRaises(shopping.InputError):
            shopping.budget(data)

    def test_refund_over_one_order_not_hidden_by_another_order(self):
        data = ledger()
        data["items"].append(dict(data["items"][0], item_id="other"))
        data["purchases"].append(dict(data["purchases"][0], purchase_id="buy2", item_id="other", order_group_id="g2"))
        data["events"].append(dict(extra_event("second-payment", "payment", 20000), target_id="buy2"))
        data["events"].append(extra_event("too-much-refund", "refund", 15000))
        data["tasks"].append({"task_id": "other-paid", "plan_id": "p", "kind": "full_payment", "status": "paid",
                              "target_type": "purchase", "target_id": "buy2", "amount_fen": 20000,
                              "payment_event_ids": ["second-payment"]})
        result = shopping.budget(data)
        self.assertIsNone(result["net_cash_spend_fen"])
        self.assertIn("order_refund_exceeds_payment:g", result["issues"])

    def test_number_column_decimal_roundtrip_through_cli(self):
        data = ledger()
        data["events"][0]["amount_fen"] = 10000.0
        result = subprocess.run([sys.executable, str(ROOT / "scripts" / "shopping.py"), "budget",
                                 "--input", "-", "--budget", "20000.00"],
                                input=json.dumps(data), capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        summary = json.loads(result.stdout)
        self.assertEqual(summary["net_cash_spend_fen"], 10000)
        self.assertEqual(summary["budget"]["remaining_fen"], 1910100)
        self.assertIsInstance(summary["paid"]["total_fen"], int)

    def multi_item_order(self, count):
        """一单多品：count 件商品各自挂需求行，共享同一订单组的整单支付。"""
        data = ledger()
        for i in range(count):
            data["items"].append({"item_id": f"i-u{i}", "name": f"临时购买{i}", "planned_quantity": 1})
            data["purchases"].append({"purchase_id": f"buy-u{i}", "item_id": f"i-u{i}",
                                      "name": f"临时购买{i}", "order_group_id": "u-group", "quantity": 1,
                                      "order_status": "received"})
        data["events"].append({"event_id": "u-pay", "target_type": "order_group", "target_id": "u-group",
                               "kind": "payment", "status": "confirmed", "amount_fen": 5000})
        data["tasks"].append({"task_id": "u-task", "kind": "full_payment", "status": "paid",
                              "target_type": "order_group", "target_id": "u-group", "amount_fen": 5000,
                              "payment_event_ids": ["u-pay"]})
        return data

    def test_shared_order_keeps_unallocated_amount(self):
        result = shopping.review(self.multi_item_order(2))
        self.assertEqual(result["summary"]["paid"]["total_fen"], 15000)
        groups = {g["order_group_id"]: g for g in result["multi_item_order_groups"]}
        self.assertEqual(groups["u-group"]["paid"]["total_fen"], 5000)
        self.assertEqual(groups["u-group"]["unallocated_paid"]["total_fen"], 5000)

    def test_shared_order_total_includes_direct_purchase_payment(self):
        data = self.multi_item_order(2)
        data["events"].append({"event_id": "direct-extra", "kind": "payment", "status": "confirmed",
                               "target_type": "purchase", "target_id": "buy-u0", "amount_fen": 1000})
        data["tasks"].append({"task_id": "direct-extra-task", "kind": "full_payment", "status": "paid",
                              "target_type": "purchase", "target_id": "buy-u0", "amount_fen": 1000,
                              "payment_event_ids": ["direct-extra"]})
        result = shopping.review(data)
        group = next(g for g in result["multi_item_order_groups"] if g["order_group_id"] == "u-group")
        self.assertEqual(group["paid"]["total_fen"], 6000)
        self.assertEqual(group["unallocated_paid"]["total_fen"], 5000)

    def test_single_purchase_order_payment_shows_net_on_the_item(self):
        result = shopping.workbench(self.multi_item_order(1))
        row = next(i for i in result["items"] if i["item_id"] == "i-u0")
        self.assertEqual(row["assistant_notes"]["金额概况"], "净现金支出 50.00元")
        self.assertEqual(row["display"]["购买状态"], "已购买")

    def test_chinese_dropdown_labels_preserve_calculation_and_input(self):
        original = ledger()
        labeled = copy.deepcopy(original)
        for name, fields in shopping.DISPLAY_LABELS.items():
            for row in labeled[name]:
                for field, labels in fields.items():
                    if row.get(field) in labels:
                        row[field] = labels[row[field]]
        before = copy.deepcopy(labeled)
        self.assertEqual(shopping.review(labeled), shopping.review(original))
        self.assertEqual(labeled, before)

    def test_display_labels_stay_in_sync_with_template_options(self):
        # Single-select options and DISPLAY_LABELS must evolve together; an unsynced
        # UI option makes the calculator fail with InputError instead of guessing.
        # Template stores the Chinese option values, DISPLAY_LABELS maps token -> label.
        template = json.loads((ROOT / "assets" / "schema.json").read_text())
        fields = {t["logical_name"]: {f["key"]: f for f in t["fields"]} for t in template["tables"]}
        for table, columns in shopping.DISPLAY_LABELS.items():
            for column, labels in columns.items():
                options = fields[table][column].get("items") or fields[table][column].get("suggested_options")
                values = [o["value"] if isinstance(o, dict) else o for o in options]
                self.assertEqual(sorted(values), sorted(labels.values()),
                                 table + "." + column + " options and DISPLAY_LABELS diverged")

    def test_demo_totals(self):
        data = json.loads((ROOT / "assets" / "demo-ledger.json").read_text())
        result = shopping.review(data)
        self.assertEqual(result["summary"]["paid"]["total_fen"], 1035000)
        self.assertEqual(result["summary"]["net_cash_spend_fen"], 1030000)
        self.assertEqual(shopping.budget(data, budget_fen=2000000)["budget"]["remaining_fen"], 970000)
        self.assertEqual([i["result"] for i in result["items"]],
                         ["not_bought", "purchased", "purchased", "purchased"])
        self.assertTrue(result["summary"]["complete"])

    def test_template_shaped_ledger_stays_complete(self):
        # The six-table template must express every field the calculator reads, and json_text
        # columns hand back text instead of a parsed array.
        schema = json.loads((ROOT / "assets" / "schema.json").read_text())
        allowed = {t["logical_name"]: {f["key"] for f in t["fields"]} for t in schema["tables"]}
        data = json.loads((ROOT / "assets" / "demo-ledger.json").read_text())
        mapped = {
            "read_complete": True,
            "items": [{k: v for k, v in r.items() if k in allowed["items"]} for r in data["items"]],
            "purchases": [{k: v for k, v in r.items() if k in allowed["purchases"]} for r in data["purchases"]],
            "events": [{k: v for k, v in r.items() if k in allowed["events"]} for r in data["events"]],
            "tasks": [{**{k: v for k, v in r.items() if k in allowed["tasks"]},
                       "payment_event_ids": json.dumps(r["payment_event_ids"])} for r in data["tasks"]],
        }
        result = shopping.budget(mapped)
        self.assertTrue(result["complete"], result["issues"])
        self.assertEqual(result["outstanding"]["total_fen"], 0)

    def test_empty_payment_event_ids_cell_is_unallocated(self):
        data = ledger()
        data["tasks"][0]["payment_event_ids"] = ""
        data["tasks"][1]["payment_event_ids"] = None
        result = shopping.budget(data)
        self.assertIn("paid_task_without_matching_payment:deposit-task", result["issues"])
        self.assertIn("payment_unallocated:deposit", result["issues"])
        self.assertIsNone(result["outstanding"]["total_fen"])

    def test_malformed_payment_event_ids_rejected(self):
        data = ledger()
        data["tasks"][0]["payment_event_ids"] = "not-json"
        with self.assertRaises(shopping.InputError):
            shopping.budget(data)

    def test_payment_tasks_expose_kind_status_and_deadline(self):
        data = ledger()
        data["tasks"][1]["due_at"] = "2025-11-10T23:59:59+08:00"
        data["tasks"][1]["time_source"] = "USER_PROVIDED"
        tasks = {t["task_id"]: t for t in shopping.budget(data)["payment_tasks"]}
        self.assertEqual(tasks["balance-task"]["kind"], "balance")
        self.assertEqual(tasks["balance-task"]["status"], "active")
        self.assertEqual(tasks["balance-task"]["target_id"], "buy")
        self.assertEqual(tasks["balance-task"]["amount_fen"], 79900)
        self.assertEqual(tasks["balance-task"]["due_at"], "2025-11-10T23:59:59+08:00")
        self.assertEqual(tasks["balance-task"]["time_source"], "USER_PROVIDED")
        self.assertEqual(tasks["balance-task"]["remaining_fen"], 79900)

    def test_purchase_without_item_row_is_rejected(self):
        data = ledger()
        data["purchases"].append({"purchase_id": "impulse", "order_group_id": "g-impulse", "quantity": 1,
                                  "order_status": "ordered"})
        with self.assertRaises(shopping.InputError):
            shopping.review(data)

    def test_imported_purchase_gets_its_own_item_row(self):
        data = ledger()
        data["items"].append({"item_id": "i-impulse", "name": "顺手买的商品", "planned_quantity": 1})
        data["purchases"].append({"purchase_id": "impulse", "item_id": "i-impulse",
                                  "order_group_id": "g-impulse", "quantity": 1, "order_status": "received"})
        data["events"].append({"event_id": "impulse-pay", "target_type": "purchase", "target_id": "impulse",
                               "kind": "payment", "status": "confirmed", "amount_fen": 3000})
        data["tasks"].append({"task_id": "impulse-task", "kind": "full_payment", "status": "paid",
                              "target_type": "purchase", "target_id": "impulse",
                              "amount_fen": 3000, "payment_event_ids": ["impulse-pay"]})
        result = shopping.workbench(data)
        row = next(i for i in result["items"] if i["item_id"] == "i-impulse")
        self.assertEqual(row["display"]["购买状态"], "已购买")
        self.assertEqual(row["assistant_notes"]["金额概况"], "净现金支出 30.00元")
        self.assertEqual(result["summary"]["paid"]["total_fen"], 13000)

    def test_per_item_paid_from_order_details_shows_on_each_row(self):
        # 一单多品的实付按京东价比例分摊（订单详情页给出京东价与优惠构成），
        # 每件商品的价格列显示分摊后的实付，不再整单留空。
        data = ledger()
        data["items"] += [{"item_id": "i-a", "name": "A", "planned_quantity": 1},
                          {"item_id": "i-b", "name": "B", "planned_quantity": 1}]
        data["events"] = []
        data["tasks"] = []
        data["purchases"] = [
            {"purchase_id": "p-a", "item_id": "i-a", "order_group_id": "g", "quantity": 1,
             "order_status": "received", "details_json": {"item_paid_fen": 1458}},
            {"purchase_id": "p-b", "item_id": "i-b", "order_group_id": "g", "quantity": 1,
             "order_status": "received", "details_json": {"item_paid_fen": 1894}}]
        data["events"].append({"event_id": "pay", "target_type": "order_group", "target_id": "g",
                               "kind": "payment", "status": "confirmed", "amount_fen": 3352})
        data["tasks"].append({"task_id": "t", "kind": "full_payment", "status": "paid",
                              "target_type": "order_group", "target_id": "g", "amount_fen": 3352,
                              "payment_event_ids": ["pay"]})
        prices = {i["item_id"]: i["display"]["净支出（元）"] for i in shopping.workbench(data)["items"]}
        self.assertEqual(prices["i-a"], 14.58)
        self.assertEqual(prices["i-b"], 18.94)

    def test_purchase_without_item_row_is_always_rejected(self):
        data = ledger()
        data["purchases"][0]["item_id"] = "ghost"
        with self.assertRaises(shopping.InputError):
            shopping.budget(data)

    def test_extreme_decimal_input_exits_two_with_json_error(self):
        script = ROOT / "scripts" / "shopping.py"
        bad = subprocess.run([sys.executable, str(script), "unit-price", "--input", "-"],
                             input='{"amount_fen":100,"total_units":"1e999999999","unit":"g"}',
                             capture_output=True, text=True)
        self.assertEqual(bad.returncode, 2, bad.stderr)
        self.assertIn("error", json.loads(bad.stderr))

    def test_command_line_valid_and_invalid_json(self):
        script = ROOT / "scripts" / "shopping.py"
        valid = subprocess.run([sys.executable, str(script), "review", "--input", str(ROOT / "assets" / "demo-ledger.json")],
                               capture_output=True, text=True)
        self.assertEqual(valid.returncode, 0, valid.stderr)
        self.assertEqual(json.loads(valid.stdout)["summary"]["net_cash_spend_fen"], 1030000)
        invalid = subprocess.run([sys.executable, str(script), "money", "--input", "-"],
                                 input='{"amount": "NaN"}', capture_output=True, text=True)
        self.assertEqual(invalid.returncode, 2)
        self.assertIn("error", json.loads(invalid.stderr))


if __name__ == "__main__":
    unittest.main()
