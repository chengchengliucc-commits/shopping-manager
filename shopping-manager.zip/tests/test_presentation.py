import copy
import json
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import ledger
import presentation


class PresentationTests(unittest.TestCase):
    def schema(self):
        policy = json.loads((ledger.ROOT / "assets/presentation.json").read_text())
        sheets = []
        for i, table in enumerate(ledger.TABLES, 1):
            fields = [{"name": f["name"], "id": "f" + str(n), "type": f["suggested_cli_type"]}
                      for n, f in enumerate(table["fields"])]
            for definition in policy["display_fields"].get(table["logical_name"], []):
                if definition["name"] not in [f["name"] for f in fields]:
                    fields.append({"id": "display" + str(len(fields)), **definition})
            for retired in policy.get("retired_fields", {}).get(table["logical_name"], []):
                if retired not in [f["name"] for f in fields]:
                    fields.append({"id": "legacy" + str(len(fields)), "name": retired, "type": "MultiLineText"})
            if table["logical_name"] == "items":
                fields += [{"id": name, "name": name, "type": "Link"} for name in ("报价证据", "购物待办", "购买记录")]
                fields.append({"id": "custom", "name": "我的备注", "type": "MultiLineText"})
            view_policy = policy["tables"][table["logical_name"]]
            views = [{"id": "main", "name": view_policy["view"], "type": "Grid"}]
            views += [{"id": v["name"], "name": v["name"], "type": v["type"]} for v in view_policy.get("secondary_views", [])]
            views.append({"id": "user-owned", "name": "用户自己的视图", "type": "Grid"})
            sheets.append({"id": i, "name": table["name"], "fields": fields, "views": views})
        return {"sheets": sheets}

    def test_primary_screen_shows_estimate_hides_notes_and_preserves_user_views(self):
        schema = self.schema()
        before = copy.deepcopy(schema)
        compiled = presentation.compile_views(schema, "file")
        self.assertEqual(compiled["limitations"], [])
        views = [r["payload"] for r in compiled["requests"] if r["action"] == "update-view"]
        items = next(v for v in views if v.get("name") == "我的购物清单")
        self.assertEqual(items["order_fields"][:6], ["商品名称", "购买状态", "预估金额（元）",
                                                     "数量", "单位", "规格摘要"])
        for name in ("参考价格说明", "金额概况", "下一步", "核算时间", "操作ID", "更新时间", "计划状态"):
            self.assertTrue(next(a for a in items["fields_attribute"] if a["field"] == name)["hidden"])
        self.assertTrue(next(a for a in items["fields_attribute"] if a["field"] == "需求ID")["hidden"])
        self.assertFalse(next(a for a in items["fields_attribute"] if a["field"] == "我的备注")["hidden"])
        self.assertFalse(any(v["view_id"] == "user-owned" for v in views))
        for view in views:
            sheet = next(s for s in schema["sheets"] if s["id"] == view["sheet_id"])
            self.assertCountEqual(view["order_fields"], [f["name"] for f in sheet["fields"]])
        self.assertEqual(schema, before)

    def test_existing_core_text_fields_cannot_be_overwritten_via_display_payload(self):
        schema = self.schema()
        from unittest.mock import patch
        with patch.object(ledger, "cli_name", return_value="dbsheet-cli"):
            binding = ledger.make_binding(schema, "file")
        self.assertNotIn("报价商品", binding["tables"]["offers"]["display_fields"])
        self.assertIn("购买状态", binding["tables"]["items"]["display_fields"])
        self.assertNotIn("金额概况", binding["tables"]["items"]["display_fields"])

    def test_schema_keeps_operation_ids_local_and_omits_retired_cache_columns(self):
        schema = json.loads((ledger.ROOT / "assets/schema.json").read_text())
        for table in schema["tables"]:
            self.assertFalse({"operation_id", "updated_at"} & {f["key"] for f in table["fields"]})
        presentation_policy = json.loads((ledger.ROOT / "assets/presentation.json").read_text())
        item_fields = {f["name"] for f in presentation_policy["display_fields"]["items"]}
        self.assertEqual(item_fields, {"购买状态", "预估金额（元）", "净支出（元）", "参考价缺项标记", "规格摘要", "参考价日期"})

    def test_failed_inner_schema_response_produces_no_mutation_requests(self):
        raw = {"code": 0, "data": {"result": "denied", "detail": self.schema()}}
        with self.assertRaises(ValueError):
            presentation.compile_views(raw, "file")


if __name__ == "__main__":
    unittest.main()
