# 购物管理系统

**把跨平台购物资料整理清楚，随时知道还想买什么、买了什么、退款后真实花了多少。**

适合大促、装修、母婴等多商品集中采购：购物车、订单、付款和退款分散在不同材料里，整理一次后，下一次可以接着更新。

## 直接这样用

> 整理我的京东购物车，看看这些东西大概要花多少钱。

> 这件买了，全款100元。这是订单截图，补到原来的记录里。

> 上次申请的20元退款到账了。现在实际花了多少，还要付多少？

用户说清购物事实，Agent 负责拆规格、匹配已有记录和写入。浏览器读取不了时可用截图或口述；缺少非关键资料先记下来，不要求用户逐列填表。

## 能做什么

- **归档与续记**：导入购物车、商品页、历史订单、截图和口述购买。重复导入按来源对账，已买一部分后再次导入不会丢掉剩余需求。
- **分清预计与实际**：购物清单显示未买部分的预估金额；已购支出视图显示确认支付减到账退款后的净支出。
- **核对整体花费**：分别给出已付净额、订单待付、未买预估和预计总额；缺价时保留已知小计，完整预估留空。
- **跟进真实付款和退款**：支持定金尾款、退款申请/到账、整单多品。普通全款已付自动表达结清，无需维护额外付款待办。
- **比较已录报价**：对齐规格、销售条件和数量；新报价替代旧版本，历史低价保留作证据。参考日期可见，页面价不等于最终结算价。
- **恢复未完成操作**：多表业务保存固定操作计划与已确认步骤；未知写入先回读，不自动重复发送付款或购买记录。

## 工作台

默认清单聚焦商品、购买状态、未买预估、数量和关键规格；已购支出、规格明细有独立视图。来源、优惠核验、分摊解释和下一步按需展开或由 Agent 回复。

系统 ID、JSON 和分金额由脚本管理。预估金额、净支出和购买状态是派生展示；用户想改购买/退款事实时告诉 Agent，直接修改缓存会被重算。手动新增有名称、数量的商品行可在原行补系统身份。

## 准备与首次使用

需要 Python 3.9+，无额外 Python 包。首次运行：

```bash
python3 scripts/ledger.py bootstrap
```

已有工具会直接复用：优先使用 `dbsheet-cli`，未安装时检测 `kdocs-cli`（两者当前核对基线均为2.7.3）。两者都没有时，从 Skill 内置的官方分发包安装 dbsheet 依赖 Skill，再调用官方安装器下载本机平台的 CLI。已有 kdocs-cli 的用户无需再装 dbsheet-cli。

内置原始 ZIP 约125 KB，来源和 SHA256 保存在 assets/vendor/dbsheet.json。它含 Skill、参考文档与安装脚本，CLI 二进制仍需首次联网下载；不是所有平台二进制的离线包。安装器支持的平台与系统工具要求以官方脚本为准，当前实际安装验证覆盖 macOS。

按 bootstrap 返回的 auth_command 登录，由用户在官方授权页确认；然后复检：

```bash
python3 scripts/ledger.py doctor
```

doctor 返回选中的工具、版本、认证状态和读取/写入/配置/新建能力。它只输出认证布尔值，不输出 Token。网页归档还需要当前 Agent 环境的浏览器能力与用户登录。

官方 dbsheet Skill 默认装入 ~/.codex/skills/dbsheet（使用已配置的 CODEX_HOME 时跟随该位置），CLI 默认装入用户安装目录；即使该目录未加入 PATH，购物 Skill 也能检测并使用绝对路径。指定自定义 --bin-dir 时需把它加入后续命令的 PATH。已有不同内容的 dbsheet Skill 会保留并提示处理，不静默覆盖。

默认 config.json 为 cli=auto。高级调试可设置 `SHOPPING_CLI=kdocs-cli` 固定工具；也兼容配置中明确指定 dbsheet-cli/kdocs-cli。每次命令选定后保持不变，认证、权限或网络失败不自动换工具重发。已有绑定在帮助契约和远端表/字段 ID 核对通过后可跨两种 CLI 续用，恢复日志保留。

Agent 可用一条命令初始化或升级：

```bash
python3 scripts/ledger.py setup --name 购物账本 --binding /用户工作目录/.shopping-ledger/binding.json
# 已有账本使用 --file-id 实际文件ID
```

setup 创建或补齐五表与业务视图，保留已有数据和用户列，不改分享权限。绑定与恢复日志保存在用户工作目录；账本登记帮助新会话找到原落点。存在多个账本时明确选择。

## Agent 的业务入口

```bash
python3 scripts/ledger.py import-cart --input 规范化购物车.json --binding 绑定.json
python3 scripts/ledger.py record-purchase --input 规范化购买.json --binding 绑定.json
python3 scripts/ledger.py record-refund --input 规范化退款.json --binding 绑定.json
python3 scripts/ledger.py set-intent --input 本次决定.json --binding 绑定.json
python3 scripts/ledger.py overview --binding 绑定.json
python3 scripts/ledger.py sync --binding 绑定.json
```

JSON 由 Agent 准备，日常用户不需要编写。输入契约与恢复方法见 [业务入口](references/operations.md)，初始化与底层读写见 [CLI说明](references/db-cli.md)。

## 能力边界

归档用户自己的购物行为是核心；不自动下单、付款、领券或公开账本，不承诺全网抓价、后台同步、降价监控或返佣。网页、OCR 和身份匹配仍会出错，需要按实际材料核对。

未知金额为空，退款申请不减支出。共享订单缺完整分摊时保留整单现金结果，单品净支出留空；比例分摊保留推算性质。预算是用户当次可选输入，不要求维护预算列。

超时后的写入结果可能未知，脚本会停下并保留恢复状态；它不提供跨设备事务。初始化成功不等于页面已视觉验收，本地测试也不能证明真实服务一直可用。

当前适合小范围试用。全面开放前仍需两条 CLI 路径的真实建表、写入与恢复验收，以及无历史对话的新用户首次使用验证；工具检测与本地测试不能替代这些结果。

## 本地验证

```bash
python3 scripts/shopping.py overview --input assets/demo-ledger.json
python3 -m unittest discover -s tests -v
```

样例和测试资料均为虚构。测试覆盖金额、报价版本、重复输入、部分购买续记、退款、恢复与初始化模拟；验证范围和真实用户体验的未验证项见 [验证说明](references/validation.md)。
